/*
 * File: solar_panel_simu_data.c
 *
 * Code generated for Simulink model 'solar_panel_simu'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.5 (R2021a) 14-Nov-2020
 * C/C++ source code generated on : Sun Apr 28 20:10:05 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "solar_panel_simu.h"
#include "solar_panel_simu_private.h"

/* Block parameters (default storage) */
P_solar_panel_simu_T solar_panel_simu_P = {
  /* Expression: -1
   * Referenced by: '<Root>/Analog Input'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<Root>/Analog Input1'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<Root>/Analog Input2'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<Root>/Analog Input3'
   */
  -1.0,

  /* Expression: 0
   * Referenced by: '<S9>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S9>/Constant1'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S9>/Constant2'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S9>/Constant3'
   */
  0.0,

  /* Expression: 120
   * Referenced by: '<S9>/Constant4'
   */
  120.0,

  /* Computed Parameter: Merge1_InitialOutput
   * Referenced by: '<S6>/Merge1'
   */
  0.0,

  /* Computed Parameter: Merge2_InitialOutput
   * Referenced by: '<S6>/Merge2'
   */
  0.0,

  /* Computed Parameter: Merge3_InitialOutput
   * Referenced by: '<S6>/Merge3'
   */
  0.0,

  /* Computed Parameter: Merge4_InitialOutput
   * Referenced by: '<S6>/Merge4'
   */
  0.0,

  /* Computed Parameter: Merge5_InitialOutput
   * Referenced by: '<S6>/Merge5'
   */
  0.0,

  /* Start of '<S6>/If Action Subsystem7' */
  {
    /* Expression: 0
     * Referenced by: '<S10>/Constant'
     */
    0.0,

    /* Expression: 0
     * Referenced by: '<S10>/Constant1'
     */
    0.0,

    /* Expression: 0
     * Referenced by: '<S10>/Constant2'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S10>/Constant3'
     */
    1.0,

    /* Expression: 180
     * Referenced by: '<S10>/Constant4'
     */
    180.0
  }
  ,

  /* End of '<S6>/If Action Subsystem7' */

  /* Start of '<S6>/If Action Subsystem5' */
  {
    /* Expression: 0
     * Referenced by: '<S8>/Constant'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S8>/Constant1'
     */
    1.0,

    /* Expression: 0
     * Referenced by: '<S8>/Constant2'
     */
    0.0,

    /* Expression: 0
     * Referenced by: '<S8>/Constant3'
     */
    0.0,

    /* Expression: 60
     * Referenced by: '<S8>/Constant4'
     */
    60.0
  }
  ,

  /* End of '<S6>/If Action Subsystem5' */

  /* Start of '<S6>/If Action Subsystem4' */
  {
    /* Expression: 1
     * Referenced by: '<S7>/Constant'
     */
    1.0,

    /* Expression: 0
     * Referenced by: '<S7>/Constant1'
     */
    0.0,

    /* Expression: 0
     * Referenced by: '<S7>/Constant2'
     */
    0.0,

    /* Expression: 0
     * Referenced by: '<S7>/Constant3'
     */
    0.0,

    /* Expression: 0
     * Referenced by: '<S7>/Constant4'
     */
    0.0
  }
  ,

  /* End of '<S6>/If Action Subsystem4' */

  /* Start of '<Root>/If Action Subsystem3' */
  {
    /* Expression: 3
     * Referenced by: '<S5>/Constant'
     */
    3.0
  }
  ,

  /* End of '<Root>/If Action Subsystem3' */

  /* Start of '<Root>/If Action Subsystem2' */
  {
    /* Expression: 2
     * Referenced by: '<S4>/Constant'
     */
    2.0
  }
  ,

  /* End of '<Root>/If Action Subsystem2' */

  /* Start of '<Root>/If Action Subsystem1' */
  {
    /* Expression: 1
     * Referenced by: '<S3>/Constant'
     */
    1.0
  }
  ,

  /* End of '<Root>/If Action Subsystem1' */

  /* Start of '<Root>/If Action Subsystem' */
  {
    /* Expression: 0
     * Referenced by: '<S2>/Constant'
     */
    0.0
  }
  /* End of '<Root>/If Action Subsystem' */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
