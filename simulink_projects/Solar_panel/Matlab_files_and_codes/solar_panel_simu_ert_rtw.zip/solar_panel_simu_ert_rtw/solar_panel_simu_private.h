/*
 * File: solar_panel_simu_private.h
 *
 * Code generated for Simulink model 'solar_panel_simu'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.5 (R2021a) 14-Nov-2020
 * C/C++ source code generated on : Sun Apr 28 20:10:05 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_solar_panel_simu_private_h_
#define RTW_HEADER_solar_panel_simu_private_h_
#include "rtwtypes.h"
#include "solar_panel_simu.h"

extern real_T rt_roundd_snf(real_T u);
extern void solar_panel_s_IfActionSubsystem(real_T *rty_Out1,
  P_IfActionSubsystem_solar_pan_T *localP);
extern void solar_panel__IfActionSubsystem4(real_T *rty_Out1, real_T *rty_Out2,
  real_T *rty_Out3, real_T *rty_Out4, real_T *rty_Out5,
  P_IfActionSubsystem4_solar_pa_T *localP);

#endif                              /* RTW_HEADER_solar_panel_simu_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
