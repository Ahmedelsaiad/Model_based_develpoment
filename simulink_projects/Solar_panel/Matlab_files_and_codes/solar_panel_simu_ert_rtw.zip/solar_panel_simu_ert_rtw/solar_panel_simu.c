/*
 * File: solar_panel_simu.c
 *
 * Code generated for Simulink model 'solar_panel_simu'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.5 (R2021a) 14-Nov-2020
 * C/C++ source code generated on : Sun Apr 28 20:10:05 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "solar_panel_simu.h"
#include "solar_panel_simu_private.h"

/* Named constants for Chart: '<Root>/Chart' */
#define solar_panel_simu_IN_East       ((uint8_T)1U)
#define solar_panel_simu_IN_North      ((uint8_T)2U)
#define solar_panel_simu_IN_South      ((uint8_T)3U)
#define solar_panel_simu_IN_West       ((uint8_T)4U)

/* Block signals (default storage) */
B_solar_panel_simu_T solar_panel_simu_B;

/* Block states (default storage) */
DW_solar_panel_simu_T solar_panel_simu_DW;

/* Real-time model */
static RT_MODEL_solar_panel_simu_T solar_panel_simu_M_;
RT_MODEL_solar_panel_simu_T *const solar_panel_simu_M = &solar_panel_simu_M_;

/*
 * Output and update for action system:
 *    '<Root>/If Action Subsystem'
 *    '<Root>/If Action Subsystem1'
 *    '<Root>/If Action Subsystem2'
 *    '<Root>/If Action Subsystem3'
 */
void solar_panel_s_IfActionSubsystem(real_T *rty_Out1,
  P_IfActionSubsystem_solar_pan_T *localP)
{
  /* SignalConversion generated from: '<S2>/Out1' incorporates:
   *  Constant: '<S2>/Constant'
   */
  *rty_Out1 = localP->Constant_Value;
}

/*
 * Output and update for action system:
 *    '<S6>/If Action Subsystem4'
 *    '<S6>/If Action Subsystem5'
 *    '<S6>/If Action Subsystem7'
 */
void solar_panel__IfActionSubsystem4(real_T *rty_Out1, real_T *rty_Out2, real_T *
  rty_Out3, real_T *rty_Out4, real_T *rty_Out5, P_IfActionSubsystem4_solar_pa_T *
  localP)
{
  /* SignalConversion generated from: '<S7>/Out1' incorporates:
   *  Constant: '<S7>/Constant'
   */
  *rty_Out1 = localP->Constant_Value;

  /* SignalConversion generated from: '<S7>/Out2' incorporates:
   *  Constant: '<S7>/Constant1'
   */
  *rty_Out2 = localP->Constant1_Value;

  /* SignalConversion generated from: '<S7>/Out3' incorporates:
   *  Constant: '<S7>/Constant2'
   */
  *rty_Out3 = localP->Constant2_Value;

  /* SignalConversion generated from: '<S7>/Out4' incorporates:
   *  Constant: '<S7>/Constant3'
   */
  *rty_Out4 = localP->Constant3_Value;

  /* SignalConversion generated from: '<S7>/Out5' incorporates:
   *  Constant: '<S7>/Constant4'
   */
  *rty_Out5 = localP->Constant4_Value;
}

real_T rt_roundd_snf(real_T u)
{
  real_T y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

/* Model step function */
void solar_panel_simu_step(void)
{
  codertarget_arduinobase_inter_T *obj;
  real_T rtb_Merge;
  int16_T rtb_position;
  uint16_T rtb_AnalogInput1_0;
  uint16_T rtb_AnalogInput2_0;
  uint16_T rtb_AnalogInput3_0;
  uint16_T rtb_AnalogInput_0;
  uint8_T tmp;
  boolean_T guard1 = false;
  boolean_T guard2 = false;

  /* MATLABSystem: '<Root>/Analog Input' */
  if (solar_panel_simu_DW.obj_j.SampleTime !=
      solar_panel_simu_P.AnalogInput_SampleTime) {
    solar_panel_simu_DW.obj_j.SampleTime =
      solar_panel_simu_P.AnalogInput_SampleTime;
  }

  obj = &solar_panel_simu_DW.obj_j;
  obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(14UL);
  MW_AnalogInSingle_ReadResult
    (solar_panel_simu_DW.obj_j.AnalogInDriverObj.MW_ANALOGIN_HANDLE,
     &rtb_AnalogInput_0, 3);

  /* MATLABSystem: '<Root>/Analog Input1' */
  if (solar_panel_simu_DW.obj_b.SampleTime !=
      solar_panel_simu_P.AnalogInput1_SampleTime) {
    solar_panel_simu_DW.obj_b.SampleTime =
      solar_panel_simu_P.AnalogInput1_SampleTime;
  }

  obj = &solar_panel_simu_DW.obj_b;
  obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(15UL);
  MW_AnalogInSingle_ReadResult
    (solar_panel_simu_DW.obj_b.AnalogInDriverObj.MW_ANALOGIN_HANDLE,
     &rtb_AnalogInput1_0, 3);

  /* MATLABSystem: '<Root>/Analog Input2' */
  if (solar_panel_simu_DW.obj_d.SampleTime !=
      solar_panel_simu_P.AnalogInput2_SampleTime) {
    solar_panel_simu_DW.obj_d.SampleTime =
      solar_panel_simu_P.AnalogInput2_SampleTime;
  }

  obj = &solar_panel_simu_DW.obj_d;
  obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(16UL);
  MW_AnalogInSingle_ReadResult
    (solar_panel_simu_DW.obj_d.AnalogInDriverObj.MW_ANALOGIN_HANDLE,
     &rtb_AnalogInput2_0, 3);

  /* MATLABSystem: '<Root>/Analog Input3' */
  if (solar_panel_simu_DW.obj.SampleTime !=
      solar_panel_simu_P.AnalogInput3_SampleTime) {
    solar_panel_simu_DW.obj.SampleTime =
      solar_panel_simu_P.AnalogInput3_SampleTime;
  }

  obj = &solar_panel_simu_DW.obj;
  obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(17UL);
  MW_AnalogInSingle_ReadResult
    (solar_panel_simu_DW.obj.AnalogInDriverObj.MW_ANALOGIN_HANDLE,
     &rtb_AnalogInput3_0, 3);

  /* If: '<Root>/If' incorporates:
   *  MATLABSystem: '<Root>/Analog Input'
   *  MATLABSystem: '<Root>/Analog Input1'
   *  MATLABSystem: '<Root>/Analog Input2'
   *  MATLABSystem: '<Root>/Analog Input3'
   */
  if ((rtb_AnalogInput_0 > rtb_AnalogInput1_0) && (rtb_AnalogInput_0 >
       rtb_AnalogInput2_0) && (rtb_AnalogInput_0 > rtb_AnalogInput3_0)) {
    /* Outputs for IfAction SubSystem: '<Root>/If Action Subsystem' incorporates:
     *  ActionPort: '<S2>/Action Port'
     */
    solar_panel_s_IfActionSubsystem(&rtb_Merge,
      &solar_panel_simu_P.IfActionSubsystem);

    /* End of Outputs for SubSystem: '<Root>/If Action Subsystem' */
  } else if ((rtb_AnalogInput1_0 > rtb_AnalogInput_0) && (rtb_AnalogInput1_0 >
              rtb_AnalogInput2_0) && (rtb_AnalogInput1_0 > rtb_AnalogInput3_0))
  {
    /* Outputs for IfAction SubSystem: '<Root>/If Action Subsystem1' incorporates:
     *  ActionPort: '<S3>/Action Port'
     */
    solar_panel_s_IfActionSubsystem(&rtb_Merge,
      &solar_panel_simu_P.IfActionSubsystem1);

    /* End of Outputs for SubSystem: '<Root>/If Action Subsystem1' */
  } else if ((rtb_AnalogInput2_0 > rtb_AnalogInput_0) && (rtb_AnalogInput2_0 >
              rtb_AnalogInput1_0) && (rtb_AnalogInput2_0 > rtb_AnalogInput3_0))
  {
    /* Outputs for IfAction SubSystem: '<Root>/If Action Subsystem2' incorporates:
     *  ActionPort: '<S4>/Action Port'
     */
    solar_panel_s_IfActionSubsystem(&rtb_Merge,
      &solar_panel_simu_P.IfActionSubsystem2);

    /* End of Outputs for SubSystem: '<Root>/If Action Subsystem2' */
  } else {
    /* Outputs for IfAction SubSystem: '<Root>/If Action Subsystem3' incorporates:
     *  ActionPort: '<S5>/Action Port'
     */
    solar_panel_s_IfActionSubsystem(&rtb_Merge,
      &solar_panel_simu_P.IfActionSubsystem3);

    /* End of Outputs for SubSystem: '<Root>/If Action Subsystem3' */
  }

  /* End of If: '<Root>/If' */

  /* Chart: '<Root>/Chart' */
  guard1 = false;
  guard2 = false;
  if (solar_panel_simu_DW.is_active_c3_solar_panel_simu == 0U) {
    solar_panel_simu_DW.is_active_c3_solar_panel_simu = 1U;
    solar_panel_simu_DW.is_c3_solar_panel_simu = solar_panel_simu_IN_North;
    guard2 = true;
  } else {
    switch (solar_panel_simu_DW.is_c3_solar_panel_simu) {
     case solar_panel_simu_IN_East:
      if (rtb_Merge != 2.0) {
        if (rtb_Merge == 0.0) {
          solar_panel_simu_DW.is_c3_solar_panel_simu = solar_panel_simu_IN_North;
          guard2 = true;
        } else {
          if (rtb_Merge == 2.0) {
            solar_panel_simu_DW.is_c3_solar_panel_simu =
              solar_panel_simu_IN_East;
            rtb_position = 2;
          } else if (rtb_Merge == 3.0) {
            solar_panel_simu_DW.is_c3_solar_panel_simu =
              solar_panel_simu_IN_West;
            rtb_position = 3;
          } else if (rtb_Merge == 1.0) {
            solar_panel_simu_DW.is_c3_solar_panel_simu =
              solar_panel_simu_IN_South;
            rtb_position = 1;
          } else {
            rtb_position = 2;
          }

          guard1 = true;
        }
      } else {
        rtb_position = 2;
        guard1 = true;
      }
      break;

     case solar_panel_simu_IN_North:
      if (rtb_Merge != 0.0) {
        if (rtb_Merge == 1.0) {
          solar_panel_simu_DW.is_c3_solar_panel_simu = solar_panel_simu_IN_South;
          rtb_position = 1;
          guard1 = true;
        } else if (rtb_Merge == 2.0) {
          solar_panel_simu_DW.is_c3_solar_panel_simu = solar_panel_simu_IN_East;
          rtb_position = 2;
          guard1 = true;
        } else if (rtb_Merge == 3.0) {
          solar_panel_simu_DW.is_c3_solar_panel_simu = solar_panel_simu_IN_West;
          rtb_position = 3;
          guard1 = true;
        } else {
          guard2 = true;
        }
      } else {
        guard2 = true;
      }
      break;

     case solar_panel_simu_IN_South:
      if (rtb_Merge != 1.0) {
        if (rtb_Merge == 0.0) {
          solar_panel_simu_DW.is_c3_solar_panel_simu = solar_panel_simu_IN_North;
          guard2 = true;
        } else {
          if (rtb_Merge == 2.0) {
            solar_panel_simu_DW.is_c3_solar_panel_simu =
              solar_panel_simu_IN_East;
            rtb_position = 2;
          } else if (rtb_Merge == 3.0) {
            solar_panel_simu_DW.is_c3_solar_panel_simu =
              solar_panel_simu_IN_West;
            rtb_position = 3;
          } else if (rtb_Merge == 1.0) {
            solar_panel_simu_DW.is_c3_solar_panel_simu =
              solar_panel_simu_IN_South;
            rtb_position = 1;
          } else {
            rtb_position = 1;
          }

          guard1 = true;
        }
      } else {
        rtb_position = 1;
        guard1 = true;
      }
      break;

     default:
      /* case IN_West: */
      if (rtb_Merge != 3.0) {
        if (rtb_Merge == 0.0) {
          solar_panel_simu_DW.is_c3_solar_panel_simu = solar_panel_simu_IN_North;
          guard2 = true;
        } else {
          if (rtb_Merge == 2.0) {
            solar_panel_simu_DW.is_c3_solar_panel_simu =
              solar_panel_simu_IN_East;
            rtb_position = 2;
          } else if (rtb_Merge == 3.0) {
            solar_panel_simu_DW.is_c3_solar_panel_simu =
              solar_panel_simu_IN_West;
            rtb_position = 3;
          } else if (rtb_Merge == 1.0) {
            solar_panel_simu_DW.is_c3_solar_panel_simu =
              solar_panel_simu_IN_South;
            rtb_position = 1;
          } else {
            rtb_position = 3;
          }

          guard1 = true;
        }
      } else {
        rtb_position = 3;
        guard1 = true;
      }
      break;
    }
  }

  if (guard2) {
    /* Outputs for IfAction SubSystem: '<S6>/If Action Subsystem4' incorporates:
     *  ActionPort: '<S7>/Action Port'
     */
    /* If: '<Root>/If1' */
    solar_panel__IfActionSubsystem4(&solar_panel_simu_B.Merge1,
      &solar_panel_simu_B.Merge2, &solar_panel_simu_B.Merge3,
      &solar_panel_simu_B.Merge4, &solar_panel_simu_B.Merge5,
      &solar_panel_simu_P.IfActionSubsystem4);

    /* End of Outputs for SubSystem: '<S6>/If Action Subsystem4' */
  }

  if (guard1) {
    /* If: '<Root>/If1' */
    if (rtb_position == 1) {
      /* Outputs for IfAction SubSystem: '<S6>/If Action Subsystem5' incorporates:
       *  ActionPort: '<S8>/Action Port'
       */
      solar_panel__IfActionSubsystem4(&solar_panel_simu_B.Merge1,
        &solar_panel_simu_B.Merge2, &solar_panel_simu_B.Merge3,
        &solar_panel_simu_B.Merge4, &solar_panel_simu_B.Merge5,
        &solar_panel_simu_P.IfActionSubsystem5);

      /* End of Outputs for SubSystem: '<S6>/If Action Subsystem5' */
    } else if (rtb_position == 2) {
      /* Outputs for IfAction SubSystem: '<S6>/If Action Subsystem6' incorporates:
       *  ActionPort: '<S9>/Action Port'
       */
      /* Merge: '<S6>/Merge1' incorporates:
       *  Constant: '<S9>/Constant'
       *  SignalConversion generated from: '<S9>/Out2'
       */
      solar_panel_simu_B.Merge1 = solar_panel_simu_P.Constant_Value;

      /* Merge: '<S6>/Merge2' incorporates:
       *  Constant: '<S9>/Constant1'
       *  SignalConversion generated from: '<S9>/Out1'
       */
      solar_panel_simu_B.Merge2 = solar_panel_simu_P.Constant1_Value;

      /* Merge: '<S6>/Merge3' incorporates:
       *  Constant: '<S9>/Constant2'
       *  SignalConversion generated from: '<S9>/Out3'
       */
      solar_panel_simu_B.Merge3 = solar_panel_simu_P.Constant2_Value;

      /* Merge: '<S6>/Merge4' incorporates:
       *  Constant: '<S9>/Constant3'
       *  SignalConversion generated from: '<S9>/Out4'
       */
      solar_panel_simu_B.Merge4 = solar_panel_simu_P.Constant3_Value;

      /* Merge: '<S6>/Merge5' incorporates:
       *  Constant: '<S9>/Constant4'
       *  SignalConversion generated from: '<S9>/Out5'
       */
      solar_panel_simu_B.Merge5 = solar_panel_simu_P.Constant4_Value;

      /* End of Outputs for SubSystem: '<S6>/If Action Subsystem6' */
    } else {
      /* Outputs for IfAction SubSystem: '<S6>/If Action Subsystem7' incorporates:
       *  ActionPort: '<S10>/Action Port'
       */
      solar_panel__IfActionSubsystem4(&solar_panel_simu_B.Merge1,
        &solar_panel_simu_B.Merge2, &solar_panel_simu_B.Merge3,
        &solar_panel_simu_B.Merge4, &solar_panel_simu_B.Merge5,
        &solar_panel_simu_P.IfActionSubsystem7);

      /* End of Outputs for SubSystem: '<S6>/If Action Subsystem7' */
    }
  }

  /* End of Chart: '<Root>/Chart' */

  /* MATLABSystem: '<Root>/Digital Output' */
  rtb_Merge = rt_roundd_snf(solar_panel_simu_B.Merge1);
  if (rtb_Merge < 256.0) {
    if (rtb_Merge >= 0.0) {
      tmp = (uint8_T)rtb_Merge;
    } else {
      tmp = 0U;
    }
  } else {
    tmp = MAX_uint8_T;
  }

  writeDigitalPin(13, tmp);

  /* End of MATLABSystem: '<Root>/Digital Output' */

  /* MATLABSystem: '<Root>/Digital Output1' */
  rtb_Merge = rt_roundd_snf(solar_panel_simu_B.Merge2);
  if (rtb_Merge < 256.0) {
    if (rtb_Merge >= 0.0) {
      tmp = (uint8_T)rtb_Merge;
    } else {
      tmp = 0U;
    }
  } else {
    tmp = MAX_uint8_T;
  }

  writeDigitalPin(12, tmp);

  /* End of MATLABSystem: '<Root>/Digital Output1' */

  /* MATLABSystem: '<Root>/Digital Output2' */
  rtb_Merge = rt_roundd_snf(solar_panel_simu_B.Merge3);
  if (rtb_Merge < 256.0) {
    if (rtb_Merge >= 0.0) {
      tmp = (uint8_T)rtb_Merge;
    } else {
      tmp = 0U;
    }
  } else {
    tmp = MAX_uint8_T;
  }

  writeDigitalPin(11, tmp);

  /* End of MATLABSystem: '<Root>/Digital Output2' */

  /* MATLABSystem: '<Root>/Digital Output3' */
  rtb_Merge = rt_roundd_snf(solar_panel_simu_B.Merge4);
  if (rtb_Merge < 256.0) {
    if (rtb_Merge >= 0.0) {
      tmp = (uint8_T)rtb_Merge;
    } else {
      tmp = 0U;
    }
  } else {
    tmp = MAX_uint8_T;
  }

  writeDigitalPin(10, tmp);

  /* End of MATLABSystem: '<Root>/Digital Output3' */

  /* MATLABSystem: '<Root>/Standard Servo Write' */
  if (solar_panel_simu_B.Merge5 < 0.0) {
    tmp = 0U;
  } else if (solar_panel_simu_B.Merge5 > 180.0) {
    tmp = 180U;
  } else {
    rtb_Merge = rt_roundd_snf(solar_panel_simu_B.Merge5);
    if (rtb_Merge < 256.0) {
      if (rtb_Merge >= 0.0) {
        tmp = (uint8_T)rtb_Merge;
      } else {
        tmp = 0U;
      }
    } else {
      tmp = MAX_uint8_T;
    }
  }

  MW_servoWrite(0, tmp);

  /* End of MATLABSystem: '<Root>/Standard Servo Write' */
}

/* Model initialize function */
void solar_panel_simu_initialize(void)
{
  {
    codertarget_arduinobase_inter_T *obj;

    /* SystemInitialize for Merge: '<S6>/Merge1' */
    solar_panel_simu_B.Merge1 = solar_panel_simu_P.Merge1_InitialOutput;

    /* SystemInitialize for Merge: '<S6>/Merge2' */
    solar_panel_simu_B.Merge2 = solar_panel_simu_P.Merge2_InitialOutput;

    /* SystemInitialize for Merge: '<S6>/Merge3' */
    solar_panel_simu_B.Merge3 = solar_panel_simu_P.Merge3_InitialOutput;

    /* SystemInitialize for Merge: '<S6>/Merge4' */
    solar_panel_simu_B.Merge4 = solar_panel_simu_P.Merge4_InitialOutput;

    /* SystemInitialize for Merge: '<S6>/Merge5' */
    solar_panel_simu_B.Merge5 = solar_panel_simu_P.Merge5_InitialOutput;

    /* Start for MATLABSystem: '<Root>/Analog Input' */
    solar_panel_simu_DW.obj_j.matlabCodegenIsDeleted = true;
    solar_panel_simu_DW.obj_j.isInitialized = 0L;
    solar_panel_simu_DW.obj_j.SampleTime = -1.0;
    solar_panel_simu_DW.obj_j.matlabCodegenIsDeleted = false;
    solar_panel_simu_DW.obj_j.SampleTime =
      solar_panel_simu_P.AnalogInput_SampleTime;
    obj = &solar_panel_simu_DW.obj_j;
    solar_panel_simu_DW.obj_j.isSetupComplete = false;
    solar_panel_simu_DW.obj_j.isInitialized = 1L;
    obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogInSingle_Open(14UL);
    solar_panel_simu_DW.obj_j.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Analog Input1' */
    solar_panel_simu_DW.obj_b.matlabCodegenIsDeleted = true;
    solar_panel_simu_DW.obj_b.isInitialized = 0L;
    solar_panel_simu_DW.obj_b.SampleTime = -1.0;
    solar_panel_simu_DW.obj_b.matlabCodegenIsDeleted = false;
    solar_panel_simu_DW.obj_b.SampleTime =
      solar_panel_simu_P.AnalogInput1_SampleTime;
    obj = &solar_panel_simu_DW.obj_b;
    solar_panel_simu_DW.obj_b.isSetupComplete = false;
    solar_panel_simu_DW.obj_b.isInitialized = 1L;
    obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogInSingle_Open(15UL);
    solar_panel_simu_DW.obj_b.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Analog Input2' */
    solar_panel_simu_DW.obj_d.matlabCodegenIsDeleted = true;
    solar_panel_simu_DW.obj_d.isInitialized = 0L;
    solar_panel_simu_DW.obj_d.SampleTime = -1.0;
    solar_panel_simu_DW.obj_d.matlabCodegenIsDeleted = false;
    solar_panel_simu_DW.obj_d.SampleTime =
      solar_panel_simu_P.AnalogInput2_SampleTime;
    obj = &solar_panel_simu_DW.obj_d;
    solar_panel_simu_DW.obj_d.isSetupComplete = false;
    solar_panel_simu_DW.obj_d.isInitialized = 1L;
    obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogInSingle_Open(16UL);
    solar_panel_simu_DW.obj_d.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Analog Input3' */
    solar_panel_simu_DW.obj.matlabCodegenIsDeleted = true;
    solar_panel_simu_DW.obj.isInitialized = 0L;
    solar_panel_simu_DW.obj.SampleTime = -1.0;
    solar_panel_simu_DW.obj.matlabCodegenIsDeleted = false;
    solar_panel_simu_DW.obj.SampleTime =
      solar_panel_simu_P.AnalogInput3_SampleTime;
    obj = &solar_panel_simu_DW.obj;
    solar_panel_simu_DW.obj.isSetupComplete = false;
    solar_panel_simu_DW.obj.isInitialized = 1L;
    obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogInSingle_Open(17UL);
    solar_panel_simu_DW.obj.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Output' */
    solar_panel_simu_DW.obj_h.matlabCodegenIsDeleted = false;
    solar_panel_simu_DW.obj_h.isInitialized = 1L;
    digitalIOSetup(13, 1);
    solar_panel_simu_DW.obj_h.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Output1' */
    solar_panel_simu_DW.obj_ec.matlabCodegenIsDeleted = false;
    solar_panel_simu_DW.obj_ec.isInitialized = 1L;
    digitalIOSetup(12, 1);
    solar_panel_simu_DW.obj_ec.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Output2' */
    solar_panel_simu_DW.obj_g.matlabCodegenIsDeleted = false;
    solar_panel_simu_DW.obj_g.isInitialized = 1L;
    digitalIOSetup(11, 1);
    solar_panel_simu_DW.obj_g.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Output3' */
    solar_panel_simu_DW.obj_e.matlabCodegenIsDeleted = false;
    solar_panel_simu_DW.obj_e.isInitialized = 1L;
    digitalIOSetup(10, 1);
    solar_panel_simu_DW.obj_e.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Standard Servo Write' */
    MW_servoAttach(0, 9);
  }
}

/* Model terminate function */
void solar_panel_simu_terminate(void)
{
  codertarget_arduinobase_inter_T *obj;

  /* Terminate for MATLABSystem: '<Root>/Analog Input' */
  obj = &solar_panel_simu_DW.obj_j;
  if (!solar_panel_simu_DW.obj_j.matlabCodegenIsDeleted) {
    solar_panel_simu_DW.obj_j.matlabCodegenIsDeleted = true;
    if ((solar_panel_simu_DW.obj_j.isInitialized == 1L) &&
        solar_panel_simu_DW.obj_j.isSetupComplete) {
      obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(14UL);
      MW_AnalogIn_Close
        (solar_panel_simu_DW.obj_j.AnalogInDriverObj.MW_ANALOGIN_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Analog Input' */

  /* Terminate for MATLABSystem: '<Root>/Analog Input1' */
  obj = &solar_panel_simu_DW.obj_b;
  if (!solar_panel_simu_DW.obj_b.matlabCodegenIsDeleted) {
    solar_panel_simu_DW.obj_b.matlabCodegenIsDeleted = true;
    if ((solar_panel_simu_DW.obj_b.isInitialized == 1L) &&
        solar_panel_simu_DW.obj_b.isSetupComplete) {
      obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(15UL);
      MW_AnalogIn_Close
        (solar_panel_simu_DW.obj_b.AnalogInDriverObj.MW_ANALOGIN_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Analog Input1' */

  /* Terminate for MATLABSystem: '<Root>/Analog Input2' */
  obj = &solar_panel_simu_DW.obj_d;
  if (!solar_panel_simu_DW.obj_d.matlabCodegenIsDeleted) {
    solar_panel_simu_DW.obj_d.matlabCodegenIsDeleted = true;
    if ((solar_panel_simu_DW.obj_d.isInitialized == 1L) &&
        solar_panel_simu_DW.obj_d.isSetupComplete) {
      obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(16UL);
      MW_AnalogIn_Close
        (solar_panel_simu_DW.obj_d.AnalogInDriverObj.MW_ANALOGIN_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Analog Input2' */

  /* Terminate for MATLABSystem: '<Root>/Analog Input3' */
  obj = &solar_panel_simu_DW.obj;
  if (!solar_panel_simu_DW.obj.matlabCodegenIsDeleted) {
    solar_panel_simu_DW.obj.matlabCodegenIsDeleted = true;
    if ((solar_panel_simu_DW.obj.isInitialized == 1L) &&
        solar_panel_simu_DW.obj.isSetupComplete) {
      obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(17UL);
      MW_AnalogIn_Close
        (solar_panel_simu_DW.obj.AnalogInDriverObj.MW_ANALOGIN_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Analog Input3' */

  /* Terminate for MATLABSystem: '<Root>/Digital Output' */
  if (!solar_panel_simu_DW.obj_h.matlabCodegenIsDeleted) {
    solar_panel_simu_DW.obj_h.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Output' */

  /* Terminate for MATLABSystem: '<Root>/Digital Output1' */
  if (!solar_panel_simu_DW.obj_ec.matlabCodegenIsDeleted) {
    solar_panel_simu_DW.obj_ec.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Output1' */

  /* Terminate for MATLABSystem: '<Root>/Digital Output2' */
  if (!solar_panel_simu_DW.obj_g.matlabCodegenIsDeleted) {
    solar_panel_simu_DW.obj_g.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Output2' */

  /* Terminate for MATLABSystem: '<Root>/Digital Output3' */
  if (!solar_panel_simu_DW.obj_e.matlabCodegenIsDeleted) {
    solar_panel_simu_DW.obj_e.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Output3' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
