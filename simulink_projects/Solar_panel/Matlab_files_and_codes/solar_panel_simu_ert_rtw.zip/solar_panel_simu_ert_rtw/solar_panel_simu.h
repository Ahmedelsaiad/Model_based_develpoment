/*
 * File: solar_panel_simu.h
 *
 * Code generated for Simulink model 'solar_panel_simu'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.5 (R2021a) 14-Nov-2020
 * C/C++ source code generated on : Sun Apr 28 20:10:05 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_solar_panel_simu_h_
#define RTW_HEADER_solar_panel_simu_h_
#include <math.h>
#include <stddef.h>
#ifndef solar_panel_simu_COMMON_INCLUDES_
#define solar_panel_simu_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "MW_AnalogIn.h"
#include "MW_arduino_digitalio.h"
#include "MW_ServoWriteRead.h"
#endif                                 /* solar_panel_simu_COMMON_INCLUDES_ */

#include "solar_panel_simu_types.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Block signals (default storage) */
typedef struct {
  real_T Merge1;                       /* '<S6>/Merge1' */
  real_T Merge2;                       /* '<S6>/Merge2' */
  real_T Merge3;                       /* '<S6>/Merge3' */
  real_T Merge4;                       /* '<S6>/Merge4' */
  real_T Merge5;                       /* '<S6>/Merge5' */
} B_solar_panel_simu_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  codertarget_arduinobase_inter_T obj; /* '<Root>/Analog Input3' */
  codertarget_arduinobase_inter_T obj_d;/* '<Root>/Analog Input2' */
  codertarget_arduinobase_inter_T obj_b;/* '<Root>/Analog Input1' */
  codertarget_arduinobase_inter_T obj_j;/* '<Root>/Analog Input' */
  codertarget_arduinobase_block_T obj_e;/* '<Root>/Digital Output3' */
  codertarget_arduinobase_block_T obj_g;/* '<Root>/Digital Output2' */
  codertarget_arduinobase_block_T obj_ec;/* '<Root>/Digital Output1' */
  codertarget_arduinobase_block_T obj_h;/* '<Root>/Digital Output' */
  uint8_T is_active_c3_solar_panel_simu;/* '<Root>/Chart' */
  uint8_T is_c3_solar_panel_simu;      /* '<Root>/Chart' */
} DW_solar_panel_simu_T;

/* Parameters for system: '<Root>/If Action Subsystem' */
struct P_IfActionSubsystem_solar_pan_T_ {
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S2>/Constant'
                                        */
};

/* Parameters for system: '<S6>/If Action Subsystem4' */
struct P_IfActionSubsystem4_solar_pa_T_ {
  real_T Constant_Value;               /* Expression: 1
                                        * Referenced by: '<S7>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S7>/Constant1'
                                        */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<S7>/Constant2'
                                        */
  real_T Constant3_Value;              /* Expression: 0
                                        * Referenced by: '<S7>/Constant3'
                                        */
  real_T Constant4_Value;              /* Expression: 0
                                        * Referenced by: '<S7>/Constant4'
                                        */
};

/* Parameters (default storage) */
struct P_solar_panel_simu_T_ {
  real_T AnalogInput_SampleTime;       /* Expression: -1
                                        * Referenced by: '<Root>/Analog Input'
                                        */
  real_T AnalogInput1_SampleTime;      /* Expression: -1
                                        * Referenced by: '<Root>/Analog Input1'
                                        */
  real_T AnalogInput2_SampleTime;      /* Expression: -1
                                        * Referenced by: '<Root>/Analog Input2'
                                        */
  real_T AnalogInput3_SampleTime;      /* Expression: -1
                                        * Referenced by: '<Root>/Analog Input3'
                                        */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S9>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S9>/Constant1'
                                        */
  real_T Constant2_Value;              /* Expression: 1
                                        * Referenced by: '<S9>/Constant2'
                                        */
  real_T Constant3_Value;              /* Expression: 0
                                        * Referenced by: '<S9>/Constant3'
                                        */
  real_T Constant4_Value;              /* Expression: 120
                                        * Referenced by: '<S9>/Constant4'
                                        */
  real_T Merge1_InitialOutput;       /* Computed Parameter: Merge1_InitialOutput
                                      * Referenced by: '<S6>/Merge1'
                                      */
  real_T Merge2_InitialOutput;       /* Computed Parameter: Merge2_InitialOutput
                                      * Referenced by: '<S6>/Merge2'
                                      */
  real_T Merge3_InitialOutput;       /* Computed Parameter: Merge3_InitialOutput
                                      * Referenced by: '<S6>/Merge3'
                                      */
  real_T Merge4_InitialOutput;       /* Computed Parameter: Merge4_InitialOutput
                                      * Referenced by: '<S6>/Merge4'
                                      */
  real_T Merge5_InitialOutput;       /* Computed Parameter: Merge5_InitialOutput
                                      * Referenced by: '<S6>/Merge5'
                                      */
  P_IfActionSubsystem4_solar_pa_T IfActionSubsystem7;/* '<S6>/If Action Subsystem7' */
  P_IfActionSubsystem4_solar_pa_T IfActionSubsystem5;/* '<S6>/If Action Subsystem5' */
  P_IfActionSubsystem4_solar_pa_T IfActionSubsystem4;/* '<S6>/If Action Subsystem4' */
  P_IfActionSubsystem_solar_pan_T IfActionSubsystem3;/* '<Root>/If Action Subsystem3' */
  P_IfActionSubsystem_solar_pan_T IfActionSubsystem2;/* '<Root>/If Action Subsystem2' */
  P_IfActionSubsystem_solar_pan_T IfActionSubsystem1;/* '<Root>/If Action Subsystem1' */
  P_IfActionSubsystem_solar_pan_T IfActionSubsystem;/* '<Root>/If Action Subsystem' */
};

/* Real-time Model Data Structure */
struct tag_RTM_solar_panel_simu_T {
  const char_T *errorStatus;
};

/* Block parameters (default storage) */
extern P_solar_panel_simu_T solar_panel_simu_P;

/* Block signals (default storage) */
extern B_solar_panel_simu_T solar_panel_simu_B;

/* Block states (default storage) */
extern DW_solar_panel_simu_T solar_panel_simu_DW;

/* Model entry point functions */
extern void solar_panel_simu_initialize(void);
extern void solar_panel_simu_step(void);
extern void solar_panel_simu_terminate(void);

/* Real-time Model object */
extern RT_MODEL_solar_panel_simu_T *const solar_panel_simu_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'solar_panel_simu'
 * '<S1>'   : 'solar_panel_simu/Chart'
 * '<S2>'   : 'solar_panel_simu/If Action Subsystem'
 * '<S3>'   : 'solar_panel_simu/If Action Subsystem1'
 * '<S4>'   : 'solar_panel_simu/If Action Subsystem2'
 * '<S5>'   : 'solar_panel_simu/If Action Subsystem3'
 * '<S6>'   : 'solar_panel_simu/Subsystem'
 * '<S7>'   : 'solar_panel_simu/Subsystem/If Action Subsystem4'
 * '<S8>'   : 'solar_panel_simu/Subsystem/If Action Subsystem5'
 * '<S9>'   : 'solar_panel_simu/Subsystem/If Action Subsystem6'
 * '<S10>'  : 'solar_panel_simu/Subsystem/If Action Subsystem7'
 */
#endif                                 /* RTW_HEADER_solar_panel_simu_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
