#ifndef RTW_HEADER_Passive_balancing_h_
#define RTW_HEADER_Passive_balancing_h_
#include <stddef.h>
#include <string.h>
#include "rtw_modelmap_simtarget.h"
#ifndef Passive_balancing_COMMON_INCLUDES_
#define Passive_balancing_COMMON_INCLUDES_
#include <stdlib.h>
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "sigstream_rtw.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "raccel.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "rt_logging_simtarget.h"
#include "dt_info.h"
#include "ext_work.h"
#endif
#include "Passive_balancing_types.h"
#include "multiword_types.h"
#include "rt_zcfcn.h"
#include "mwmathutil.h"
#include "rtGetInf.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
#define MODEL_NAME Passive_balancing
#define NSAMPLE_TIMES (3) 
#define NINPUTS (0)       
#define NOUTPUTS (0)     
#define NBLOCKIO (149) 
#define NUM_ZC_EVENTS (3) 
#ifndef NCSTATES
#define NCSTATES (12)   
#elif NCSTATES != 12
#error Invalid specification of NCSTATES defined in compiler command
#endif
#ifndef rtmGetDataMapInfo
#define rtmGetDataMapInfo(rtm) (*rt_dataMapInfoPtr)
#endif
#ifndef rtmSetDataMapInfo
#define rtmSetDataMapInfo(rtm, val) (rt_dataMapInfoPtr = &val)
#endif
#ifndef IN_RACCEL_MAIN
#endif
typedef struct { real_T brzjamghps ; real_T jw451fwnvv ; real_T hnt3ftc4mk ;
real_T eu3o5g1x2r ; real_T d5an0i50bp ; real_T kharh1onr2 ; real_T gdglp05luq
; real_T iyfasljzji ; real_T kid3xl3flw ; real_T orby2ps5pm ; real_T
p03chjpubi ; real_T datxyxwqsn ; real_T hag5fa5wq5 ; real_T irwvsmo3n1 ;
real_T m2x5nkxt2s ; real_T nigeuue53d ; real_T prvd12bttp ; real_T ghz5b1e3e3
; real_T h5exb04soq ; real_T huvwhwqywz ; real_T iomwh2g1s2 ; real_T
gzlt4xylvw ; real_T bmrka5l5eq ; real_T bkaepijqzl ; real_T h22uhfy2kg ;
real_T jzumqygy01 ; real_T jqep12tdv2 ; real_T f0c2kodzql ; real_T ni5dgzgvxm
; real_T ay355figj3 ; real_T abmum4zdvq ; real_T jjvc40ph1m ; real_T
cdzndnqfwj ; real_T apjpswajes ; real_T nfpqqtt4xe ; real_T osqxc1rnvg ;
real_T cun2lttrzh ; real_T i25z0wvgra ; real_T ehifpgdwjy ; real_T obg0kvwunj
; real_T pvonpaqj1n ; real_T kmx5zhhmnh ; real_T jugdae5134 ; real_T
bjd1txqszf ; real_T j1tsv1iiyg ; real_T gwm55h223z ; real_T k1a40pib50 ;
real_T h1cgh2p3m1 ; real_T me5y00movs ; real_T bfoinkupre ; real_T pdw4w0iukq
; real_T ef23qut0ie ; real_T i0gqr3h53o ; real_T jg4yrqfsjm ; real_T
azy5vdur0y ; real_T ojpg4sgyg2 ; real_T bybzbvcgip ; real_T c0s1abefak ;
real_T nj11lx1qq3 ; real_T ctnsceddfy ; real_T kvfix31cdr ; real_T pkj0c3flun
; real_T alow0u4nsz ; real_T eavnlisxfe ; real_T kixhxo1qh1 ; real_T
ipqjb5oznn ; real_T lersv2nrng ; real_T deqrvibqyf ; real_T kjglqur00l ;
real_T dagypwp03e [ 3 ] ; real_T hkblhik3th [ 6 ] ; real_T ldgus1sr1s ;
real_T pvu3dnbqsl ; real_T glvvn5z0tb ; real_T gnspd531yz ; real_T i0mboczxg1
; real_T alddy4exqt ; real_T l3y1twbqro ; real_T e1vfx4yr0v ; real_T
bxlrmhtp4q ; real_T a4tzm2m5sq ; real_T iuxt2aetva ; real_T abcbugh4lq ;
real_T grdkvtj4al ; real_T g1v4ipxq25 ; real_T apotbg3wx1 ; real_T gbetiytzwl
; real_T bh3gpd01qa ; real_T pnshzpy2e2 ; real_T anyjfk53qp ; real_T
cpfn4adcdj ; real_T asmh3r5xcj ; real_T pwybstq3ra ; real_T gw1zorijkj ;
real_T lt0awrrixb ; real_T njircekp2k ; real_T k1ekc1vsf0 ; real_T cpadzae1y5
; real_T h14foxcrc1 ; real_T j2xpkyat4x ; real_T hys3hftnnd ; real_T
gisoswnzov ; real_T be1yt0sowu ; real_T do3x3pi1jp ; real_T easujerxmm ;
real_T i1ccd4rxd5 ; real_T exhgo3ztsa ; real_T hbdfujedg1 ; real_T oin55b55uz
; real_T fos1jiogax ; real_T lexfemd5s5 [ 4 ] ; real_T bfwytcdw0r [ 4 ] ;
real_T hakcjtbzae [ 4 ] ; real_T kvy1l3feb5 [ 4 ] ; real_T mv3ukrhvwg ;
real_T luiisy1tsz ; real_T pgjbxu0ggf ; real_T gz0xktnhv2 [ 4 ] ; real_T
cpsa2gffjp [ 4 ] ; real_T bpkwyg51d0 [ 4 ] ; real_T k4vv5a5qnd [ 4 ] ; real_T
pzbmqcb4oc ; real_T cgct03fk00 ; real_T haad1hudpr ; real_T cpafwt3ydk [ 4 ]
; real_T fktu3qn43z [ 4 ] ; real_T fpks1og0r3 [ 4 ] ; real_T amiygo4hlk [ 4 ]
; boolean_T oipsn2ext2 ; boolean_T djaii0vejs ; boolean_T onwyx43zfl ;
boolean_T fiehiuyw0k ; boolean_T l0gpduqluz ; boolean_T gyuxlbpm5v ;
boolean_T jdzd4nb0ri ; boolean_T emt33ggwjf ; boolean_T hfuuf2ubg0 ;
boolean_T brbu1ojabk ; boolean_T etmrit0r0u ; boolean_T byn2laotwy ;
boolean_T cfgua3mzpn ; boolean_T o2yv2v00xl ; boolean_T pvm1yyq1x2 ;
boolean_T liehtgeamk ; boolean_T p11j5vzjvf ; boolean_T jlf0hrvb5z ;
boolean_T hoc1uowy0l ; boolean_T ivq3zpd1bd ; boolean_T etnpopllbl ; } B ;
typedef struct { real_T e42aspecmq ; real_T blqbjt0rtj ; real_T nvqz2cg41c ;
real_T f2m3u0xu0r ; real_T nbwsnfqnlk ; real_T doqeveoc11 ; real_T p4t13c2qkh
[ 2 ] ; void * d05nmt3jlb [ 22 ] ; int_T pmmw3kelkp ; int_T pkauuknbee ;
int_T lwuqhty1j2 ; int_T f3xzmv2juc [ 23 ] ; int_T dvjbhtqxmw ; int_T
iyzdqyqxlc ; int_T lzjct3gebg ; int_T nx4kcep112 ; int_T a5hpejqbid ; int_T
e4gutnhgzf ; int_T i45jrqad2t [ 4 ] ; int_T pq0j2opq0v ; int_T gx0nzawyk1 ;
int_T e1fty5bnxj ; int_T addp1g5vdn ; int_T iplu2tul0d ; int_T aztlcwuvj4 ;
boolean_T g3zekubeld ; boolean_T kerw5fyz1o ; boolean_T hzo55z2pdj ;
boolean_T mh4i1la1g4 ; boolean_T jwqn22rjtx ; boolean_T jjnjjs4i01 ;
boolean_T otnlex10rk ; boolean_T nozmgf3fmt ; boolean_T nvbl4ewadw ;
boolean_T filnbm2liy ; boolean_T nakmqyg1s0 ; boolean_T ajr05m0wfh ;
boolean_T i0a3swey5k ; boolean_T ktt1yqpggw ; boolean_T bx2lamoanh ;
boolean_T cz0xtkwtbl ; boolean_T hoowhfzk1u ; boolean_T fr2favuzoz ;
boolean_T lbwvzc51ur ; boolean_T isyxaae0ta ; boolean_T f4biz4rnh4 ;
boolean_T bzi5sp21lh ; boolean_T nghvchwmka ; boolean_T kzhafiuqm5 ;
boolean_T j5wwiwrs0c ; boolean_T hjta2mhewa ; boolean_T i1hse0ipam ;
boolean_T ejfpjeh5m5 ; boolean_T kwwsfqauib ; boolean_T m43xdundri ; } DW ;
typedef struct { real_T llwavd3uol ; real_T ifbj2oqhyc ; real_T ifq0x11cs2 ;
real_T e1x530c3es ; real_T cs01gdjeym ; real_T pfxj2ul3dz ; real_T akpflzngjb
; real_T jmchzhaobx ; real_T otk33ad0ab ; real_T p3nmfmnma0 ; real_T
jws0lo1qo5 ; real_T g004y4jnca ; } X ; typedef struct { real_T llwavd3uol ;
real_T ifbj2oqhyc ; real_T ifq0x11cs2 ; real_T e1x530c3es ; real_T cs01gdjeym
; real_T pfxj2ul3dz ; real_T akpflzngjb ; real_T jmchzhaobx ; real_T
otk33ad0ab ; real_T p3nmfmnma0 ; real_T jws0lo1qo5 ; real_T g004y4jnca ; }
XDot ; typedef struct { boolean_T llwavd3uol ; boolean_T ifbj2oqhyc ;
boolean_T ifq0x11cs2 ; boolean_T e1x530c3es ; boolean_T cs01gdjeym ;
boolean_T pfxj2ul3dz ; boolean_T akpflzngjb ; boolean_T jmchzhaobx ;
boolean_T otk33ad0ab ; boolean_T p3nmfmnma0 ; boolean_T jws0lo1qo5 ;
boolean_T g004y4jnca ; } XDis ; typedef struct { real_T llwavd3uol ; real_T
ifbj2oqhyc ; real_T ifq0x11cs2 ; real_T e1x530c3es ; real_T cs01gdjeym ;
real_T pfxj2ul3dz ; real_T akpflzngjb ; real_T jmchzhaobx ; real_T otk33ad0ab
; real_T p3nmfmnma0 ; real_T jws0lo1qo5 ; real_T g004y4jnca ; } CStateAbsTol
; typedef struct { real_T llwavd3uol ; real_T ifbj2oqhyc ; real_T ifq0x11cs2
; real_T e1x530c3es ; real_T cs01gdjeym ; real_T pfxj2ul3dz ; real_T
akpflzngjb ; real_T jmchzhaobx ; real_T otk33ad0ab ; real_T p3nmfmnma0 ;
real_T jws0lo1qo5 ; real_T g004y4jnca ; } CXPtMin ; typedef struct { real_T
llwavd3uol ; real_T ifbj2oqhyc ; real_T ifq0x11cs2 ; real_T e1x530c3es ;
real_T cs01gdjeym ; real_T pfxj2ul3dz ; real_T akpflzngjb ; real_T jmchzhaobx
; real_T otk33ad0ab ; real_T p3nmfmnma0 ; real_T jws0lo1qo5 ; real_T
g004y4jnca ; } CXPtMax ; typedef struct { real_T fdnslpvls5 ; real_T
g5vbbq1bj0 ; real_T bpdqbd11vl ; real_T nrfk30fotw ; real_T ama1zmqq3c ;
real_T alzaxrhst5 ; real_T mnfw3j5o3b ; real_T o5xc50cadv ; real_T lw0lg3yi2h
; real_T af2kdct1z0 ; real_T mfppydvi44 ; real_T gy5gisvieu ; real_T
hlrpe3mm41 ; real_T bn5ffrb0j4 ; real_T jffp4lkqfd ; real_T jhds2js3yn ;
real_T ikvurn0zq4 ; real_T nhelrozjhs ; real_T bvk5eh2jrf ; real_T o5qmhd1fki
; real_T ls0bmborz4 ; real_T jccksrr2g2 ; real_T fd3dqccwnu ; real_T
eow004kazk ; real_T kknc51hjvv ; real_T pbytzpa1qb ; real_T exlr04veit ;
real_T kaiyuzuht2 ; real_T n0btl3auax ; real_T otybnaqskq ; real_T khd1hzy5hm
; real_T hj1xzckflc ; real_T om3rbhetlw ; real_T i5ekkply22 ; real_T
kccnz43vm4 ; real_T a1glw5qzrz ; real_T mopcnqs0r4 ; real_T mnetvhzfen ;
real_T o1fkf5dcpb ; real_T gfj3zvwrmt ; real_T cgkuls43qd ; real_T jangylcagi
; real_T iiphl5uwrl ; real_T dzzntfzcwt ; real_T psfiklfccd ; real_T
cgtkpgzhce [ 4 ] ; real_T p5eblkyv4j ; real_T i3wttv04da ; real_T lfobpjboni
; real_T jakcquecoz ; real_T fsowuvns4h ; real_T kwufqgroyh ; real_T
crb5yz0hg2 ; real_T mvzyhp2pwm ; real_T k35orq1xu1 ; real_T lm3gdcfn3d ;
real_T mpop54b5qu ; real_T em1gol2bjz ; } ZCV ; typedef struct { ZCSigState
pmftj50xl0 ; ZCSigState abvz0x2czi ; ZCSigState jnr2ivwps5 ; } PrevZCX ;
typedef struct { rtwCAPI_ModelMappingInfo mmi ; } DataMapInfo ; struct P_ {
real_T Battery_BatType ; real_T Battery1_BatType ; real_T Battery2_BatType ;
real_T Constant_Value ; real_T Constant_Value_efypwvyyax ; real_T
Constant_Value_ogegtmkzv0 ; real_T Constant_Value_epq2rsx4ba ; real_T
Constant_Value_h45zreb2fb ; real_T Constant_Value_khiqevv1tc ; real_T
Constant_Value_c5l5x2wrr5 ; real_T Constant_Value_j455eynuld ; real_T
Constant_Value_anxi4ijlqk ; real_T itinit1_InitialCondition ; real_T R2_Gain
; real_T Currentfilter_A ; real_T Currentfilter_C ; real_T
itinit_InitialCondition ; real_T inti_UpperSat ; real_T inti_LowerSat ;
real_T Gain_Gain ; real_T R3_Gain ; real_T Integrator2_IC ; real_T
Saturation_UpperSat ; real_T Saturation_LowerSat ; real_T BAL_A ; real_T
BAL_C ; real_T R1_Gain ; real_T itinit1_InitialCondition_po45v3mmic ; real_T
R2_Gain_axv50jbqfg ; real_T Currentfilter_A_o3r40a2fs0 ; real_T
Currentfilter_C_e5mev0pk52 ; real_T itinit_InitialCondition_mh2yj0opxq ;
real_T inti_UpperSat_ff0nysnmjy ; real_T inti_LowerSat_hzpmw3xl5s ; real_T
Gain_Gain_a4qiy5rws3 ; real_T R3_Gain_hslbhc5rsq ; real_T
Integrator2_IC_iw5ohpmyuz ; real_T Saturation_UpperSat_dr1jmbb0we ; real_T
Saturation_LowerSat_haspwmkdbs ; real_T BAL_A_oad34lr4nf ; real_T
BAL_C_cq3wtorxkj ; real_T R1_Gain_bdgjwewy0w ; real_T
itinit1_InitialCondition_ma1kf4wxow ; real_T R2_Gain_co3b3ev0vv ; real_T
Currentfilter_A_b4s30vlpp5 ; real_T Currentfilter_C_cr1quwu5bc ; real_T
itinit_InitialCondition_ha0g3gbxl1 ; real_T inti_UpperSat_paqyu313at ; real_T
inti_LowerSat_ntmgylsy20 ; real_T Gain_Gain_fhbsryzldc ; real_T
R3_Gain_d3ow5rqpqq ; real_T Integrator2_IC_bg2f3nd4dc ; real_T
Saturation_UpperSat_dcwljnke5m ; real_T Saturation_LowerSat_pt1ot4ctql ;
real_T BAL_A_lpxrnrfk4y ; real_T BAL_C_ekdjgq2enr ; real_T R1_Gain_pckb3sksct
; real_T StateSpace_P1_Size [ 2 ] ; real_T StateSpace_P1 [ 90 ] ; real_T
StateSpace_P2_Size [ 2 ] ; real_T StateSpace_P2 [ 4 ] ; real_T
StateSpace_P3_Size [ 2 ] ; real_T StateSpace_P4_Size [ 2 ] ; real_T
StateSpace_P4 [ 585 ] ; real_T StateSpace_P5_Size [ 2 ] ; real_T
StateSpace_P5 [ 6 ] ; real_T StateSpace_P6_Size [ 2 ] ; real_T StateSpace_P6
[ 3 ] ; real_T StateSpace_P7_Size [ 2 ] ; real_T StateSpace_P7 [ 3 ] ; real_T
StateSpace_P8_Size [ 2 ] ; real_T StateSpace_P8 [ 3 ] ; real_T
StateSpace_P9_Size [ 2 ] ; real_T StateSpace_P9 ; real_T StateSpace_P10_Size
[ 2 ] ; real_T StateSpace_P10 ; real_T R4_Gain ; real_T
Saturation_UpperSat_pcz043fnep ; real_T Saturation_LowerSat_b05y2t0vvl ;
real_T R4_Gain_e51nv5aiyc ; real_T Saturation_UpperSat_p4wbgcsokm ; real_T
Saturation_LowerSat_gdbbvpyvzg ; real_T R4_Gain_djamifkejg ; real_T
Saturation_UpperSat_mldly5fnun ; real_T Saturation_LowerSat_ctz2o0nkl2 ;
real_T donotdeletethisgain_Gain ; real_T Gain4_Gain ; real_T Gain1_Gain ;
real_T Gain2_Gain ; real_T donotdeletethisgain_Gain_ave45anr4u ; real_T
Gain4_Gain_j4eqtusam3 ; real_T Gain1_Gain_dq4vkdpk0h ; real_T
Gain2_Gain_of2pa5ka31 ; real_T donotdeletethisgain_Gain_hhsesvmj2g ; real_T
Gain4_Gain_fxc0qhliat ; real_T Gain1_Gain_erkjggn3zc ; real_T
Gain2_Gain_lnlqortcjb ; real_T qqq_Value ; real_T qqq_Value_fqup2ywv0j ;
real_T qqq_Value_ahsmvvczti ; real_T Constant_Value_jorngiczgp ; real_T
Constant1_Value ; real_T Constant12_Value ; real_T Constant9_Value ; real_T
Constant1_Value_ks0gbwvaxk ; real_T Constant2_Value ; real_T Constant3_Value
; real_T Constant4_Value ; real_T Constant_Value_pfu1thap3i ; real_T
Constant1_Value_h1thd4w1zg ; real_T Constant12_Value_oujd2whfki ; real_T
Constant9_Value_bcezbzp4a1 ; real_T Constant1_Value_ny1xdqiske ; real_T
Constant2_Value_ppmjeluned ; real_T Constant3_Value_kuyjih2run ; real_T
Constant4_Value_om2zghpbx3 ; real_T Constant_Value_no3jct1ds0 ; real_T
Constant1_Value_lyb1tm4os2 ; real_T Constant12_Value_fsrk0ximud ; real_T
Constant9_Value_jb43nlmf1e ; real_T Constant1_Value_d4ob3b25zw ; real_T
Constant2_Value_cymgwomvip ; real_T Constant3_Value_mv2f5w5r3e ; real_T
Constant4_Value_g3r4dndzdn ; } ; extern const char *
RT_MEMORY_ALLOCATION_ERROR ; extern B rtB ; extern X rtX ; extern DW rtDW ;
extern PrevZCX rtPrevZCX ; extern P rtP ; extern mxArray *
mr_Passive_balancing_GetDWork ( ) ; extern void mr_Passive_balancing_SetDWork
( const mxArray * ssDW ) ; extern mxArray *
mr_Passive_balancing_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * Passive_balancing_GetCAPIStaticMap ( void )
; extern SimStruct * const rtS ; extern const int_T gblNumToFiles ; extern
const int_T gblNumFrFiles ; extern const int_T gblNumFrWksBlocks ; extern
rtInportTUtable * gblInportTUtables ; extern const char * gblInportFileName ;
extern const int_T gblNumRootInportBlks ; extern const int_T
gblNumModelInputs ; extern const int_T gblInportDataTypeIdx [ ] ; extern
const int_T gblInportDims [ ] ; extern const int_T gblInportComplex [ ] ;
extern const int_T gblInportInterpoFlag [ ] ; extern const int_T
gblInportContinuous [ ] ; extern const int_T gblParameterTuningTid ; extern
DataMapInfo * rt_dataMapInfoPtr ; extern rtwCAPI_ModelMappingInfo *
rt_modelMapInfoPtr ; void MdlOutputs ( int_T tid ) ; void
MdlOutputsParameterSampleTime ( int_T tid ) ; void MdlUpdate ( int_T tid ) ;
void MdlTerminate ( void ) ; void MdlInitializeSizes ( void ) ; void
MdlInitializeSampleTimes ( void ) ; SimStruct * raccel_register_model (
ssExecutionInfo * executionInfo ) ;
#endif
