#ifndef RTW_HEADER_Passive_balancing_capi_h
#define RTW_HEADER_Passive_balancing_capi_h
#include "Passive_balancing.h"
extern void Passive_balancing_InitializeDataMapInfo ( void ) ;
#endif
