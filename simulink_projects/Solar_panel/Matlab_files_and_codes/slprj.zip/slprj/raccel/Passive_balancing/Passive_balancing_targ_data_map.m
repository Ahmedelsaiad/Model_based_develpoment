  function targMap = targDataMap(),

  ;%***********************
  ;% Create Parameter Map *
  ;%***********************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 1;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc paramMap
    ;%
    paramMap.nSections           = nTotSects;
    paramMap.sectIdxOffset       = sectIdxOffset;
      paramMap.sections(nTotSects) = dumSection; %prealloc
    paramMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtP)
    ;%
      section.nData     = 124;
      section.data(124)  = dumData; %prealloc
      
	  ;% rtP.Battery_BatType
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtP.Battery1_BatType
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtP.Battery2_BatType
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtP.Constant_Value
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtP.Constant_Value_efypwvyyax
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtP.Constant_Value_ogegtmkzv0
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtP.Constant_Value_epq2rsx4ba
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtP.Constant_Value_h45zreb2fb
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtP.Constant_Value_khiqevv1tc
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtP.Constant_Value_c5l5x2wrr5
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtP.Constant_Value_j455eynuld
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtP.Constant_Value_anxi4ijlqk
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtP.itinit1_InitialCondition
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtP.R2_Gain
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 13;
	
	  ;% rtP.Currentfilter_A
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 14;
	
	  ;% rtP.Currentfilter_C
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 15;
	
	  ;% rtP.itinit_InitialCondition
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 16;
	
	  ;% rtP.inti_UpperSat
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 17;
	
	  ;% rtP.inti_LowerSat
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 18;
	
	  ;% rtP.Gain_Gain
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 19;
	
	  ;% rtP.R3_Gain
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 20;
	
	  ;% rtP.Integrator2_IC
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 21;
	
	  ;% rtP.Saturation_UpperSat
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 22;
	
	  ;% rtP.Saturation_LowerSat
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 23;
	
	  ;% rtP.BAL_A
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 24;
	
	  ;% rtP.BAL_C
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 25;
	
	  ;% rtP.R1_Gain
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 26;
	
	  ;% rtP.itinit1_InitialCondition_po45v3mmic
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 27;
	
	  ;% rtP.R2_Gain_axv50jbqfg
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 28;
	
	  ;% rtP.Currentfilter_A_o3r40a2fs0
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 29;
	
	  ;% rtP.Currentfilter_C_e5mev0pk52
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 30;
	
	  ;% rtP.itinit_InitialCondition_mh2yj0opxq
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 31;
	
	  ;% rtP.inti_UpperSat_ff0nysnmjy
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 32;
	
	  ;% rtP.inti_LowerSat_hzpmw3xl5s
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 33;
	
	  ;% rtP.Gain_Gain_a4qiy5rws3
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 34;
	
	  ;% rtP.R3_Gain_hslbhc5rsq
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 35;
	
	  ;% rtP.Integrator2_IC_iw5ohpmyuz
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 36;
	
	  ;% rtP.Saturation_UpperSat_dr1jmbb0we
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 37;
	
	  ;% rtP.Saturation_LowerSat_haspwmkdbs
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 38;
	
	  ;% rtP.BAL_A_oad34lr4nf
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 39;
	
	  ;% rtP.BAL_C_cq3wtorxkj
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 40;
	
	  ;% rtP.R1_Gain_bdgjwewy0w
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 41;
	
	  ;% rtP.itinit1_InitialCondition_ma1kf4wxow
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 42;
	
	  ;% rtP.R2_Gain_co3b3ev0vv
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 43;
	
	  ;% rtP.Currentfilter_A_b4s30vlpp5
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 44;
	
	  ;% rtP.Currentfilter_C_cr1quwu5bc
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 45;
	
	  ;% rtP.itinit_InitialCondition_ha0g3gbxl1
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 46;
	
	  ;% rtP.inti_UpperSat_paqyu313at
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 47;
	
	  ;% rtP.inti_LowerSat_ntmgylsy20
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 48;
	
	  ;% rtP.Gain_Gain_fhbsryzldc
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 49;
	
	  ;% rtP.R3_Gain_d3ow5rqpqq
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 50;
	
	  ;% rtP.Integrator2_IC_bg2f3nd4dc
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 51;
	
	  ;% rtP.Saturation_UpperSat_dcwljnke5m
	  section.data(53).logicalSrcIdx = 52;
	  section.data(53).dtTransOffset = 52;
	
	  ;% rtP.Saturation_LowerSat_pt1ot4ctql
	  section.data(54).logicalSrcIdx = 53;
	  section.data(54).dtTransOffset = 53;
	
	  ;% rtP.BAL_A_lpxrnrfk4y
	  section.data(55).logicalSrcIdx = 54;
	  section.data(55).dtTransOffset = 54;
	
	  ;% rtP.BAL_C_ekdjgq2enr
	  section.data(56).logicalSrcIdx = 55;
	  section.data(56).dtTransOffset = 55;
	
	  ;% rtP.R1_Gain_pckb3sksct
	  section.data(57).logicalSrcIdx = 56;
	  section.data(57).dtTransOffset = 56;
	
	  ;% rtP.StateSpace_P1_Size
	  section.data(58).logicalSrcIdx = 57;
	  section.data(58).dtTransOffset = 57;
	
	  ;% rtP.StateSpace_P1
	  section.data(59).logicalSrcIdx = 58;
	  section.data(59).dtTransOffset = 59;
	
	  ;% rtP.StateSpace_P2_Size
	  section.data(60).logicalSrcIdx = 59;
	  section.data(60).dtTransOffset = 149;
	
	  ;% rtP.StateSpace_P2
	  section.data(61).logicalSrcIdx = 60;
	  section.data(61).dtTransOffset = 151;
	
	  ;% rtP.StateSpace_P3_Size
	  section.data(62).logicalSrcIdx = 61;
	  section.data(62).dtTransOffset = 155;
	
	  ;% rtP.StateSpace_P4_Size
	  section.data(63).logicalSrcIdx = 63;
	  section.data(63).dtTransOffset = 157;
	
	  ;% rtP.StateSpace_P4
	  section.data(64).logicalSrcIdx = 64;
	  section.data(64).dtTransOffset = 159;
	
	  ;% rtP.StateSpace_P5_Size
	  section.data(65).logicalSrcIdx = 65;
	  section.data(65).dtTransOffset = 744;
	
	  ;% rtP.StateSpace_P5
	  section.data(66).logicalSrcIdx = 66;
	  section.data(66).dtTransOffset = 746;
	
	  ;% rtP.StateSpace_P6_Size
	  section.data(67).logicalSrcIdx = 67;
	  section.data(67).dtTransOffset = 752;
	
	  ;% rtP.StateSpace_P6
	  section.data(68).logicalSrcIdx = 68;
	  section.data(68).dtTransOffset = 754;
	
	  ;% rtP.StateSpace_P7_Size
	  section.data(69).logicalSrcIdx = 69;
	  section.data(69).dtTransOffset = 757;
	
	  ;% rtP.StateSpace_P7
	  section.data(70).logicalSrcIdx = 70;
	  section.data(70).dtTransOffset = 759;
	
	  ;% rtP.StateSpace_P8_Size
	  section.data(71).logicalSrcIdx = 71;
	  section.data(71).dtTransOffset = 762;
	
	  ;% rtP.StateSpace_P8
	  section.data(72).logicalSrcIdx = 72;
	  section.data(72).dtTransOffset = 764;
	
	  ;% rtP.StateSpace_P9_Size
	  section.data(73).logicalSrcIdx = 73;
	  section.data(73).dtTransOffset = 767;
	
	  ;% rtP.StateSpace_P9
	  section.data(74).logicalSrcIdx = 74;
	  section.data(74).dtTransOffset = 769;
	
	  ;% rtP.StateSpace_P10_Size
	  section.data(75).logicalSrcIdx = 75;
	  section.data(75).dtTransOffset = 770;
	
	  ;% rtP.StateSpace_P10
	  section.data(76).logicalSrcIdx = 76;
	  section.data(76).dtTransOffset = 772;
	
	  ;% rtP.R4_Gain
	  section.data(77).logicalSrcIdx = 77;
	  section.data(77).dtTransOffset = 773;
	
	  ;% rtP.Saturation_UpperSat_pcz043fnep
	  section.data(78).logicalSrcIdx = 78;
	  section.data(78).dtTransOffset = 774;
	
	  ;% rtP.Saturation_LowerSat_b05y2t0vvl
	  section.data(79).logicalSrcIdx = 79;
	  section.data(79).dtTransOffset = 775;
	
	  ;% rtP.R4_Gain_e51nv5aiyc
	  section.data(80).logicalSrcIdx = 80;
	  section.data(80).dtTransOffset = 776;
	
	  ;% rtP.Saturation_UpperSat_p4wbgcsokm
	  section.data(81).logicalSrcIdx = 81;
	  section.data(81).dtTransOffset = 777;
	
	  ;% rtP.Saturation_LowerSat_gdbbvpyvzg
	  section.data(82).logicalSrcIdx = 82;
	  section.data(82).dtTransOffset = 778;
	
	  ;% rtP.R4_Gain_djamifkejg
	  section.data(83).logicalSrcIdx = 83;
	  section.data(83).dtTransOffset = 779;
	
	  ;% rtP.Saturation_UpperSat_mldly5fnun
	  section.data(84).logicalSrcIdx = 84;
	  section.data(84).dtTransOffset = 780;
	
	  ;% rtP.Saturation_LowerSat_ctz2o0nkl2
	  section.data(85).logicalSrcIdx = 85;
	  section.data(85).dtTransOffset = 781;
	
	  ;% rtP.donotdeletethisgain_Gain
	  section.data(86).logicalSrcIdx = 86;
	  section.data(86).dtTransOffset = 782;
	
	  ;% rtP.Gain4_Gain
	  section.data(87).logicalSrcIdx = 87;
	  section.data(87).dtTransOffset = 783;
	
	  ;% rtP.Gain1_Gain
	  section.data(88).logicalSrcIdx = 88;
	  section.data(88).dtTransOffset = 784;
	
	  ;% rtP.Gain2_Gain
	  section.data(89).logicalSrcIdx = 89;
	  section.data(89).dtTransOffset = 785;
	
	  ;% rtP.donotdeletethisgain_Gain_ave45anr4u
	  section.data(90).logicalSrcIdx = 90;
	  section.data(90).dtTransOffset = 786;
	
	  ;% rtP.Gain4_Gain_j4eqtusam3
	  section.data(91).logicalSrcIdx = 91;
	  section.data(91).dtTransOffset = 787;
	
	  ;% rtP.Gain1_Gain_dq4vkdpk0h
	  section.data(92).logicalSrcIdx = 92;
	  section.data(92).dtTransOffset = 788;
	
	  ;% rtP.Gain2_Gain_of2pa5ka31
	  section.data(93).logicalSrcIdx = 93;
	  section.data(93).dtTransOffset = 789;
	
	  ;% rtP.donotdeletethisgain_Gain_hhsesvmj2g
	  section.data(94).logicalSrcIdx = 94;
	  section.data(94).dtTransOffset = 790;
	
	  ;% rtP.Gain4_Gain_fxc0qhliat
	  section.data(95).logicalSrcIdx = 95;
	  section.data(95).dtTransOffset = 791;
	
	  ;% rtP.Gain1_Gain_erkjggn3zc
	  section.data(96).logicalSrcIdx = 96;
	  section.data(96).dtTransOffset = 792;
	
	  ;% rtP.Gain2_Gain_lnlqortcjb
	  section.data(97).logicalSrcIdx = 97;
	  section.data(97).dtTransOffset = 793;
	
	  ;% rtP.qqq_Value
	  section.data(98).logicalSrcIdx = 98;
	  section.data(98).dtTransOffset = 794;
	
	  ;% rtP.qqq_Value_fqup2ywv0j
	  section.data(99).logicalSrcIdx = 99;
	  section.data(99).dtTransOffset = 795;
	
	  ;% rtP.qqq_Value_ahsmvvczti
	  section.data(100).logicalSrcIdx = 100;
	  section.data(100).dtTransOffset = 796;
	
	  ;% rtP.Constant_Value_jorngiczgp
	  section.data(101).logicalSrcIdx = 101;
	  section.data(101).dtTransOffset = 797;
	
	  ;% rtP.Constant1_Value
	  section.data(102).logicalSrcIdx = 102;
	  section.data(102).dtTransOffset = 798;
	
	  ;% rtP.Constant12_Value
	  section.data(103).logicalSrcIdx = 103;
	  section.data(103).dtTransOffset = 799;
	
	  ;% rtP.Constant9_Value
	  section.data(104).logicalSrcIdx = 104;
	  section.data(104).dtTransOffset = 800;
	
	  ;% rtP.Constant1_Value_ks0gbwvaxk
	  section.data(105).logicalSrcIdx = 105;
	  section.data(105).dtTransOffset = 801;
	
	  ;% rtP.Constant2_Value
	  section.data(106).logicalSrcIdx = 106;
	  section.data(106).dtTransOffset = 802;
	
	  ;% rtP.Constant3_Value
	  section.data(107).logicalSrcIdx = 107;
	  section.data(107).dtTransOffset = 803;
	
	  ;% rtP.Constant4_Value
	  section.data(108).logicalSrcIdx = 108;
	  section.data(108).dtTransOffset = 804;
	
	  ;% rtP.Constant_Value_pfu1thap3i
	  section.data(109).logicalSrcIdx = 109;
	  section.data(109).dtTransOffset = 805;
	
	  ;% rtP.Constant1_Value_h1thd4w1zg
	  section.data(110).logicalSrcIdx = 110;
	  section.data(110).dtTransOffset = 806;
	
	  ;% rtP.Constant12_Value_oujd2whfki
	  section.data(111).logicalSrcIdx = 111;
	  section.data(111).dtTransOffset = 807;
	
	  ;% rtP.Constant9_Value_bcezbzp4a1
	  section.data(112).logicalSrcIdx = 112;
	  section.data(112).dtTransOffset = 808;
	
	  ;% rtP.Constant1_Value_ny1xdqiske
	  section.data(113).logicalSrcIdx = 113;
	  section.data(113).dtTransOffset = 809;
	
	  ;% rtP.Constant2_Value_ppmjeluned
	  section.data(114).logicalSrcIdx = 114;
	  section.data(114).dtTransOffset = 810;
	
	  ;% rtP.Constant3_Value_kuyjih2run
	  section.data(115).logicalSrcIdx = 115;
	  section.data(115).dtTransOffset = 811;
	
	  ;% rtP.Constant4_Value_om2zghpbx3
	  section.data(116).logicalSrcIdx = 116;
	  section.data(116).dtTransOffset = 812;
	
	  ;% rtP.Constant_Value_no3jct1ds0
	  section.data(117).logicalSrcIdx = 117;
	  section.data(117).dtTransOffset = 813;
	
	  ;% rtP.Constant1_Value_lyb1tm4os2
	  section.data(118).logicalSrcIdx = 118;
	  section.data(118).dtTransOffset = 814;
	
	  ;% rtP.Constant12_Value_fsrk0ximud
	  section.data(119).logicalSrcIdx = 119;
	  section.data(119).dtTransOffset = 815;
	
	  ;% rtP.Constant9_Value_jb43nlmf1e
	  section.data(120).logicalSrcIdx = 120;
	  section.data(120).dtTransOffset = 816;
	
	  ;% rtP.Constant1_Value_d4ob3b25zw
	  section.data(121).logicalSrcIdx = 121;
	  section.data(121).dtTransOffset = 817;
	
	  ;% rtP.Constant2_Value_cymgwomvip
	  section.data(122).logicalSrcIdx = 122;
	  section.data(122).dtTransOffset = 818;
	
	  ;% rtP.Constant3_Value_mv2f5w5r3e
	  section.data(123).logicalSrcIdx = 123;
	  section.data(123).dtTransOffset = 819;
	
	  ;% rtP.Constant4_Value_g3r4dndzdn
	  section.data(124).logicalSrcIdx = 124;
	  section.data(124).dtTransOffset = 820;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(1) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (parameter)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    paramMap.nTotData = nTotData;
    


  ;%**************************
  ;% Create Block Output Map *
  ;%**************************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 2;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc sigMap
    ;%
    sigMap.nSections           = nTotSects;
    sigMap.sectIdxOffset       = sectIdxOffset;
      sigMap.sections(nTotSects) = dumSection; %prealloc
    sigMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtB)
    ;%
      section.nData     = 128;
      section.data(128)  = dumData; %prealloc
      
	  ;% rtB.brzjamghps
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.jw451fwnvv
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtB.hnt3ftc4mk
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtB.eu3o5g1x2r
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtB.d5an0i50bp
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtB.kharh1onr2
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtB.gdglp05luq
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtB.iyfasljzji
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtB.kid3xl3flw
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtB.orby2ps5pm
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtB.p03chjpubi
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtB.datxyxwqsn
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtB.hag5fa5wq5
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtB.irwvsmo3n1
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 13;
	
	  ;% rtB.m2x5nkxt2s
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 14;
	
	  ;% rtB.nigeuue53d
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 15;
	
	  ;% rtB.prvd12bttp
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 16;
	
	  ;% rtB.ghz5b1e3e3
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 17;
	
	  ;% rtB.h5exb04soq
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 18;
	
	  ;% rtB.huvwhwqywz
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 19;
	
	  ;% rtB.iomwh2g1s2
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 20;
	
	  ;% rtB.gzlt4xylvw
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 21;
	
	  ;% rtB.bmrka5l5eq
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 22;
	
	  ;% rtB.bkaepijqzl
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 23;
	
	  ;% rtB.h22uhfy2kg
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 24;
	
	  ;% rtB.jzumqygy01
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 25;
	
	  ;% rtB.jqep12tdv2
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 26;
	
	  ;% rtB.f0c2kodzql
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 27;
	
	  ;% rtB.ni5dgzgvxm
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 28;
	
	  ;% rtB.ay355figj3
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 29;
	
	  ;% rtB.abmum4zdvq
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 30;
	
	  ;% rtB.jjvc40ph1m
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 31;
	
	  ;% rtB.cdzndnqfwj
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 32;
	
	  ;% rtB.apjpswajes
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 33;
	
	  ;% rtB.nfpqqtt4xe
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 34;
	
	  ;% rtB.osqxc1rnvg
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 35;
	
	  ;% rtB.cun2lttrzh
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 36;
	
	  ;% rtB.i25z0wvgra
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 37;
	
	  ;% rtB.ehifpgdwjy
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 38;
	
	  ;% rtB.obg0kvwunj
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 39;
	
	  ;% rtB.pvonpaqj1n
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 40;
	
	  ;% rtB.kmx5zhhmnh
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 41;
	
	  ;% rtB.jugdae5134
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 42;
	
	  ;% rtB.bjd1txqszf
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 43;
	
	  ;% rtB.j1tsv1iiyg
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 44;
	
	  ;% rtB.gwm55h223z
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 45;
	
	  ;% rtB.k1a40pib50
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 46;
	
	  ;% rtB.h1cgh2p3m1
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 47;
	
	  ;% rtB.me5y00movs
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 48;
	
	  ;% rtB.bfoinkupre
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 49;
	
	  ;% rtB.pdw4w0iukq
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 50;
	
	  ;% rtB.ef23qut0ie
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 51;
	
	  ;% rtB.i0gqr3h53o
	  section.data(53).logicalSrcIdx = 52;
	  section.data(53).dtTransOffset = 52;
	
	  ;% rtB.jg4yrqfsjm
	  section.data(54).logicalSrcIdx = 53;
	  section.data(54).dtTransOffset = 53;
	
	  ;% rtB.azy5vdur0y
	  section.data(55).logicalSrcIdx = 54;
	  section.data(55).dtTransOffset = 54;
	
	  ;% rtB.ojpg4sgyg2
	  section.data(56).logicalSrcIdx = 55;
	  section.data(56).dtTransOffset = 55;
	
	  ;% rtB.bybzbvcgip
	  section.data(57).logicalSrcIdx = 56;
	  section.data(57).dtTransOffset = 56;
	
	  ;% rtB.c0s1abefak
	  section.data(58).logicalSrcIdx = 57;
	  section.data(58).dtTransOffset = 57;
	
	  ;% rtB.nj11lx1qq3
	  section.data(59).logicalSrcIdx = 58;
	  section.data(59).dtTransOffset = 58;
	
	  ;% rtB.ctnsceddfy
	  section.data(60).logicalSrcIdx = 59;
	  section.data(60).dtTransOffset = 59;
	
	  ;% rtB.kvfix31cdr
	  section.data(61).logicalSrcIdx = 60;
	  section.data(61).dtTransOffset = 60;
	
	  ;% rtB.pkj0c3flun
	  section.data(62).logicalSrcIdx = 61;
	  section.data(62).dtTransOffset = 61;
	
	  ;% rtB.alow0u4nsz
	  section.data(63).logicalSrcIdx = 62;
	  section.data(63).dtTransOffset = 62;
	
	  ;% rtB.eavnlisxfe
	  section.data(64).logicalSrcIdx = 63;
	  section.data(64).dtTransOffset = 63;
	
	  ;% rtB.kixhxo1qh1
	  section.data(65).logicalSrcIdx = 64;
	  section.data(65).dtTransOffset = 64;
	
	  ;% rtB.ipqjb5oznn
	  section.data(66).logicalSrcIdx = 65;
	  section.data(66).dtTransOffset = 65;
	
	  ;% rtB.lersv2nrng
	  section.data(67).logicalSrcIdx = 66;
	  section.data(67).dtTransOffset = 66;
	
	  ;% rtB.deqrvibqyf
	  section.data(68).logicalSrcIdx = 67;
	  section.data(68).dtTransOffset = 67;
	
	  ;% rtB.kjglqur00l
	  section.data(69).logicalSrcIdx = 68;
	  section.data(69).dtTransOffset = 68;
	
	  ;% rtB.dagypwp03e
	  section.data(70).logicalSrcIdx = 69;
	  section.data(70).dtTransOffset = 69;
	
	  ;% rtB.hkblhik3th
	  section.data(71).logicalSrcIdx = 70;
	  section.data(71).dtTransOffset = 72;
	
	  ;% rtB.ldgus1sr1s
	  section.data(72).logicalSrcIdx = 71;
	  section.data(72).dtTransOffset = 78;
	
	  ;% rtB.pvu3dnbqsl
	  section.data(73).logicalSrcIdx = 72;
	  section.data(73).dtTransOffset = 79;
	
	  ;% rtB.glvvn5z0tb
	  section.data(74).logicalSrcIdx = 73;
	  section.data(74).dtTransOffset = 80;
	
	  ;% rtB.gnspd531yz
	  section.data(75).logicalSrcIdx = 74;
	  section.data(75).dtTransOffset = 81;
	
	  ;% rtB.i0mboczxg1
	  section.data(76).logicalSrcIdx = 75;
	  section.data(76).dtTransOffset = 82;
	
	  ;% rtB.alddy4exqt
	  section.data(77).logicalSrcIdx = 76;
	  section.data(77).dtTransOffset = 83;
	
	  ;% rtB.l3y1twbqro
	  section.data(78).logicalSrcIdx = 77;
	  section.data(78).dtTransOffset = 84;
	
	  ;% rtB.e1vfx4yr0v
	  section.data(79).logicalSrcIdx = 78;
	  section.data(79).dtTransOffset = 85;
	
	  ;% rtB.bxlrmhtp4q
	  section.data(80).logicalSrcIdx = 79;
	  section.data(80).dtTransOffset = 86;
	
	  ;% rtB.a4tzm2m5sq
	  section.data(81).logicalSrcIdx = 80;
	  section.data(81).dtTransOffset = 87;
	
	  ;% rtB.iuxt2aetva
	  section.data(82).logicalSrcIdx = 81;
	  section.data(82).dtTransOffset = 88;
	
	  ;% rtB.abcbugh4lq
	  section.data(83).logicalSrcIdx = 82;
	  section.data(83).dtTransOffset = 89;
	
	  ;% rtB.grdkvtj4al
	  section.data(84).logicalSrcIdx = 83;
	  section.data(84).dtTransOffset = 90;
	
	  ;% rtB.g1v4ipxq25
	  section.data(85).logicalSrcIdx = 84;
	  section.data(85).dtTransOffset = 91;
	
	  ;% rtB.apotbg3wx1
	  section.data(86).logicalSrcIdx = 85;
	  section.data(86).dtTransOffset = 92;
	
	  ;% rtB.gbetiytzwl
	  section.data(87).logicalSrcIdx = 86;
	  section.data(87).dtTransOffset = 93;
	
	  ;% rtB.bh3gpd01qa
	  section.data(88).logicalSrcIdx = 87;
	  section.data(88).dtTransOffset = 94;
	
	  ;% rtB.pnshzpy2e2
	  section.data(89).logicalSrcIdx = 88;
	  section.data(89).dtTransOffset = 95;
	
	  ;% rtB.anyjfk53qp
	  section.data(90).logicalSrcIdx = 89;
	  section.data(90).dtTransOffset = 96;
	
	  ;% rtB.cpfn4adcdj
	  section.data(91).logicalSrcIdx = 90;
	  section.data(91).dtTransOffset = 97;
	
	  ;% rtB.asmh3r5xcj
	  section.data(92).logicalSrcIdx = 91;
	  section.data(92).dtTransOffset = 98;
	
	  ;% rtB.pwybstq3ra
	  section.data(93).logicalSrcIdx = 92;
	  section.data(93).dtTransOffset = 99;
	
	  ;% rtB.gw1zorijkj
	  section.data(94).logicalSrcIdx = 93;
	  section.data(94).dtTransOffset = 100;
	
	  ;% rtB.lt0awrrixb
	  section.data(95).logicalSrcIdx = 94;
	  section.data(95).dtTransOffset = 101;
	
	  ;% rtB.njircekp2k
	  section.data(96).logicalSrcIdx = 95;
	  section.data(96).dtTransOffset = 102;
	
	  ;% rtB.k1ekc1vsf0
	  section.data(97).logicalSrcIdx = 96;
	  section.data(97).dtTransOffset = 103;
	
	  ;% rtB.cpadzae1y5
	  section.data(98).logicalSrcIdx = 97;
	  section.data(98).dtTransOffset = 104;
	
	  ;% rtB.h14foxcrc1
	  section.data(99).logicalSrcIdx = 98;
	  section.data(99).dtTransOffset = 105;
	
	  ;% rtB.j2xpkyat4x
	  section.data(100).logicalSrcIdx = 99;
	  section.data(100).dtTransOffset = 106;
	
	  ;% rtB.hys3hftnnd
	  section.data(101).logicalSrcIdx = 100;
	  section.data(101).dtTransOffset = 107;
	
	  ;% rtB.gisoswnzov
	  section.data(102).logicalSrcIdx = 101;
	  section.data(102).dtTransOffset = 108;
	
	  ;% rtB.be1yt0sowu
	  section.data(103).logicalSrcIdx = 102;
	  section.data(103).dtTransOffset = 109;
	
	  ;% rtB.do3x3pi1jp
	  section.data(104).logicalSrcIdx = 103;
	  section.data(104).dtTransOffset = 110;
	
	  ;% rtB.easujerxmm
	  section.data(105).logicalSrcIdx = 104;
	  section.data(105).dtTransOffset = 111;
	
	  ;% rtB.i1ccd4rxd5
	  section.data(106).logicalSrcIdx = 105;
	  section.data(106).dtTransOffset = 112;
	
	  ;% rtB.exhgo3ztsa
	  section.data(107).logicalSrcIdx = 106;
	  section.data(107).dtTransOffset = 113;
	
	  ;% rtB.hbdfujedg1
	  section.data(108).logicalSrcIdx = 107;
	  section.data(108).dtTransOffset = 114;
	
	  ;% rtB.oin55b55uz
	  section.data(109).logicalSrcIdx = 108;
	  section.data(109).dtTransOffset = 115;
	
	  ;% rtB.fos1jiogax
	  section.data(110).logicalSrcIdx = 109;
	  section.data(110).dtTransOffset = 116;
	
	  ;% rtB.lexfemd5s5
	  section.data(111).logicalSrcIdx = 110;
	  section.data(111).dtTransOffset = 117;
	
	  ;% rtB.bfwytcdw0r
	  section.data(112).logicalSrcIdx = 111;
	  section.data(112).dtTransOffset = 121;
	
	  ;% rtB.hakcjtbzae
	  section.data(113).logicalSrcIdx = 112;
	  section.data(113).dtTransOffset = 125;
	
	  ;% rtB.kvy1l3feb5
	  section.data(114).logicalSrcIdx = 113;
	  section.data(114).dtTransOffset = 129;
	
	  ;% rtB.mv3ukrhvwg
	  section.data(115).logicalSrcIdx = 114;
	  section.data(115).dtTransOffset = 133;
	
	  ;% rtB.luiisy1tsz
	  section.data(116).logicalSrcIdx = 115;
	  section.data(116).dtTransOffset = 134;
	
	  ;% rtB.pgjbxu0ggf
	  section.data(117).logicalSrcIdx = 116;
	  section.data(117).dtTransOffset = 135;
	
	  ;% rtB.gz0xktnhv2
	  section.data(118).logicalSrcIdx = 117;
	  section.data(118).dtTransOffset = 136;
	
	  ;% rtB.cpsa2gffjp
	  section.data(119).logicalSrcIdx = 118;
	  section.data(119).dtTransOffset = 140;
	
	  ;% rtB.bpkwyg51d0
	  section.data(120).logicalSrcIdx = 119;
	  section.data(120).dtTransOffset = 144;
	
	  ;% rtB.k4vv5a5qnd
	  section.data(121).logicalSrcIdx = 120;
	  section.data(121).dtTransOffset = 148;
	
	  ;% rtB.pzbmqcb4oc
	  section.data(122).logicalSrcIdx = 121;
	  section.data(122).dtTransOffset = 152;
	
	  ;% rtB.cgct03fk00
	  section.data(123).logicalSrcIdx = 122;
	  section.data(123).dtTransOffset = 153;
	
	  ;% rtB.haad1hudpr
	  section.data(124).logicalSrcIdx = 123;
	  section.data(124).dtTransOffset = 154;
	
	  ;% rtB.cpafwt3ydk
	  section.data(125).logicalSrcIdx = 124;
	  section.data(125).dtTransOffset = 155;
	
	  ;% rtB.fktu3qn43z
	  section.data(126).logicalSrcIdx = 125;
	  section.data(126).dtTransOffset = 159;
	
	  ;% rtB.fpks1og0r3
	  section.data(127).logicalSrcIdx = 126;
	  section.data(127).dtTransOffset = 163;
	
	  ;% rtB.amiygo4hlk
	  section.data(128).logicalSrcIdx = 127;
	  section.data(128).dtTransOffset = 167;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(1) = section;
      clear section
      
      section.nData     = 21;
      section.data(21)  = dumData; %prealloc
      
	  ;% rtB.oipsn2ext2
	  section.data(1).logicalSrcIdx = 128;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.djaii0vejs
	  section.data(2).logicalSrcIdx = 129;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtB.onwyx43zfl
	  section.data(3).logicalSrcIdx = 130;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtB.fiehiuyw0k
	  section.data(4).logicalSrcIdx = 131;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtB.l0gpduqluz
	  section.data(5).logicalSrcIdx = 132;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtB.gyuxlbpm5v
	  section.data(6).logicalSrcIdx = 133;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtB.jdzd4nb0ri
	  section.data(7).logicalSrcIdx = 134;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtB.emt33ggwjf
	  section.data(8).logicalSrcIdx = 135;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtB.hfuuf2ubg0
	  section.data(9).logicalSrcIdx = 136;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtB.brbu1ojabk
	  section.data(10).logicalSrcIdx = 137;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtB.etmrit0r0u
	  section.data(11).logicalSrcIdx = 138;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtB.byn2laotwy
	  section.data(12).logicalSrcIdx = 139;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtB.cfgua3mzpn
	  section.data(13).logicalSrcIdx = 140;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtB.o2yv2v00xl
	  section.data(14).logicalSrcIdx = 141;
	  section.data(14).dtTransOffset = 13;
	
	  ;% rtB.pvm1yyq1x2
	  section.data(15).logicalSrcIdx = 142;
	  section.data(15).dtTransOffset = 14;
	
	  ;% rtB.liehtgeamk
	  section.data(16).logicalSrcIdx = 143;
	  section.data(16).dtTransOffset = 15;
	
	  ;% rtB.p11j5vzjvf
	  section.data(17).logicalSrcIdx = 144;
	  section.data(17).dtTransOffset = 16;
	
	  ;% rtB.jlf0hrvb5z
	  section.data(18).logicalSrcIdx = 145;
	  section.data(18).dtTransOffset = 17;
	
	  ;% rtB.hoc1uowy0l
	  section.data(19).logicalSrcIdx = 146;
	  section.data(19).dtTransOffset = 18;
	
	  ;% rtB.ivq3zpd1bd
	  section.data(20).logicalSrcIdx = 147;
	  section.data(20).dtTransOffset = 19;
	
	  ;% rtB.etnpopllbl
	  section.data(21).logicalSrcIdx = 148;
	  section.data(21).dtTransOffset = 20;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(2) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (signal)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    sigMap.nTotData = nTotData;
    


  ;%*******************
  ;% Create DWork Map *
  ;%*******************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 4;
    sectIdxOffset = 2;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc dworkMap
    ;%
    dworkMap.nSections           = nTotSects;
    dworkMap.sectIdxOffset       = sectIdxOffset;
      dworkMap.sections(nTotSects) = dumSection; %prealloc
    dworkMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtDW)
    ;%
      section.nData     = 7;
      section.data(7)  = dumData; %prealloc
      
	  ;% rtDW.e42aspecmq
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.blqbjt0rtj
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.nvqz2cg41c
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.f2m3u0xu0r
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtDW.nbwsnfqnlk
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtDW.doqeveoc11
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtDW.p4t13c2qkh
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(1) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.d05nmt3jlb
	  section.data(1).logicalSrcIdx = 7;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(2) = section;
      clear section
      
      section.nData     = 17;
      section.data(17)  = dumData; %prealloc
      
	  ;% rtDW.pmmw3kelkp
	  section.data(1).logicalSrcIdx = 8;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.pkauuknbee
	  section.data(2).logicalSrcIdx = 9;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.lwuqhty1j2
	  section.data(3).logicalSrcIdx = 10;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.f3xzmv2juc
	  section.data(4).logicalSrcIdx = 11;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtDW.dvjbhtqxmw
	  section.data(5).logicalSrcIdx = 12;
	  section.data(5).dtTransOffset = 26;
	
	  ;% rtDW.iyzdqyqxlc
	  section.data(6).logicalSrcIdx = 13;
	  section.data(6).dtTransOffset = 27;
	
	  ;% rtDW.lzjct3gebg
	  section.data(7).logicalSrcIdx = 14;
	  section.data(7).dtTransOffset = 28;
	
	  ;% rtDW.nx4kcep112
	  section.data(8).logicalSrcIdx = 15;
	  section.data(8).dtTransOffset = 29;
	
	  ;% rtDW.a5hpejqbid
	  section.data(9).logicalSrcIdx = 16;
	  section.data(9).dtTransOffset = 30;
	
	  ;% rtDW.e4gutnhgzf
	  section.data(10).logicalSrcIdx = 17;
	  section.data(10).dtTransOffset = 31;
	
	  ;% rtDW.i45jrqad2t
	  section.data(11).logicalSrcIdx = 18;
	  section.data(11).dtTransOffset = 32;
	
	  ;% rtDW.pq0j2opq0v
	  section.data(12).logicalSrcIdx = 19;
	  section.data(12).dtTransOffset = 36;
	
	  ;% rtDW.gx0nzawyk1
	  section.data(13).logicalSrcIdx = 20;
	  section.data(13).dtTransOffset = 37;
	
	  ;% rtDW.e1fty5bnxj
	  section.data(14).logicalSrcIdx = 21;
	  section.data(14).dtTransOffset = 38;
	
	  ;% rtDW.addp1g5vdn
	  section.data(15).logicalSrcIdx = 22;
	  section.data(15).dtTransOffset = 39;
	
	  ;% rtDW.iplu2tul0d
	  section.data(16).logicalSrcIdx = 23;
	  section.data(16).dtTransOffset = 40;
	
	  ;% rtDW.aztlcwuvj4
	  section.data(17).logicalSrcIdx = 24;
	  section.data(17).dtTransOffset = 41;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(3) = section;
      clear section
      
      section.nData     = 30;
      section.data(30)  = dumData; %prealloc
      
	  ;% rtDW.g3zekubeld
	  section.data(1).logicalSrcIdx = 25;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.kerw5fyz1o
	  section.data(2).logicalSrcIdx = 26;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.hzo55z2pdj
	  section.data(3).logicalSrcIdx = 27;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.mh4i1la1g4
	  section.data(4).logicalSrcIdx = 28;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtDW.jwqn22rjtx
	  section.data(5).logicalSrcIdx = 29;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtDW.jjnjjs4i01
	  section.data(6).logicalSrcIdx = 30;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtDW.otnlex10rk
	  section.data(7).logicalSrcIdx = 31;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtDW.nozmgf3fmt
	  section.data(8).logicalSrcIdx = 32;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtDW.nvbl4ewadw
	  section.data(9).logicalSrcIdx = 33;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtDW.filnbm2liy
	  section.data(10).logicalSrcIdx = 34;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtDW.nakmqyg1s0
	  section.data(11).logicalSrcIdx = 35;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtDW.ajr05m0wfh
	  section.data(12).logicalSrcIdx = 36;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtDW.i0a3swey5k
	  section.data(13).logicalSrcIdx = 37;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtDW.ktt1yqpggw
	  section.data(14).logicalSrcIdx = 38;
	  section.data(14).dtTransOffset = 13;
	
	  ;% rtDW.bx2lamoanh
	  section.data(15).logicalSrcIdx = 39;
	  section.data(15).dtTransOffset = 14;
	
	  ;% rtDW.cz0xtkwtbl
	  section.data(16).logicalSrcIdx = 40;
	  section.data(16).dtTransOffset = 15;
	
	  ;% rtDW.hoowhfzk1u
	  section.data(17).logicalSrcIdx = 41;
	  section.data(17).dtTransOffset = 16;
	
	  ;% rtDW.fr2favuzoz
	  section.data(18).logicalSrcIdx = 42;
	  section.data(18).dtTransOffset = 17;
	
	  ;% rtDW.lbwvzc51ur
	  section.data(19).logicalSrcIdx = 43;
	  section.data(19).dtTransOffset = 18;
	
	  ;% rtDW.isyxaae0ta
	  section.data(20).logicalSrcIdx = 44;
	  section.data(20).dtTransOffset = 19;
	
	  ;% rtDW.f4biz4rnh4
	  section.data(21).logicalSrcIdx = 45;
	  section.data(21).dtTransOffset = 20;
	
	  ;% rtDW.bzi5sp21lh
	  section.data(22).logicalSrcIdx = 46;
	  section.data(22).dtTransOffset = 21;
	
	  ;% rtDW.nghvchwmka
	  section.data(23).logicalSrcIdx = 47;
	  section.data(23).dtTransOffset = 22;
	
	  ;% rtDW.kzhafiuqm5
	  section.data(24).logicalSrcIdx = 48;
	  section.data(24).dtTransOffset = 23;
	
	  ;% rtDW.j5wwiwrs0c
	  section.data(25).logicalSrcIdx = 49;
	  section.data(25).dtTransOffset = 24;
	
	  ;% rtDW.hjta2mhewa
	  section.data(26).logicalSrcIdx = 50;
	  section.data(26).dtTransOffset = 25;
	
	  ;% rtDW.i1hse0ipam
	  section.data(27).logicalSrcIdx = 51;
	  section.data(27).dtTransOffset = 26;
	
	  ;% rtDW.ejfpjeh5m5
	  section.data(28).logicalSrcIdx = 52;
	  section.data(28).dtTransOffset = 27;
	
	  ;% rtDW.kwwsfqauib
	  section.data(29).logicalSrcIdx = 53;
	  section.data(29).dtTransOffset = 28;
	
	  ;% rtDW.m43xdundri
	  section.data(30).logicalSrcIdx = 54;
	  section.data(30).dtTransOffset = 29;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(4) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (dwork)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    dworkMap.nTotData = nTotData;
    


  ;%
  ;% Add individual maps to base struct.
  ;%

  targMap.paramMap  = paramMap;    
  targMap.signalMap = sigMap;
  targMap.dworkMap  = dworkMap;
  
  ;%
  ;% Add checksums to base struct.
  ;%


  targMap.checksum0 = 808582686;
  targMap.checksum1 = 3126849085;
  targMap.checksum2 = 4170160061;
  targMap.checksum3 = 2909507965;

