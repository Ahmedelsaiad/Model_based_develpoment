#include "rt_logging_mmi.h"
#include "Passive_balancing_capi.h"
#include <math.h>
#include "Passive_balancing.h"
#include "Passive_balancing_private.h"
#include "Passive_balancing_dt.h"
#include "sfcn_loader_c_api.h"
extern void * CreateDiagnosticAsVoidPtr_wrapper ( const char * id , int nargs
, ... ) ; RTWExtModeInfo * gblRTWExtModeInfo = NULL ; void
raccelForceExtModeShutdown ( boolean_T extModeStartPktReceived ) { if ( !
extModeStartPktReceived ) { boolean_T stopRequested = false ;
rtExtModeWaitForStartPkt ( gblRTWExtModeInfo , 2 , & stopRequested ) ; }
rtExtModeShutdown ( 2 ) ; }
#include "slsv_diagnostic_codegen_c_api.h"
#include "slsa_sim_engine.h"
const int_T gblNumToFiles = 0 ; const int_T gblNumFrFiles = 0 ; const int_T
gblNumFrWksBlocks = 0 ;
#ifdef RSIM_WITH_SOLVER_MULTITASKING
boolean_T gbl_raccel_isMultitasking = 1 ;
#else
boolean_T gbl_raccel_isMultitasking = 0 ;
#endif
boolean_T gbl_raccel_tid01eq = 0 ; int_T gbl_raccel_NumST = 3 ; const char_T
* gbl_raccel_Version = "9.5 (R2021a) 14-Nov-2020" ; void
raccel_setup_MMIStateLog ( SimStruct * S ) {
#ifdef UseMMIDataLogging
rt_FillStateSigInfoFromMMI ( ssGetRTWLogInfo ( S ) , & ssGetErrorStatus ( S )
) ;
#else
UNUSED_PARAMETER ( S ) ;
#endif
} static DataMapInfo rt_dataMapInfo ; DataMapInfo * rt_dataMapInfoPtr = &
rt_dataMapInfo ; rtwCAPI_ModelMappingInfo * rt_modelMapInfoPtr = & (
rt_dataMapInfo . mmi ) ; const int_T gblNumRootInportBlks = 0 ; const int_T
gblNumModelInputs = 0 ; extern const char * gblInportFileName ; extern
rtInportTUtable * gblInportTUtables ; const int_T gblInportDataTypeIdx [ ] =
{ - 1 } ; const int_T gblInportDims [ ] = { - 1 } ; const int_T
gblInportComplex [ ] = { - 1 } ; const int_T gblInportInterpoFlag [ ] = { - 1
} ; const int_T gblInportContinuous [ ] = { - 1 } ; int_T enableFcnCallFlag [
] = { 1 , 1 , 1 } ; const char * raccelLoadInputsAndAperiodicHitTimes (
SimStruct * S , const char * inportFileName , int * matFileFormat ) { return
rt_RAccelReadInportsMatFile ( S , inportFileName , matFileFormat ) ; }
#include "simstruc.h"
#include "fixedpoint.h"
#include "slsa_sim_engine.h"
#include "simtarget/slSimTgtSLExecSimBridge.h"
B rtB ; X rtX ; DW rtDW ; PrevZCX rtPrevZCX ; static SimStruct model_S ;
SimStruct * const rtS = & model_S ; void MdlInitialize ( void ) { boolean_T
tmp ; rtDW . e42aspecmq = rtP . itinit1_InitialCondition ; rtX . llwavd3uol =
0.0 ; rtDW . blqbjt0rtj = rtP . itinit_InitialCondition ; rtDW . pmmw3kelkp =
1 ; if ( ssIsFirstInitCond ( rtS ) ) { rtX . ifbj2oqhyc = 0.0 ; tmp =
slIsRapidAcceleratorSimulating ( ) ; if ( tmp ) { tmp =
ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . pmmw3kelkp = ! tmp ; }
else { rtDW . pmmw3kelkp = 1 ; } rtX . pfxj2ul3dz = 0.0 ; } rtX . ifq0x11cs2
= rtP . Integrator2_IC ; rtX . e1x530c3es = 0.0 ; rtDW . nvqz2cg41c = rtP .
itinit1_InitialCondition_po45v3mmic ; rtX . cs01gdjeym = 0.0 ; rtDW .
f2m3u0xu0r = rtP . itinit_InitialCondition_mh2yj0opxq ; rtDW . pkauuknbee = 1
; if ( ssIsFirstInitCond ( rtS ) ) { tmp = slIsRapidAcceleratorSimulating ( )
; if ( tmp ) { tmp = ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW .
pkauuknbee = ! tmp ; } else { rtDW . pkauuknbee = 1 ; } rtX . p3nmfmnma0 =
0.0 ; } rtX . akpflzngjb = rtP . Integrator2_IC_iw5ohpmyuz ; rtX . jmchzhaobx
= 0.0 ; rtDW . nbwsnfqnlk = rtP . itinit1_InitialCondition_ma1kf4wxow ; rtX .
otk33ad0ab = 0.0 ; rtDW . doqeveoc11 = rtP .
itinit_InitialCondition_ha0g3gbxl1 ; rtDW . lwuqhty1j2 = 1 ; if (
ssIsFirstInitCond ( rtS ) ) { tmp = slIsRapidAcceleratorSimulating ( ) ; if (
tmp ) { tmp = ssGetGlobalInitialStatesAvailable ( rtS ) ; rtDW . lwuqhty1j2 =
! tmp ; } else { rtDW . lwuqhty1j2 = 1 ; } } rtX . jws0lo1qo5 = rtP .
Integrator2_IC_bg2f3nd4dc ; rtX . g004y4jnca = 0.0 ; { SimStruct * rts =
ssGetSFunction ( rtS , 0 ) ; sfcnInitializeConditions ( rts ) ; if (
ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } } void MdlStart ( void ) {
{ bool externalInputIsInDatasetFormat = false ; void * pISigstreamManager =
rt_GetISigstreamManager ( rtS ) ;
rtwISigstreamManagerGetInputIsInDatasetFormat ( pISigstreamManager , &
externalInputIsInDatasetFormat ) ; if ( externalInputIsInDatasetFormat ) { }
} { SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; sfcnStart ( rts ) ; if (
ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } MdlInitialize ( ) ; } void
MdlOutputs ( int_T tid ) { real_T jmuz0todoh ; real_T k0qu5tzxih ; boolean_T
tmp ; ZCEventType zcEvent ; rtB . eu3o5g1x2r = 0.0 ; rtB . eu3o5g1x2r += rtP
. Currentfilter_C * rtX . llwavd3uol ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
rtB . brzjamghps = rtDW . e42aspecmq ; rtB . jw451fwnvv = rtP . R2_Gain * rtB
. brzjamghps ; rtB . hnt3ftc4mk = 1.000001 * rtB . jw451fwnvv *
0.96711798839458663 / 0.9999 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW
. g3zekubeld = ( rtB . eu3o5g1x2r > rtP . Constant_Value ) ; } rtB .
d5an0i50bp = rtDW . g3zekubeld ; rtB . kharh1onr2 = rtDW . blqbjt0rtj ; } tmp
= ssGetIsOkayToUpdateMode ( rtS ) ; if ( tmp ) { zcEvent = rt_ZCFcn (
RISING_ZERO_CROSSING , & rtPrevZCX . pmftj50xl0 , ( rtB . d5an0i50bp ) ) ; if
( ( zcEvent != NO_ZCEVENT ) || ( rtDW . pmmw3kelkp != 0 ) ) { rtX .
ifbj2oqhyc = rtB . kharh1onr2 ; ssSetBlockStateForSolverChangedAtMajorStep (
rtS ) ; } if ( rtX . ifbj2oqhyc >= rtP . inti_UpperSat ) { if ( rtX .
ifbj2oqhyc != rtP . inti_UpperSat ) { rtX . ifbj2oqhyc = rtP . inti_UpperSat
; ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . dvjbhtqxmw =
3 ; } else if ( rtX . ifbj2oqhyc <= rtP . inti_LowerSat ) { if ( rtX .
ifbj2oqhyc != rtP . inti_LowerSat ) { rtX . ifbj2oqhyc = rtP . inti_LowerSat
; ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . dvjbhtqxmw =
4 ; } else { if ( rtDW . dvjbhtqxmw != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . dvjbhtqxmw = 0
; } rtB . gdglp05luq = rtX . ifbj2oqhyc ; } else { rtB . gdglp05luq = rtX .
ifbj2oqhyc ; } rtB . iyfasljzji = rtP . Gain_Gain * rtB . gdglp05luq ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . kerw5fyz1o = ( rtB . iyfasljzji > rtB . jw451fwnvv ) ; } rtB .
oipsn2ext2 = rtDW . kerw5fyz1o ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . hzo55z2pdj = ( rtB . iyfasljzji < rtP . Constant9_Value ) ; } rtB .
djaii0vejs = rtDW . hzo55z2pdj ; } if ( rtB . oipsn2ext2 ) { rtB . kid3xl3flw
= rtB . jw451fwnvv ; } else { if ( rtB . djaii0vejs ) { rtB . cgct03fk00 =
rtP . Constant9_Value ; } else { rtB . cgct03fk00 = rtB . iyfasljzji ; } rtB
. kid3xl3flw = rtB . cgct03fk00 ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if
( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . mh4i1la1g4 = ( rtB . hnt3ftc4mk
<= rtB . kid3xl3flw ) ; } rtB . onwyx43zfl = rtDW . mh4i1la1g4 ; } if ( rtB .
onwyx43zfl ) { rtB . orby2ps5pm = rtB . jw451fwnvv ; } else { rtB .
orby2ps5pm = rtB . kid3xl3flw ; } k0qu5tzxih = - 0.0051332805144139711 * rtB
. brzjamghps / ( rtB . brzjamghps - rtB . orby2ps5pm ) * rtB . orby2ps5pm ;
jmuz0todoh = - rtB . d5an0i50bp * 0.0051332805144139711 * rtB . eu3o5g1x2r *
rtB . brzjamghps / ( rtB . brzjamghps - rtB . orby2ps5pm ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . p03chjpubi = rtP . R3_Gain * rtB .
brzjamghps ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . jwqn22rjtx = (
rtB . iyfasljzji > rtB . p03chjpubi ) ; } rtB . fiehiuyw0k = rtDW .
jwqn22rjtx ; rtB . datxyxwqsn = - rtB . p03chjpubi * 0.999 * 0.1 * 0.9999 ;
if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . jjnjjs4i01 = ( rtB .
iyfasljzji < rtB . datxyxwqsn ) ; } rtB . l0gpduqluz = rtDW . jjnjjs4i01 ; }
if ( rtB . fiehiuyw0k ) { rtB . hag5fa5wq5 = rtB . p03chjpubi ; } else { if (
rtB . l0gpduqluz ) { rtB . pzbmqcb4oc = rtB . datxyxwqsn ; } else { rtB .
pzbmqcb4oc = rtB . iyfasljzji ; } rtB . hag5fa5wq5 = rtB . pzbmqcb4oc ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . otnlex10rk = ( rtB . eu3o5g1x2r < rtP . Constant_Value_efypwvyyax ) ;
} rtB . irwvsmo3n1 = rtDW . otnlex10rk ; } switch ( ( int32_T ) rtP .
Battery_BatType ) { case 1 : rtB . amiygo4hlk [ 0 ] = rtP . Constant4_Value *
rtB . hag5fa5wq5 ; rtB . amiygo4hlk [ 1 ] = rtP . Constant4_Value * rtB .
eu3o5g1x2r ; rtB . amiygo4hlk [ 2 ] = rtP . Constant4_Value * rtB .
irwvsmo3n1 ; rtB . amiygo4hlk [ 3 ] = rtP . Constant4_Value * rtB .
brzjamghps ; rtB . m2x5nkxt2s = - rtB . amiygo4hlk [ 2 ] *
0.0051332805144139711 * rtB . amiygo4hlk [ 1 ] * ( 5.5835999999999864 / ( rtB
. amiygo4hlk [ 0 ] + 0.55835999999999864 ) ) ; break ; case 2 : rtB .
fpks1og0r3 [ 0 ] = rtP . Constant1_Value_ks0gbwvaxk * rtB . hag5fa5wq5 ; rtB
. fpks1og0r3 [ 1 ] = rtP . Constant1_Value_ks0gbwvaxk * rtB . eu3o5g1x2r ;
rtB . fpks1og0r3 [ 2 ] = rtP . Constant1_Value_ks0gbwvaxk * rtB . irwvsmo3n1
; rtB . fpks1og0r3 [ 3 ] = rtP . Constant1_Value_ks0gbwvaxk * rtB .
brzjamghps ; rtB . m2x5nkxt2s = - rtB . fpks1og0r3 [ 2 ] *
0.0051332805144139711 * rtB . fpks1og0r3 [ 1 ] * rtB . fpks1og0r3 [ 3 ] / (
rtB . fpks1og0r3 [ 3 ] * 0.1 + rtB . fpks1og0r3 [ 0 ] ) ; break ; case 3 :
rtB . fktu3qn43z [ 0 ] = rtP . Constant3_Value * rtB . hag5fa5wq5 ; rtB .
fktu3qn43z [ 1 ] = rtP . Constant3_Value * rtB . eu3o5g1x2r ; rtB .
fktu3qn43z [ 2 ] = rtP . Constant3_Value * rtB . irwvsmo3n1 ; rtB .
fktu3qn43z [ 3 ] = rtP . Constant3_Value * rtB . brzjamghps ; rtB .
m2x5nkxt2s = - rtB . fktu3qn43z [ 2 ] * 0.0051332805144139711 * rtB .
fktu3qn43z [ 1 ] * ( 5.5835999999999864 / ( muDoubleScalarAbs ( rtB .
fktu3qn43z [ 0 ] ) + 0.55835999999999864 ) ) ; break ; default : rtB .
cpafwt3ydk [ 0 ] = rtP . Constant2_Value * rtB . hag5fa5wq5 ; rtB .
cpafwt3ydk [ 1 ] = rtP . Constant2_Value * rtB . eu3o5g1x2r ; rtB .
cpafwt3ydk [ 2 ] = rtP . Constant2_Value * rtB . irwvsmo3n1 ; rtB .
cpafwt3ydk [ 3 ] = rtP . Constant2_Value * rtB . brzjamghps ; rtB .
m2x5nkxt2s = - rtB . cpafwt3ydk [ 2 ] * 0.0051332805144139711 * rtB .
cpafwt3ydk [ 1 ] * ( 5.5835999999999864 / ( muDoubleScalarAbs ( rtB .
cpafwt3ydk [ 0 ] ) + 0.55835999999999864 ) ) ; break ; } rtB . nigeuue53d =
rtX . ifq0x11cs2 ; if ( ssIsMajorTimeStep ( rtS ) ) { rtDW . iyzdqyqxlc = rtB
. orby2ps5pm >= rtP . Saturation_UpperSat ? 1 : rtB . orby2ps5pm > rtP .
Saturation_LowerSat ? 0 : - 1 ; } rtB . prvd12bttp = rtDW . iyzdqyqxlc == 1 ?
rtP . Saturation_UpperSat : rtDW . iyzdqyqxlc == - 1 ? rtP .
Saturation_LowerSat : rtB . orby2ps5pm ; switch ( ( int32_T ) rtP .
Battery_BatType ) { case 1 : rtB . ghz5b1e3e3 = rtB . nigeuue53d ; break ;
case 2 : rtB . ghz5b1e3e3 = muDoubleScalarExp ( - 11.307767944936083 * rtB .
prvd12bttp ) * 0.31071106332851506 ; break ; case 3 : rtB . ghz5b1e3e3 = rtB
. nigeuue53d ; break ; default : rtB . ghz5b1e3e3 = rtB . nigeuue53d ; break
; } rtB . h5exb04soq = ( ( ( k0qu5tzxih + jmuz0todoh ) + rtB . m2x5nkxt2s ) +
rtB . ghz5b1e3e3 ) + - 0.0 * rtB . orby2ps5pm ; rtB . huvwhwqywz = rtP .
Constant_Value_jorngiczgp + rtB . h5exb04soq ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . nozmgf3fmt = ( rtB .
huvwhwqywz > rtP . Constant1_Value ) ; } rtB . gyuxlbpm5v = rtDW . nozmgf3fmt
; } rtB . iomwh2g1s2 = 0.0 ; rtB . iomwh2g1s2 += rtP . BAL_C * rtX .
e1x530c3es ; rtB . gzlt4xylvw = rtP . R1_Gain * rtB . iomwh2g1s2 ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . nvbl4ewadw = ( rtB . huvwhwqywz < rtB . gzlt4xylvw ) ; } rtB .
jdzd4nb0ri = rtDW . nvbl4ewadw ; rtB . bkaepijqzl = rtDW . nvqz2cg41c ; rtB .
h22uhfy2kg = rtP . R2_Gain_axv50jbqfg * rtB . bkaepijqzl ; rtB . jzumqygy01 =
1.000001 * rtB . h22uhfy2kg * 0.96711798839458663 / 0.9999 ; } if ( rtB .
gyuxlbpm5v ) { rtB . bmrka5l5eq = rtP . Constant1_Value ; } else { if ( rtB .
jdzd4nb0ri ) { rtB . haad1hudpr = rtB . gzlt4xylvw ; } else { rtB .
haad1hudpr = rtB . huvwhwqywz ; } rtB . bmrka5l5eq = rtB . haad1hudpr ; } rtB
. jqep12tdv2 = 0.0 ; rtB . jqep12tdv2 += rtP . Currentfilter_C_e5mev0pk52 *
rtX . cs01gdjeym ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . filnbm2liy = ( rtB . jqep12tdv2 >
rtP . Constant_Value_epq2rsx4ba ) ; } rtB . f0c2kodzql = rtDW . filnbm2liy ;
rtB . ni5dgzgvxm = rtDW . f2m3u0xu0r ; } tmp = ssGetIsOkayToUpdateMode ( rtS
) ; if ( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
abvz0x2czi , ( rtB . f0c2kodzql ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . pkauuknbee != 0 ) ) { rtX . pfxj2ul3dz = rtB . ni5dgzgvxm ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . pfxj2ul3dz
>= rtP . inti_UpperSat_ff0nysnmjy ) { if ( rtX . pfxj2ul3dz != rtP .
inti_UpperSat_ff0nysnmjy ) { rtX . pfxj2ul3dz = rtP .
inti_UpperSat_ff0nysnmjy ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . lzjct3gebg = 3 ; } else if ( rtX . pfxj2ul3dz <= rtP .
inti_LowerSat_hzpmw3xl5s ) { if ( rtX . pfxj2ul3dz != rtP .
inti_LowerSat_hzpmw3xl5s ) { rtX . pfxj2ul3dz = rtP .
inti_LowerSat_hzpmw3xl5s ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . lzjct3gebg = 4 ; } else { if ( rtDW . lzjct3gebg != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . lzjct3gebg = 0
; } rtB . ay355figj3 = rtX . pfxj2ul3dz ; } else { rtB . ay355figj3 = rtX .
pfxj2ul3dz ; } rtB . abmum4zdvq = rtP . Gain_Gain_a4qiy5rws3 * rtB .
ay355figj3 ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . nakmqyg1s0 = ( rtB . abmum4zdvq >
rtB . h22uhfy2kg ) ; } rtB . emt33ggwjf = rtDW . nakmqyg1s0 ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . ajr05m0wfh = ( rtB . abmum4zdvq <
rtP . Constant9_Value_bcezbzp4a1 ) ; } rtB . hfuuf2ubg0 = rtDW . ajr05m0wfh ;
} if ( rtB . emt33ggwjf ) { rtB . jjvc40ph1m = rtB . h22uhfy2kg ; } else { if
( rtB . hfuuf2ubg0 ) { rtB . luiisy1tsz = rtP . Constant9_Value_bcezbzp4a1 ;
} else { rtB . luiisy1tsz = rtB . abmum4zdvq ; } rtB . jjvc40ph1m = rtB .
luiisy1tsz ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . i0a3swey5k = ( rtB . jzumqygy01 <=
rtB . jjvc40ph1m ) ; } rtB . brbu1ojabk = rtDW . i0a3swey5k ; } if ( rtB .
brbu1ojabk ) { rtB . cdzndnqfwj = rtB . h22uhfy2kg ; } else { rtB .
cdzndnqfwj = rtB . jjvc40ph1m ; } k0qu5tzxih = - 0.0051332805144139711 * rtB
. bkaepijqzl / ( rtB . bkaepijqzl - rtB . cdzndnqfwj ) * rtB . cdzndnqfwj ;
jmuz0todoh = - rtB . f0c2kodzql * 0.0051332805144139711 * rtB . jqep12tdv2 *
rtB . bkaepijqzl / ( rtB . bkaepijqzl - rtB . cdzndnqfwj ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . apjpswajes = rtP . R3_Gain_hslbhc5rsq
* rtB . bkaepijqzl ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
ktt1yqpggw = ( rtB . abmum4zdvq > rtB . apjpswajes ) ; } rtB . etmrit0r0u =
rtDW . ktt1yqpggw ; rtB . nfpqqtt4xe = - rtB . apjpswajes * 0.999 * 0.1 *
0.9999 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . bx2lamoanh = ( rtB .
abmum4zdvq < rtB . nfpqqtt4xe ) ; } rtB . byn2laotwy = rtDW . bx2lamoanh ; }
if ( rtB . etmrit0r0u ) { rtB . osqxc1rnvg = rtB . apjpswajes ; } else { if (
rtB . byn2laotwy ) { rtB . mv3ukrhvwg = rtB . nfpqqtt4xe ; } else { rtB .
mv3ukrhvwg = rtB . abmum4zdvq ; } rtB . osqxc1rnvg = rtB . mv3ukrhvwg ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . cz0xtkwtbl = ( rtB . jqep12tdv2 < rtP . Constant_Value_h45zreb2fb ) ;
} rtB . cun2lttrzh = rtDW . cz0xtkwtbl ; } switch ( ( int32_T ) rtP .
Battery1_BatType ) { case 1 : rtB . k4vv5a5qnd [ 0 ] = rtP .
Constant4_Value_om2zghpbx3 * rtB . osqxc1rnvg ; rtB . k4vv5a5qnd [ 1 ] = rtP
. Constant4_Value_om2zghpbx3 * rtB . jqep12tdv2 ; rtB . k4vv5a5qnd [ 2 ] =
rtP . Constant4_Value_om2zghpbx3 * rtB . cun2lttrzh ; rtB . k4vv5a5qnd [ 3 ]
= rtP . Constant4_Value_om2zghpbx3 * rtB . bkaepijqzl ; rtB . i25z0wvgra = -
rtB . k4vv5a5qnd [ 2 ] * 0.0051332805144139711 * rtB . k4vv5a5qnd [ 1 ] * (
5.5835999999999864 / ( rtB . k4vv5a5qnd [ 0 ] + 0.55835999999999864 ) ) ;
break ; case 2 : rtB . bpkwyg51d0 [ 0 ] = rtP . Constant1_Value_ny1xdqiske *
rtB . osqxc1rnvg ; rtB . bpkwyg51d0 [ 1 ] = rtP . Constant1_Value_ny1xdqiske
* rtB . jqep12tdv2 ; rtB . bpkwyg51d0 [ 2 ] = rtP .
Constant1_Value_ny1xdqiske * rtB . cun2lttrzh ; rtB . bpkwyg51d0 [ 3 ] = rtP
. Constant1_Value_ny1xdqiske * rtB . bkaepijqzl ; rtB . i25z0wvgra = - rtB .
bpkwyg51d0 [ 2 ] * 0.0051332805144139711 * rtB . bpkwyg51d0 [ 1 ] * rtB .
bpkwyg51d0 [ 3 ] / ( rtB . bpkwyg51d0 [ 3 ] * 0.1 + rtB . bpkwyg51d0 [ 0 ] )
; break ; case 3 : rtB . cpsa2gffjp [ 0 ] = rtP . Constant3_Value_kuyjih2run
* rtB . osqxc1rnvg ; rtB . cpsa2gffjp [ 1 ] = rtP .
Constant3_Value_kuyjih2run * rtB . jqep12tdv2 ; rtB . cpsa2gffjp [ 2 ] = rtP
. Constant3_Value_kuyjih2run * rtB . cun2lttrzh ; rtB . cpsa2gffjp [ 3 ] =
rtP . Constant3_Value_kuyjih2run * rtB . bkaepijqzl ; rtB . i25z0wvgra = -
rtB . cpsa2gffjp [ 2 ] * 0.0051332805144139711 * rtB . cpsa2gffjp [ 1 ] * (
5.5835999999999864 / ( muDoubleScalarAbs ( rtB . cpsa2gffjp [ 0 ] ) +
0.55835999999999864 ) ) ; break ; default : rtB . gz0xktnhv2 [ 0 ] = rtP .
Constant2_Value_ppmjeluned * rtB . osqxc1rnvg ; rtB . gz0xktnhv2 [ 1 ] = rtP
. Constant2_Value_ppmjeluned * rtB . jqep12tdv2 ; rtB . gz0xktnhv2 [ 2 ] =
rtP . Constant2_Value_ppmjeluned * rtB . cun2lttrzh ; rtB . gz0xktnhv2 [ 3 ]
= rtP . Constant2_Value_ppmjeluned * rtB . bkaepijqzl ; rtB . i25z0wvgra = -
rtB . gz0xktnhv2 [ 2 ] * 0.0051332805144139711 * rtB . gz0xktnhv2 [ 1 ] * (
5.5835999999999864 / ( muDoubleScalarAbs ( rtB . gz0xktnhv2 [ 0 ] ) +
0.55835999999999864 ) ) ; break ; } rtB . ehifpgdwjy = rtX . akpflzngjb ; if
( ssIsMajorTimeStep ( rtS ) ) { rtDW . nx4kcep112 = rtB . cdzndnqfwj >= rtP .
Saturation_UpperSat_dr1jmbb0we ? 1 : rtB . cdzndnqfwj > rtP .
Saturation_LowerSat_haspwmkdbs ? 0 : - 1 ; } rtB . obg0kvwunj = rtDW .
nx4kcep112 == 1 ? rtP . Saturation_UpperSat_dr1jmbb0we : rtDW . nx4kcep112 ==
- 1 ? rtP . Saturation_LowerSat_haspwmkdbs : rtB . cdzndnqfwj ; switch ( (
int32_T ) rtP . Battery1_BatType ) { case 1 : rtB . pvonpaqj1n = rtB .
ehifpgdwjy ; break ; case 2 : rtB . pvonpaqj1n = muDoubleScalarExp ( -
11.307767944936083 * rtB . obg0kvwunj ) * 0.31071106332851506 ; break ; case
3 : rtB . pvonpaqj1n = rtB . ehifpgdwjy ; break ; default : rtB . pvonpaqj1n
= rtB . ehifpgdwjy ; break ; } rtB . kmx5zhhmnh = ( ( ( k0qu5tzxih +
jmuz0todoh ) + rtB . i25z0wvgra ) + rtB . pvonpaqj1n ) + - 0.0 * rtB .
cdzndnqfwj ; rtB . jugdae5134 = rtP . Constant_Value_pfu1thap3i + rtB .
kmx5zhhmnh ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . hoowhfzk1u = ( rtB . jugdae5134 >
rtP . Constant1_Value_h1thd4w1zg ) ; } rtB . cfgua3mzpn = rtDW . hoowhfzk1u ;
} rtB . bjd1txqszf = 0.0 ; rtB . bjd1txqszf += rtP . BAL_C_cq3wtorxkj * rtX .
jmchzhaobx ; rtB . j1tsv1iiyg = rtP . R1_Gain_bdgjwewy0w * rtB . bjd1txqszf ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) )
{ rtDW . fr2favuzoz = ( rtB . jugdae5134 < rtB . j1tsv1iiyg ) ; } rtB .
o2yv2v00xl = rtDW . fr2favuzoz ; rtB . k1a40pib50 = rtDW . nbwsnfqnlk ; rtB .
h1cgh2p3m1 = rtP . R2_Gain_co3b3ev0vv * rtB . k1a40pib50 ; rtB . me5y00movs =
1.000001 * rtB . h1cgh2p3m1 * 0.96711798839458663 / 0.9999 ; } if ( rtB .
cfgua3mzpn ) { rtB . gwm55h223z = rtP . Constant1_Value_h1thd4w1zg ; } else {
if ( rtB . o2yv2v00xl ) { rtB . pgjbxu0ggf = rtB . j1tsv1iiyg ; } else { rtB
. pgjbxu0ggf = rtB . jugdae5134 ; } rtB . gwm55h223z = rtB . pgjbxu0ggf ; }
rtB . bfoinkupre = 0.0 ; rtB . bfoinkupre += rtP . Currentfilter_C_cr1quwu5bc
* rtX . otk33ad0ab ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . lbwvzc51ur = ( rtB . bfoinkupre >
rtP . Constant_Value_c5l5x2wrr5 ) ; } rtB . pdw4w0iukq = rtDW . lbwvzc51ur ;
rtB . ef23qut0ie = rtDW . doqeveoc11 ; } tmp = ssGetIsOkayToUpdateMode ( rtS
) ; if ( tmp ) { zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & rtPrevZCX .
jnr2ivwps5 , ( rtB . pdw4w0iukq ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
rtDW . lwuqhty1j2 != 0 ) ) { rtX . p3nmfmnma0 = rtB . ef23qut0ie ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } if ( rtX . p3nmfmnma0
>= rtP . inti_UpperSat_paqyu313at ) { if ( rtX . p3nmfmnma0 != rtP .
inti_UpperSat_paqyu313at ) { rtX . p3nmfmnma0 = rtP .
inti_UpperSat_paqyu313at ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . a5hpejqbid = 3 ; } else if ( rtX . p3nmfmnma0 <= rtP .
inti_LowerSat_ntmgylsy20 ) { if ( rtX . p3nmfmnma0 != rtP .
inti_LowerSat_ntmgylsy20 ) { rtX . p3nmfmnma0 = rtP .
inti_LowerSat_ntmgylsy20 ; ssSetBlockStateForSolverChangedAtMajorStep ( rtS )
; } rtDW . a5hpejqbid = 4 ; } else { if ( rtDW . a5hpejqbid != 0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } rtDW . a5hpejqbid = 0
; } rtB . i0gqr3h53o = rtX . p3nmfmnma0 ; } else { rtB . i0gqr3h53o = rtX .
p3nmfmnma0 ; } rtB . jg4yrqfsjm = rtP . Gain_Gain_fhbsryzldc * rtB .
i0gqr3h53o ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . isyxaae0ta = ( rtB . jg4yrqfsjm >
rtB . h1cgh2p3m1 ) ; } rtB . pvm1yyq1x2 = rtDW . isyxaae0ta ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . f4biz4rnh4 = ( rtB . jg4yrqfsjm <
rtP . Constant9_Value_jb43nlmf1e ) ; } rtB . liehtgeamk = rtDW . f4biz4rnh4 ;
} if ( rtB . pvm1yyq1x2 ) { rtB . azy5vdur0y = rtB . h1cgh2p3m1 ; } else { if
( rtB . liehtgeamk ) { rtB . oin55b55uz = rtP . Constant9_Value_jb43nlmf1e ;
} else { rtB . oin55b55uz = rtB . jg4yrqfsjm ; } rtB . azy5vdur0y = rtB .
oin55b55uz ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . bzi5sp21lh = ( rtB . me5y00movs <=
rtB . azy5vdur0y ) ; } rtB . p11j5vzjvf = rtDW . bzi5sp21lh ; } if ( rtB .
p11j5vzjvf ) { rtB . ojpg4sgyg2 = rtB . h1cgh2p3m1 ; } else { rtB .
ojpg4sgyg2 = rtB . azy5vdur0y ; } k0qu5tzxih = - 0.0051332805144139711 * rtB
. k1a40pib50 / ( rtB . k1a40pib50 - rtB . ojpg4sgyg2 ) * rtB . ojpg4sgyg2 ;
jmuz0todoh = - rtB . pdw4w0iukq * 0.0051332805144139711 * rtB . bfoinkupre *
rtB . k1a40pib50 / ( rtB . k1a40pib50 - rtB . ojpg4sgyg2 ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . bybzbvcgip = rtP . R3_Gain_d3ow5rqpqq
* rtB . k1a40pib50 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
nghvchwmka = ( rtB . jg4yrqfsjm > rtB . bybzbvcgip ) ; } rtB . jlf0hrvb5z =
rtDW . nghvchwmka ; rtB . c0s1abefak = - rtB . bybzbvcgip * 0.999 * 0.1 *
0.9999 ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . kzhafiuqm5 = ( rtB .
jg4yrqfsjm < rtB . c0s1abefak ) ; } rtB . hoc1uowy0l = rtDW . kzhafiuqm5 ; }
if ( rtB . jlf0hrvb5z ) { rtB . nj11lx1qq3 = rtB . bybzbvcgip ; } else { if (
rtB . hoc1uowy0l ) { rtB . hbdfujedg1 = rtB . c0s1abefak ; } else { rtB .
hbdfujedg1 = rtB . jg4yrqfsjm ; } rtB . nj11lx1qq3 = rtB . hbdfujedg1 ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) {
rtDW . j5wwiwrs0c = ( rtB . bfoinkupre < rtP . Constant_Value_j455eynuld ) ;
} rtB . ctnsceddfy = rtDW . j5wwiwrs0c ; } switch ( ( int32_T ) rtP .
Battery2_BatType ) { case 1 : rtB . kvy1l3feb5 [ 0 ] = rtP .
Constant4_Value_g3r4dndzdn * rtB . nj11lx1qq3 ; rtB . kvy1l3feb5 [ 1 ] = rtP
. Constant4_Value_g3r4dndzdn * rtB . bfoinkupre ; rtB . kvy1l3feb5 [ 2 ] =
rtP . Constant4_Value_g3r4dndzdn * rtB . ctnsceddfy ; rtB . kvy1l3feb5 [ 3 ]
= rtP . Constant4_Value_g3r4dndzdn * rtB . k1a40pib50 ; rtB . kvfix31cdr = -
rtB . kvy1l3feb5 [ 2 ] * 0.0051332805144139711 * rtB . kvy1l3feb5 [ 1 ] * (
5.5835999999999864 / ( rtB . kvy1l3feb5 [ 0 ] + 0.55835999999999864 ) ) ;
break ; case 2 : rtB . hakcjtbzae [ 0 ] = rtP . Constant1_Value_d4ob3b25zw *
rtB . nj11lx1qq3 ; rtB . hakcjtbzae [ 1 ] = rtP . Constant1_Value_d4ob3b25zw
* rtB . bfoinkupre ; rtB . hakcjtbzae [ 2 ] = rtP .
Constant1_Value_d4ob3b25zw * rtB . ctnsceddfy ; rtB . hakcjtbzae [ 3 ] = rtP
. Constant1_Value_d4ob3b25zw * rtB . k1a40pib50 ; rtB . kvfix31cdr = - rtB .
hakcjtbzae [ 2 ] * 0.0051332805144139711 * rtB . hakcjtbzae [ 1 ] * rtB .
hakcjtbzae [ 3 ] / ( rtB . hakcjtbzae [ 3 ] * 0.1 + rtB . hakcjtbzae [ 0 ] )
; break ; case 3 : rtB . bfwytcdw0r [ 0 ] = rtP . Constant3_Value_mv2f5w5r3e
* rtB . nj11lx1qq3 ; rtB . bfwytcdw0r [ 1 ] = rtP .
Constant3_Value_mv2f5w5r3e * rtB . bfoinkupre ; rtB . bfwytcdw0r [ 2 ] = rtP
. Constant3_Value_mv2f5w5r3e * rtB . ctnsceddfy ; rtB . bfwytcdw0r [ 3 ] =
rtP . Constant3_Value_mv2f5w5r3e * rtB . k1a40pib50 ; rtB . kvfix31cdr = -
rtB . bfwytcdw0r [ 2 ] * 0.0051332805144139711 * rtB . bfwytcdw0r [ 1 ] * (
5.5835999999999864 / ( muDoubleScalarAbs ( rtB . bfwytcdw0r [ 0 ] ) +
0.55835999999999864 ) ) ; break ; default : rtB . lexfemd5s5 [ 0 ] = rtP .
Constant2_Value_cymgwomvip * rtB . nj11lx1qq3 ; rtB . lexfemd5s5 [ 1 ] = rtP
. Constant2_Value_cymgwomvip * rtB . bfoinkupre ; rtB . lexfemd5s5 [ 2 ] =
rtP . Constant2_Value_cymgwomvip * rtB . ctnsceddfy ; rtB . lexfemd5s5 [ 3 ]
= rtP . Constant2_Value_cymgwomvip * rtB . k1a40pib50 ; rtB . kvfix31cdr = -
rtB . lexfemd5s5 [ 2 ] * 0.0051332805144139711 * rtB . lexfemd5s5 [ 1 ] * (
5.5835999999999864 / ( muDoubleScalarAbs ( rtB . lexfemd5s5 [ 0 ] ) +
0.55835999999999864 ) ) ; break ; } rtB . pkj0c3flun = rtX . jws0lo1qo5 ; if
( ssIsMajorTimeStep ( rtS ) ) { rtDW . e4gutnhgzf = rtB . ojpg4sgyg2 >= rtP .
Saturation_UpperSat_dcwljnke5m ? 1 : rtB . ojpg4sgyg2 > rtP .
Saturation_LowerSat_pt1ot4ctql ? 0 : - 1 ; } rtB . alow0u4nsz = rtDW .
e4gutnhgzf == 1 ? rtP . Saturation_UpperSat_dcwljnke5m : rtDW . e4gutnhgzf ==
- 1 ? rtP . Saturation_LowerSat_pt1ot4ctql : rtB . ojpg4sgyg2 ; switch ( (
int32_T ) rtP . Battery2_BatType ) { case 1 : rtB . eavnlisxfe = rtB .
pkj0c3flun ; break ; case 2 : rtB . eavnlisxfe = muDoubleScalarExp ( -
11.307767944936083 * rtB . alow0u4nsz ) * 0.31071106332851506 ; break ; case
3 : rtB . eavnlisxfe = rtB . pkj0c3flun ; break ; default : rtB . eavnlisxfe
= rtB . pkj0c3flun ; break ; } rtB . kixhxo1qh1 = ( ( ( k0qu5tzxih +
jmuz0todoh ) + rtB . kvfix31cdr ) + rtB . eavnlisxfe ) + - 0.0 * rtB .
ojpg4sgyg2 ; rtB . ipqjb5oznn = rtP . Constant_Value_no3jct1ds0 + rtB .
kixhxo1qh1 ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . hjta2mhewa = ( rtB . ipqjb5oznn >
rtP . Constant1_Value_lyb1tm4os2 ) ; } rtB . ivq3zpd1bd = rtDW . hjta2mhewa ;
} rtB . lersv2nrng = 0.0 ; rtB . lersv2nrng += rtP . BAL_C_ekdjgq2enr * rtX .
g004y4jnca ; rtB . deqrvibqyf = rtP . R1_Gain_pckb3sksct * rtB . lersv2nrng ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) )
{ rtDW . i1hse0ipam = ( rtB . ipqjb5oznn < rtB . deqrvibqyf ) ; } rtB .
etnpopllbl = rtDW . i1hse0ipam ; } if ( rtB . ivq3zpd1bd ) { rtB . kjglqur00l
= rtP . Constant1_Value_lyb1tm4os2 ; } else { if ( rtB . etnpopllbl ) { rtB .
fos1jiogax = rtB . deqrvibqyf ; } else { rtB . fos1jiogax = rtB . ipqjb5oznn
; } rtB . kjglqur00l = rtB . fos1jiogax ; } { SimStruct * rts =
ssGetSFunction ( rtS , 0 ) ; sfcnOutputs ( rts , 0 ) ; } if ( ssIsSampleHit (
rtS , 1 , 0 ) ) { rtB . ldgus1sr1s = rtP . R4_Gain * rtB . brzjamghps ; } rtB
. pvu3dnbqsl = ( 1.0 - rtB . orby2ps5pm / rtB . ldgus1sr1s ) * 100.0 ; if (
ssIsMajorTimeStep ( rtS ) ) { rtDW . pq0j2opq0v = rtB . pvu3dnbqsl >= rtP .
Saturation_UpperSat_pcz043fnep ? 1 : rtB . pvu3dnbqsl > rtP .
Saturation_LowerSat_b05y2t0vvl ? 0 : - 1 ; } rtB . glvvn5z0tb = rtDW .
pq0j2opq0v == 1 ? rtP . Saturation_UpperSat_pcz043fnep : rtDW . pq0j2opq0v ==
- 1 ? rtP . Saturation_LowerSat_b05y2t0vvl : rtB . pvu3dnbqsl ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . gnspd531yz = rtP . R4_Gain_e51nv5aiyc
* rtB . bkaepijqzl ; } rtB . i0mboczxg1 = ( 1.0 - rtB . cdzndnqfwj / rtB .
gnspd531yz ) * 100.0 ; if ( ssIsMajorTimeStep ( rtS ) ) { rtDW . gx0nzawyk1 =
rtB . i0mboczxg1 >= rtP . Saturation_UpperSat_p4wbgcsokm ? 1 : rtB .
i0mboczxg1 > rtP . Saturation_LowerSat_gdbbvpyvzg ? 0 : - 1 ; } rtB .
alddy4exqt = rtDW . gx0nzawyk1 == 1 ? rtP . Saturation_UpperSat_p4wbgcsokm :
rtDW . gx0nzawyk1 == - 1 ? rtP . Saturation_LowerSat_gdbbvpyvzg : rtB .
i0mboczxg1 ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . l3y1twbqro = rtP .
R4_Gain_djamifkejg * rtB . k1a40pib50 ; } rtB . e1vfx4yr0v = ( 1.0 - rtB .
ojpg4sgyg2 / rtB . l3y1twbqro ) * 100.0 ; if ( ssIsMajorTimeStep ( rtS ) ) {
rtDW . e1fty5bnxj = rtB . e1vfx4yr0v >= rtP . Saturation_UpperSat_mldly5fnun
? 1 : rtB . e1vfx4yr0v > rtP . Saturation_LowerSat_ctz2o0nkl2 ? 0 : - 1 ; }
rtB . bxlrmhtp4q = rtDW . e1fty5bnxj == 1 ? rtP .
Saturation_UpperSat_mldly5fnun : rtDW . e1fty5bnxj == - 1 ? rtP .
Saturation_LowerSat_ctz2o0nkl2 : rtB . e1vfx4yr0v ; rtB . a4tzm2m5sq = rtP .
donotdeletethisgain_Gain * rtB . dagypwp03e [ 0 ] ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . addp1g5vdn = ( rtB . a4tzm2m5sq >=
0.0 ) ; } rtB . iuxt2aetva = rtDW . addp1g5vdn > 0 ? rtB . a4tzm2m5sq : - rtB
. a4tzm2m5sq ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . ejfpjeh5m5 = ( rtB . a4tzm2m5sq <
rtP . Constant_Value_ogegtmkzv0 ) ; } rtB . abcbugh4lq = rtP . Gain4_Gain * (
real_T ) rtDW . ejfpjeh5m5 ; } rtB . grdkvtj4al = rtB . abcbugh4lq - rtB .
nigeuue53d ; rtB . g1v4ipxq25 = rtB . iuxt2aetva * rtB . grdkvtj4al ; rtB .
apotbg3wx1 = rtP . Gain1_Gain * rtB . g1v4ipxq25 ; rtB . gbetiytzwl = rtP .
Gain2_Gain * rtB . orby2ps5pm ; rtB . bh3gpd01qa = rtP .
donotdeletethisgain_Gain_ave45anr4u * rtB . dagypwp03e [ 1 ] ; if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . iplu2tul0d = ( rtB . bh3gpd01qa >=
0.0 ) ; } rtB . pnshzpy2e2 = rtDW . iplu2tul0d > 0 ? rtB . bh3gpd01qa : - rtB
. bh3gpd01qa ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if (
ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . kwwsfqauib = ( rtB . bh3gpd01qa <
rtP . Constant_Value_khiqevv1tc ) ; } rtB . anyjfk53qp = rtP .
Gain4_Gain_j4eqtusam3 * ( real_T ) rtDW . kwwsfqauib ; } rtB . cpfn4adcdj =
rtB . anyjfk53qp - rtB . ehifpgdwjy ; rtB . asmh3r5xcj = rtB . pnshzpy2e2 *
rtB . cpfn4adcdj ; rtB . pwybstq3ra = rtP . Gain1_Gain_dq4vkdpk0h * rtB .
asmh3r5xcj ; rtB . gw1zorijkj = rtP . Gain2_Gain_of2pa5ka31 * rtB .
cdzndnqfwj ; rtB . lt0awrrixb = rtP . donotdeletethisgain_Gain_hhsesvmj2g *
rtB . dagypwp03e [ 2 ] ; if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW .
aztlcwuvj4 = ( rtB . lt0awrrixb >= 0.0 ) ; } rtB . njircekp2k = rtDW .
aztlcwuvj4 > 0 ? rtB . lt0awrrixb : - rtB . lt0awrrixb ; if ( ssIsSampleHit (
rtS , 1 , 0 ) ) { if ( ssGetIsOkayToUpdateMode ( rtS ) ) { rtDW . m43xdundri
= ( rtB . lt0awrrixb < rtP . Constant_Value_anxi4ijlqk ) ; } rtB . k1ekc1vsf0
= rtP . Gain4_Gain_fxc0qhliat * ( real_T ) rtDW . m43xdundri ; } rtB .
cpadzae1y5 = rtB . k1ekc1vsf0 - rtB . pkj0c3flun ; rtB . h14foxcrc1 = rtB .
njircekp2k * rtB . cpadzae1y5 ; rtB . j2xpkyat4x = rtP .
Gain1_Gain_erkjggn3zc * rtB . h14foxcrc1 ; rtB . hys3hftnnd = rtP .
Gain2_Gain_lnlqortcjb * rtB . ojpg4sgyg2 ; rtB . easujerxmm = ( ( rtB .
glvvn5z0tb > rtB . alddy4exqt ) || ( rtB . glvvn5z0tb > rtB . bxlrmhtp4q ) )
; rtB . i1ccd4rxd5 = ( ( rtB . alddy4exqt > rtB . glvvn5z0tb ) || ( rtB .
alddy4exqt > rtB . bxlrmhtp4q ) ) ; rtB . exhgo3ztsa = ( ( rtB . bxlrmhtp4q >
rtB . alddy4exqt ) || ( rtB . bxlrmhtp4q > rtB . glvvn5z0tb ) ) ;
UNUSED_PARAMETER ( tid ) ; } void MdlOutputsTID2 ( int_T tid ) { rtB .
gisoswnzov = rtP . qqq_Value ; rtB . be1yt0sowu = rtP . qqq_Value_fqup2ywv0j
; rtB . do3x3pi1jp = rtP . qqq_Value_ahsmvvczti ; UNUSED_PARAMETER ( tid ) ;
} void MdlUpdate ( int_T tid ) { XDis * _rtXdis ; _rtXdis = ( ( XDis * )
ssGetContStateDisabled ( rtS ) ) ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
rtDW . e42aspecmq = rtP . Constant12_Value ; rtDW . blqbjt0rtj = rtB .
gbetiytzwl ; } rtDW . pmmw3kelkp = 0 ; switch ( rtDW . dvjbhtqxmw ) { case 3
: if ( rtB . a4tzm2m5sq < 0.0 ) { rtDW . dvjbhtqxmw = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . a4tzm2m5sq > 0.0 ) { rtDW . dvjbhtqxmw = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
ifbj2oqhyc = ( ( rtDW . dvjbhtqxmw == 3 ) || ( rtDW . dvjbhtqxmw == 4 ) ) ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . nvqz2cg41c = rtP .
Constant12_Value_oujd2whfki ; rtDW . f2m3u0xu0r = rtB . gw1zorijkj ; } rtDW .
pkauuknbee = 0 ; switch ( rtDW . lzjct3gebg ) { case 3 : if ( rtB .
bh3gpd01qa < 0.0 ) { rtDW . lzjct3gebg = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . bh3gpd01qa > 0.0 ) { rtDW . lzjct3gebg = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
pfxj2ul3dz = ( ( rtDW . lzjct3gebg == 3 ) || ( rtDW . lzjct3gebg == 4 ) ) ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . nbwsnfqnlk = rtP .
Constant12_Value_fsrk0ximud ; rtDW . doqeveoc11 = rtB . hys3hftnnd ; } rtDW .
lwuqhty1j2 = 0 ; switch ( rtDW . a5hpejqbid ) { case 3 : if ( rtB .
lt0awrrixb < 0.0 ) { rtDW . a5hpejqbid = 1 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; case 4 : if (
rtB . lt0awrrixb > 0.0 ) { rtDW . a5hpejqbid = 2 ;
ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; } break ; } _rtXdis ->
p3nmfmnma0 = ( ( rtDW . a5hpejqbid == 3 ) || ( rtDW . a5hpejqbid == 4 ) ) ; {
SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; sfcnUpdate ( rts , 0 ) ; if (
ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } UNUSED_PARAMETER ( tid ) ;
} void MdlUpdateTID2 ( int_T tid ) { UNUSED_PARAMETER ( tid ) ; } void
MdlDerivatives ( void ) { XDis * _rtXdis ; XDot * _rtXdot ; _rtXdis = ( (
XDis * ) ssGetContStateDisabled ( rtS ) ) ; _rtXdot = ( ( XDot * ) ssGetdX (
rtS ) ) ; _rtXdot -> llwavd3uol = 0.0 ; _rtXdot -> llwavd3uol += rtP .
Currentfilter_A * rtX . llwavd3uol ; _rtXdot -> llwavd3uol += rtB .
a4tzm2m5sq ; if ( _rtXdis -> ifbj2oqhyc ) { _rtXdot -> ifbj2oqhyc = 0.0 ; }
else { _rtXdot -> ifbj2oqhyc = rtB . a4tzm2m5sq ; } _rtXdot -> ifq0x11cs2 =
rtB . apotbg3wx1 ; _rtXdot -> e1x530c3es = 0.0 ; _rtXdot -> e1x530c3es += rtP
. BAL_A * rtX . e1x530c3es ; _rtXdot -> e1x530c3es += rtB . a4tzm2m5sq ;
_rtXdot -> cs01gdjeym = 0.0 ; _rtXdot -> cs01gdjeym += rtP .
Currentfilter_A_o3r40a2fs0 * rtX . cs01gdjeym ; _rtXdot -> cs01gdjeym += rtB
. bh3gpd01qa ; if ( _rtXdis -> pfxj2ul3dz ) { _rtXdot -> pfxj2ul3dz = 0.0 ; }
else { _rtXdot -> pfxj2ul3dz = rtB . bh3gpd01qa ; } _rtXdot -> akpflzngjb =
rtB . pwybstq3ra ; _rtXdot -> jmchzhaobx = 0.0 ; _rtXdot -> jmchzhaobx += rtP
. BAL_A_oad34lr4nf * rtX . jmchzhaobx ; _rtXdot -> jmchzhaobx += rtB .
bh3gpd01qa ; _rtXdot -> otk33ad0ab = 0.0 ; _rtXdot -> otk33ad0ab += rtP .
Currentfilter_A_b4s30vlpp5 * rtX . otk33ad0ab ; _rtXdot -> otk33ad0ab += rtB
. lt0awrrixb ; if ( _rtXdis -> p3nmfmnma0 ) { _rtXdot -> p3nmfmnma0 = 0.0 ; }
else { _rtXdot -> p3nmfmnma0 = rtB . lt0awrrixb ; } _rtXdot -> jws0lo1qo5 =
rtB . j2xpkyat4x ; _rtXdot -> g004y4jnca = 0.0 ; _rtXdot -> g004y4jnca += rtP
. BAL_A_lpxrnrfk4y * rtX . g004y4jnca ; _rtXdot -> g004y4jnca += rtB .
lt0awrrixb ; } void MdlProjection ( void ) { } void MdlZeroCrossings ( void )
{ ZCV * _rtZCSV ; _rtZCSV = ( ( ZCV * ) ssGetSolverZcSignalVector ( rtS ) ) ;
_rtZCSV -> fdnslpvls5 = rtB . eu3o5g1x2r - rtP . Constant_Value ; switch (
rtDW . dvjbhtqxmw ) { case 1 : _rtZCSV -> bpdqbd11vl = 0.0 ; _rtZCSV ->
nrfk30fotw = rtP . inti_UpperSat - rtP . inti_LowerSat ; break ; case 2 :
_rtZCSV -> bpdqbd11vl = rtP . inti_LowerSat - rtP . inti_UpperSat ; _rtZCSV
-> nrfk30fotw = 0.0 ; break ; default : _rtZCSV -> bpdqbd11vl = rtX .
ifbj2oqhyc - rtP . inti_UpperSat ; _rtZCSV -> nrfk30fotw = rtX . ifbj2oqhyc -
rtP . inti_LowerSat ; break ; } if ( ( rtDW . dvjbhtqxmw == 3 ) || ( rtDW .
dvjbhtqxmw == 4 ) ) { _rtZCSV -> ama1zmqq3c = rtB . a4tzm2m5sq ; } else {
_rtZCSV -> ama1zmqq3c = 0.0 ; } _rtZCSV -> alzaxrhst5 = rtB . iyfasljzji -
rtB . jw451fwnvv ; _rtZCSV -> mnfw3j5o3b = rtB . iyfasljzji - rtP .
Constant9_Value ; _rtZCSV -> o5xc50cadv = rtB . hnt3ftc4mk - rtB . kid3xl3flw
; _rtZCSV -> lw0lg3yi2h = rtB . iyfasljzji - rtB . p03chjpubi ; _rtZCSV ->
af2kdct1z0 = rtB . iyfasljzji - rtB . datxyxwqsn ; _rtZCSV -> mfppydvi44 =
rtB . eu3o5g1x2r - rtP . Constant_Value_efypwvyyax ; _rtZCSV -> gy5gisvieu =
rtB . orby2ps5pm - rtP . Saturation_UpperSat ; _rtZCSV -> hlrpe3mm41 = rtB .
orby2ps5pm - rtP . Saturation_LowerSat ; _rtZCSV -> bn5ffrb0j4 = rtB .
huvwhwqywz - rtP . Constant1_Value ; _rtZCSV -> jffp4lkqfd = rtB . huvwhwqywz
- rtB . gzlt4xylvw ; _rtZCSV -> jhds2js3yn = rtB . jqep12tdv2 - rtP .
Constant_Value_epq2rsx4ba ; switch ( rtDW . lzjct3gebg ) { case 1 : _rtZCSV
-> nhelrozjhs = 0.0 ; _rtZCSV -> bvk5eh2jrf = rtP . inti_UpperSat_ff0nysnmjy
- rtP . inti_LowerSat_hzpmw3xl5s ; break ; case 2 : _rtZCSV -> nhelrozjhs =
rtP . inti_LowerSat_hzpmw3xl5s - rtP . inti_UpperSat_ff0nysnmjy ; _rtZCSV ->
bvk5eh2jrf = 0.0 ; break ; default : _rtZCSV -> nhelrozjhs = rtX . pfxj2ul3dz
- rtP . inti_UpperSat_ff0nysnmjy ; _rtZCSV -> bvk5eh2jrf = rtX . pfxj2ul3dz -
rtP . inti_LowerSat_hzpmw3xl5s ; break ; } if ( ( rtDW . lzjct3gebg == 3 ) ||
( rtDW . lzjct3gebg == 4 ) ) { _rtZCSV -> o5qmhd1fki = rtB . bh3gpd01qa ; }
else { _rtZCSV -> o5qmhd1fki = 0.0 ; } _rtZCSV -> ls0bmborz4 = rtB .
abmum4zdvq - rtB . h22uhfy2kg ; _rtZCSV -> jccksrr2g2 = rtB . abmum4zdvq -
rtP . Constant9_Value_bcezbzp4a1 ; _rtZCSV -> fd3dqccwnu = rtB . jzumqygy01 -
rtB . jjvc40ph1m ; _rtZCSV -> eow004kazk = rtB . abmum4zdvq - rtB .
apjpswajes ; _rtZCSV -> kknc51hjvv = rtB . abmum4zdvq - rtB . nfpqqtt4xe ;
_rtZCSV -> pbytzpa1qb = rtB . jqep12tdv2 - rtP . Constant_Value_h45zreb2fb ;
_rtZCSV -> exlr04veit = rtB . cdzndnqfwj - rtP .
Saturation_UpperSat_dr1jmbb0we ; _rtZCSV -> kaiyuzuht2 = rtB . cdzndnqfwj -
rtP . Saturation_LowerSat_haspwmkdbs ; _rtZCSV -> n0btl3auax = rtB .
jugdae5134 - rtP . Constant1_Value_h1thd4w1zg ; _rtZCSV -> otybnaqskq = rtB .
jugdae5134 - rtB . j1tsv1iiyg ; _rtZCSV -> khd1hzy5hm = rtB . bfoinkupre -
rtP . Constant_Value_c5l5x2wrr5 ; switch ( rtDW . a5hpejqbid ) { case 1 :
_rtZCSV -> om3rbhetlw = 0.0 ; _rtZCSV -> i5ekkply22 = rtP .
inti_UpperSat_paqyu313at - rtP . inti_LowerSat_ntmgylsy20 ; break ; case 2 :
_rtZCSV -> om3rbhetlw = rtP . inti_LowerSat_ntmgylsy20 - rtP .
inti_UpperSat_paqyu313at ; _rtZCSV -> i5ekkply22 = 0.0 ; break ; default :
_rtZCSV -> om3rbhetlw = rtX . p3nmfmnma0 - rtP . inti_UpperSat_paqyu313at ;
_rtZCSV -> i5ekkply22 = rtX . p3nmfmnma0 - rtP . inti_LowerSat_ntmgylsy20 ;
break ; } if ( ( rtDW . a5hpejqbid == 3 ) || ( rtDW . a5hpejqbid == 4 ) ) {
_rtZCSV -> kccnz43vm4 = rtB . lt0awrrixb ; } else { _rtZCSV -> kccnz43vm4 =
0.0 ; } _rtZCSV -> a1glw5qzrz = rtB . jg4yrqfsjm - rtB . h1cgh2p3m1 ; _rtZCSV
-> mopcnqs0r4 = rtB . jg4yrqfsjm - rtP . Constant9_Value_jb43nlmf1e ; _rtZCSV
-> mnetvhzfen = rtB . me5y00movs - rtB . azy5vdur0y ; _rtZCSV -> o1fkf5dcpb =
rtB . jg4yrqfsjm - rtB . bybzbvcgip ; _rtZCSV -> gfj3zvwrmt = rtB .
jg4yrqfsjm - rtB . c0s1abefak ; _rtZCSV -> cgkuls43qd = rtB . bfoinkupre -
rtP . Constant_Value_j455eynuld ; _rtZCSV -> jangylcagi = rtB . ojpg4sgyg2 -
rtP . Saturation_UpperSat_dcwljnke5m ; _rtZCSV -> iiphl5uwrl = rtB .
ojpg4sgyg2 - rtP . Saturation_LowerSat_pt1ot4ctql ; _rtZCSV -> dzzntfzcwt =
rtB . ipqjb5oznn - rtP . Constant1_Value_lyb1tm4os2 ; _rtZCSV -> psfiklfccd =
rtB . ipqjb5oznn - rtB . deqrvibqyf ; { SimStruct * rts = ssGetSFunction (
rtS , 0 ) ; ssSetNonsampledZCs ( rts , & ( ( ( ZCV * )
ssGetSolverZcSignalVector ( rtS ) ) -> cgtkpgzhce [ 0 ] ) ) ;
sfcnZeroCrossings ( rts ) ; if ( ssGetErrorStatus ( rts ) != ( NULL ) )
return ; } _rtZCSV -> p5eblkyv4j = rtB . pvu3dnbqsl - rtP .
Saturation_UpperSat_pcz043fnep ; _rtZCSV -> i3wttv04da = rtB . pvu3dnbqsl -
rtP . Saturation_LowerSat_b05y2t0vvl ; _rtZCSV -> lfobpjboni = rtB .
i0mboczxg1 - rtP . Saturation_UpperSat_p4wbgcsokm ; _rtZCSV -> jakcquecoz =
rtB . i0mboczxg1 - rtP . Saturation_LowerSat_gdbbvpyvzg ; _rtZCSV ->
fsowuvns4h = rtB . e1vfx4yr0v - rtP . Saturation_UpperSat_mldly5fnun ;
_rtZCSV -> kwufqgroyh = rtB . e1vfx4yr0v - rtP .
Saturation_LowerSat_ctz2o0nkl2 ; _rtZCSV -> crb5yz0hg2 = rtB . a4tzm2m5sq ;
_rtZCSV -> mvzyhp2pwm = rtB . a4tzm2m5sq - rtP . Constant_Value_ogegtmkzv0 ;
_rtZCSV -> k35orq1xu1 = rtB . bh3gpd01qa ; _rtZCSV -> lm3gdcfn3d = rtB .
bh3gpd01qa - rtP . Constant_Value_khiqevv1tc ; _rtZCSV -> mpop54b5qu = rtB .
lt0awrrixb ; _rtZCSV -> em1gol2bjz = rtB . lt0awrrixb - rtP .
Constant_Value_anxi4ijlqk ; } void MdlTerminate ( void ) { { SimStruct * rts
= ssGetSFunction ( rtS , 0 ) ; sfcnTerminate ( rts ) ; } } static void
mr_Passive_balancing_cacheDataAsMxArray ( mxArray * destArray , mwIndex i ,
int j , const void * srcData , size_t numBytes ) ; static void
mr_Passive_balancing_cacheDataAsMxArray ( mxArray * destArray , mwIndex i ,
int j , const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_Passive_balancing_restoreDataFromMxArray ( void * destData
, const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static
void mr_Passive_balancing_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( (
uint8_T * ) destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber (
srcArray , i , j ) ) , numBytes ) ; } static void
mr_Passive_balancing_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i
, int j , uint_T bitVal ) ; static void
mr_Passive_balancing_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i
, int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_Passive_balancing_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_Passive_balancing_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T )
mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( (
1u << numBits ) - 1u ) ; } static void
mr_Passive_balancing_cacheDataToMxArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , const void * srcData , size_t numBytes )
; static void mr_Passive_balancing_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_Passive_balancing_restoreDataFromMxArrayWithOffset ( void * destData
, const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) ; static void
mr_Passive_balancing_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_Passive_balancing_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static
void mr_Passive_balancing_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) {
mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_Passive_balancing_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_Passive_balancing_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) {
const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_Passive_balancing_GetDWork ( ) {
static const char * ssDWFieldNames [ 3 ] = { "rtB" , "rtDW" , "rtPrevZCX" , }
; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_Passive_balancing_cacheDataAsMxArray ( ssDW , 0 , 0 , ( const void * ) & (
rtB ) , sizeof ( rtB ) ) ; { static const char * rtdwDataFieldNames [ 54 ] =
{ "rtDW.e42aspecmq" , "rtDW.blqbjt0rtj" , "rtDW.nvqz2cg41c" ,
"rtDW.f2m3u0xu0r" , "rtDW.nbwsnfqnlk" , "rtDW.doqeveoc11" , "rtDW.p4t13c2qkh"
, "rtDW.pmmw3kelkp" , "rtDW.pkauuknbee" , "rtDW.lwuqhty1j2" ,
"rtDW.f3xzmv2juc" , "rtDW.dvjbhtqxmw" , "rtDW.iyzdqyqxlc" , "rtDW.lzjct3gebg"
, "rtDW.nx4kcep112" , "rtDW.a5hpejqbid" , "rtDW.e4gutnhgzf" ,
"rtDW.i45jrqad2t" , "rtDW.pq0j2opq0v" , "rtDW.gx0nzawyk1" , "rtDW.e1fty5bnxj"
, "rtDW.addp1g5vdn" , "rtDW.iplu2tul0d" , "rtDW.aztlcwuvj4" ,
"rtDW.g3zekubeld" , "rtDW.kerw5fyz1o" , "rtDW.hzo55z2pdj" , "rtDW.mh4i1la1g4"
, "rtDW.jwqn22rjtx" , "rtDW.jjnjjs4i01" , "rtDW.otnlex10rk" ,
"rtDW.nozmgf3fmt" , "rtDW.nvbl4ewadw" , "rtDW.filnbm2liy" , "rtDW.nakmqyg1s0"
, "rtDW.ajr05m0wfh" , "rtDW.i0a3swey5k" , "rtDW.ktt1yqpggw" ,
"rtDW.bx2lamoanh" , "rtDW.cz0xtkwtbl" , "rtDW.hoowhfzk1u" , "rtDW.fr2favuzoz"
, "rtDW.lbwvzc51ur" , "rtDW.isyxaae0ta" , "rtDW.f4biz4rnh4" ,
"rtDW.bzi5sp21lh" , "rtDW.nghvchwmka" , "rtDW.kzhafiuqm5" , "rtDW.j5wwiwrs0c"
, "rtDW.hjta2mhewa" , "rtDW.i1hse0ipam" , "rtDW.ejfpjeh5m5" ,
"rtDW.kwwsfqauib" , "rtDW.m43xdundri" , } ; mxArray * rtdwData =
mxCreateStructMatrix ( 1 , 1 , 54 , rtdwDataFieldNames ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 0 , ( const void * )
& ( rtDW . e42aspecmq ) , sizeof ( rtDW . e42aspecmq ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 1 , ( const void * )
& ( rtDW . blqbjt0rtj ) , sizeof ( rtDW . blqbjt0rtj ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 2 , ( const void * )
& ( rtDW . nvqz2cg41c ) , sizeof ( rtDW . nvqz2cg41c ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 3 , ( const void * )
& ( rtDW . f2m3u0xu0r ) , sizeof ( rtDW . f2m3u0xu0r ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 4 , ( const void * )
& ( rtDW . nbwsnfqnlk ) , sizeof ( rtDW . nbwsnfqnlk ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 5 , ( const void * )
& ( rtDW . doqeveoc11 ) , sizeof ( rtDW . doqeveoc11 ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 6 , ( const void * )
& ( rtDW . p4t13c2qkh ) , sizeof ( rtDW . p4t13c2qkh ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 7 , ( const void * )
& ( rtDW . pmmw3kelkp ) , sizeof ( rtDW . pmmw3kelkp ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 8 , ( const void * )
& ( rtDW . pkauuknbee ) , sizeof ( rtDW . pkauuknbee ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 9 , ( const void * )
& ( rtDW . lwuqhty1j2 ) , sizeof ( rtDW . lwuqhty1j2 ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 10 , ( const void *
) & ( rtDW . f3xzmv2juc ) , sizeof ( rtDW . f3xzmv2juc ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 11 , ( const void *
) & ( rtDW . dvjbhtqxmw ) , sizeof ( rtDW . dvjbhtqxmw ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 12 , ( const void *
) & ( rtDW . iyzdqyqxlc ) , sizeof ( rtDW . iyzdqyqxlc ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 13 , ( const void *
) & ( rtDW . lzjct3gebg ) , sizeof ( rtDW . lzjct3gebg ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 14 , ( const void *
) & ( rtDW . nx4kcep112 ) , sizeof ( rtDW . nx4kcep112 ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 15 , ( const void *
) & ( rtDW . a5hpejqbid ) , sizeof ( rtDW . a5hpejqbid ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 16 , ( const void *
) & ( rtDW . e4gutnhgzf ) , sizeof ( rtDW . e4gutnhgzf ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 17 , ( const void *
) & ( rtDW . i45jrqad2t ) , sizeof ( rtDW . i45jrqad2t ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 18 , ( const void *
) & ( rtDW . pq0j2opq0v ) , sizeof ( rtDW . pq0j2opq0v ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 19 , ( const void *
) & ( rtDW . gx0nzawyk1 ) , sizeof ( rtDW . gx0nzawyk1 ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 20 , ( const void *
) & ( rtDW . e1fty5bnxj ) , sizeof ( rtDW . e1fty5bnxj ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 21 , ( const void *
) & ( rtDW . addp1g5vdn ) , sizeof ( rtDW . addp1g5vdn ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 22 , ( const void *
) & ( rtDW . iplu2tul0d ) , sizeof ( rtDW . iplu2tul0d ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 23 , ( const void *
) & ( rtDW . aztlcwuvj4 ) , sizeof ( rtDW . aztlcwuvj4 ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 24 , ( const void *
) & ( rtDW . g3zekubeld ) , sizeof ( rtDW . g3zekubeld ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 25 , ( const void *
) & ( rtDW . kerw5fyz1o ) , sizeof ( rtDW . kerw5fyz1o ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 26 , ( const void *
) & ( rtDW . hzo55z2pdj ) , sizeof ( rtDW . hzo55z2pdj ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 27 , ( const void *
) & ( rtDW . mh4i1la1g4 ) , sizeof ( rtDW . mh4i1la1g4 ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 28 , ( const void *
) & ( rtDW . jwqn22rjtx ) , sizeof ( rtDW . jwqn22rjtx ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 29 , ( const void *
) & ( rtDW . jjnjjs4i01 ) , sizeof ( rtDW . jjnjjs4i01 ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 30 , ( const void *
) & ( rtDW . otnlex10rk ) , sizeof ( rtDW . otnlex10rk ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 31 , ( const void *
) & ( rtDW . nozmgf3fmt ) , sizeof ( rtDW . nozmgf3fmt ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 32 , ( const void *
) & ( rtDW . nvbl4ewadw ) , sizeof ( rtDW . nvbl4ewadw ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 33 , ( const void *
) & ( rtDW . filnbm2liy ) , sizeof ( rtDW . filnbm2liy ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 34 , ( const void *
) & ( rtDW . nakmqyg1s0 ) , sizeof ( rtDW . nakmqyg1s0 ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 35 , ( const void *
) & ( rtDW . ajr05m0wfh ) , sizeof ( rtDW . ajr05m0wfh ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 36 , ( const void *
) & ( rtDW . i0a3swey5k ) , sizeof ( rtDW . i0a3swey5k ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 37 , ( const void *
) & ( rtDW . ktt1yqpggw ) , sizeof ( rtDW . ktt1yqpggw ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 38 , ( const void *
) & ( rtDW . bx2lamoanh ) , sizeof ( rtDW . bx2lamoanh ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 39 , ( const void *
) & ( rtDW . cz0xtkwtbl ) , sizeof ( rtDW . cz0xtkwtbl ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 40 , ( const void *
) & ( rtDW . hoowhfzk1u ) , sizeof ( rtDW . hoowhfzk1u ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 41 , ( const void *
) & ( rtDW . fr2favuzoz ) , sizeof ( rtDW . fr2favuzoz ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 42 , ( const void *
) & ( rtDW . lbwvzc51ur ) , sizeof ( rtDW . lbwvzc51ur ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 43 , ( const void *
) & ( rtDW . isyxaae0ta ) , sizeof ( rtDW . isyxaae0ta ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 44 , ( const void *
) & ( rtDW . f4biz4rnh4 ) , sizeof ( rtDW . f4biz4rnh4 ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 45 , ( const void *
) & ( rtDW . bzi5sp21lh ) , sizeof ( rtDW . bzi5sp21lh ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 46 , ( const void *
) & ( rtDW . nghvchwmka ) , sizeof ( rtDW . nghvchwmka ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 47 , ( const void *
) & ( rtDW . kzhafiuqm5 ) , sizeof ( rtDW . kzhafiuqm5 ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 48 , ( const void *
) & ( rtDW . j5wwiwrs0c ) , sizeof ( rtDW . j5wwiwrs0c ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 49 , ( const void *
) & ( rtDW . hjta2mhewa ) , sizeof ( rtDW . hjta2mhewa ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 50 , ( const void *
) & ( rtDW . i1hse0ipam ) , sizeof ( rtDW . i1hse0ipam ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 51 , ( const void *
) & ( rtDW . ejfpjeh5m5 ) , sizeof ( rtDW . ejfpjeh5m5 ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 52 , ( const void *
) & ( rtDW . kwwsfqauib ) , sizeof ( rtDW . kwwsfqauib ) ) ;
mr_Passive_balancing_cacheDataAsMxArray ( rtdwData , 0 , 53 , ( const void *
) & ( rtDW . m43xdundri ) , sizeof ( rtDW . m43xdundri ) ) ;
mxSetFieldByNumber ( ssDW , 0 , 1 , rtdwData ) ; }
mr_Passive_balancing_cacheDataAsMxArray ( ssDW , 0 , 2 , ( const void * ) & (
rtPrevZCX ) , sizeof ( rtPrevZCX ) ) ; return ssDW ; } void
mr_Passive_balancing_SetDWork ( const mxArray * ssDW ) { ( void ) ssDW ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtB ) , ssDW , 0
, 0 , sizeof ( rtB ) ) ; { const mxArray * rtdwData = mxGetFieldByNumber (
ssDW , 0 , 1 ) ; mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & (
rtDW . e42aspecmq ) , rtdwData , 0 , 0 , sizeof ( rtDW . e42aspecmq ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
blqbjt0rtj ) , rtdwData , 0 , 1 , sizeof ( rtDW . blqbjt0rtj ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
nvqz2cg41c ) , rtdwData , 0 , 2 , sizeof ( rtDW . nvqz2cg41c ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
f2m3u0xu0r ) , rtdwData , 0 , 3 , sizeof ( rtDW . f2m3u0xu0r ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
nbwsnfqnlk ) , rtdwData , 0 , 4 , sizeof ( rtDW . nbwsnfqnlk ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
doqeveoc11 ) , rtdwData , 0 , 5 , sizeof ( rtDW . doqeveoc11 ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
p4t13c2qkh ) , rtdwData , 0 , 6 , sizeof ( rtDW . p4t13c2qkh ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
pmmw3kelkp ) , rtdwData , 0 , 7 , sizeof ( rtDW . pmmw3kelkp ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
pkauuknbee ) , rtdwData , 0 , 8 , sizeof ( rtDW . pkauuknbee ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
lwuqhty1j2 ) , rtdwData , 0 , 9 , sizeof ( rtDW . lwuqhty1j2 ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
f3xzmv2juc ) , rtdwData , 0 , 10 , sizeof ( rtDW . f3xzmv2juc ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
dvjbhtqxmw ) , rtdwData , 0 , 11 , sizeof ( rtDW . dvjbhtqxmw ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
iyzdqyqxlc ) , rtdwData , 0 , 12 , sizeof ( rtDW . iyzdqyqxlc ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
lzjct3gebg ) , rtdwData , 0 , 13 , sizeof ( rtDW . lzjct3gebg ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
nx4kcep112 ) , rtdwData , 0 , 14 , sizeof ( rtDW . nx4kcep112 ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
a5hpejqbid ) , rtdwData , 0 , 15 , sizeof ( rtDW . a5hpejqbid ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
e4gutnhgzf ) , rtdwData , 0 , 16 , sizeof ( rtDW . e4gutnhgzf ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
i45jrqad2t ) , rtdwData , 0 , 17 , sizeof ( rtDW . i45jrqad2t ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
pq0j2opq0v ) , rtdwData , 0 , 18 , sizeof ( rtDW . pq0j2opq0v ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
gx0nzawyk1 ) , rtdwData , 0 , 19 , sizeof ( rtDW . gx0nzawyk1 ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
e1fty5bnxj ) , rtdwData , 0 , 20 , sizeof ( rtDW . e1fty5bnxj ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
addp1g5vdn ) , rtdwData , 0 , 21 , sizeof ( rtDW . addp1g5vdn ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
iplu2tul0d ) , rtdwData , 0 , 22 , sizeof ( rtDW . iplu2tul0d ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
aztlcwuvj4 ) , rtdwData , 0 , 23 , sizeof ( rtDW . aztlcwuvj4 ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
g3zekubeld ) , rtdwData , 0 , 24 , sizeof ( rtDW . g3zekubeld ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
kerw5fyz1o ) , rtdwData , 0 , 25 , sizeof ( rtDW . kerw5fyz1o ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
hzo55z2pdj ) , rtdwData , 0 , 26 , sizeof ( rtDW . hzo55z2pdj ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
mh4i1la1g4 ) , rtdwData , 0 , 27 , sizeof ( rtDW . mh4i1la1g4 ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
jwqn22rjtx ) , rtdwData , 0 , 28 , sizeof ( rtDW . jwqn22rjtx ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
jjnjjs4i01 ) , rtdwData , 0 , 29 , sizeof ( rtDW . jjnjjs4i01 ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
otnlex10rk ) , rtdwData , 0 , 30 , sizeof ( rtDW . otnlex10rk ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
nozmgf3fmt ) , rtdwData , 0 , 31 , sizeof ( rtDW . nozmgf3fmt ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
nvbl4ewadw ) , rtdwData , 0 , 32 , sizeof ( rtDW . nvbl4ewadw ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
filnbm2liy ) , rtdwData , 0 , 33 , sizeof ( rtDW . filnbm2liy ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
nakmqyg1s0 ) , rtdwData , 0 , 34 , sizeof ( rtDW . nakmqyg1s0 ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
ajr05m0wfh ) , rtdwData , 0 , 35 , sizeof ( rtDW . ajr05m0wfh ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
i0a3swey5k ) , rtdwData , 0 , 36 , sizeof ( rtDW . i0a3swey5k ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
ktt1yqpggw ) , rtdwData , 0 , 37 , sizeof ( rtDW . ktt1yqpggw ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
bx2lamoanh ) , rtdwData , 0 , 38 , sizeof ( rtDW . bx2lamoanh ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
cz0xtkwtbl ) , rtdwData , 0 , 39 , sizeof ( rtDW . cz0xtkwtbl ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
hoowhfzk1u ) , rtdwData , 0 , 40 , sizeof ( rtDW . hoowhfzk1u ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
fr2favuzoz ) , rtdwData , 0 , 41 , sizeof ( rtDW . fr2favuzoz ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
lbwvzc51ur ) , rtdwData , 0 , 42 , sizeof ( rtDW . lbwvzc51ur ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
isyxaae0ta ) , rtdwData , 0 , 43 , sizeof ( rtDW . isyxaae0ta ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
f4biz4rnh4 ) , rtdwData , 0 , 44 , sizeof ( rtDW . f4biz4rnh4 ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
bzi5sp21lh ) , rtdwData , 0 , 45 , sizeof ( rtDW . bzi5sp21lh ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
nghvchwmka ) , rtdwData , 0 , 46 , sizeof ( rtDW . nghvchwmka ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
kzhafiuqm5 ) , rtdwData , 0 , 47 , sizeof ( rtDW . kzhafiuqm5 ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
j5wwiwrs0c ) , rtdwData , 0 , 48 , sizeof ( rtDW . j5wwiwrs0c ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
hjta2mhewa ) , rtdwData , 0 , 49 , sizeof ( rtDW . hjta2mhewa ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
i1hse0ipam ) , rtdwData , 0 , 50 , sizeof ( rtDW . i1hse0ipam ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
ejfpjeh5m5 ) , rtdwData , 0 , 51 , sizeof ( rtDW . ejfpjeh5m5 ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
kwwsfqauib ) , rtdwData , 0 , 52 , sizeof ( rtDW . kwwsfqauib ) ) ;
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtDW .
m43xdundri ) , rtdwData , 0 , 53 , sizeof ( rtDW . m43xdundri ) ) ; }
mr_Passive_balancing_restoreDataFromMxArray ( ( void * ) & ( rtPrevZCX ) ,
ssDW , 0 , 2 , sizeof ( rtPrevZCX ) ) ; } mxArray *
mr_Passive_balancing_GetSimStateDisallowedBlocks ( ) { mxArray * data =
mxCreateCellMatrix ( 2 , 3 ) ; mwIndex subs [ 2 ] , offset ; { static const
char * blockType [ 2 ] = { "S-Function" , "S-Function" , } ; static const
char * blockPath [ 2 ] = {
"Passive_balancing/powergui/EquivalentModel1/State-Space" ,
"Passive_balancing/powergui/EquivalentModel1/State-Space" , } ; static const
int reason [ 2 ] = { 0 , 2 , } ; for ( subs [ 0 ] = 0 ; subs [ 0 ] < 2 ; ++ (
subs [ 0 ] ) ) { subs [ 1 ] = 0 ; offset = mxCalcSingleSubscript ( data , 2 ,
subs ) ; mxSetCell ( data , offset , mxCreateString ( blockType [ subs [ 0 ]
] ) ) ; subs [ 1 ] = 1 ; offset = mxCalcSingleSubscript ( data , 2 , subs ) ;
mxSetCell ( data , offset , mxCreateString ( blockPath [ subs [ 0 ] ] ) ) ;
subs [ 1 ] = 2 ; offset = mxCalcSingleSubscript ( data , 2 , subs ) ;
mxSetCell ( data , offset , mxCreateDoubleScalar ( ( double ) reason [ subs [
0 ] ] ) ) ; } } return data ; } void MdlInitializeSizes ( void ) {
ssSetNumContStates ( rtS , 12 ) ; ssSetNumPeriodicContStates ( rtS , 0 ) ;
ssSetNumY ( rtS , 0 ) ; ssSetNumU ( rtS , 0 ) ; ssSetDirectFeedThrough ( rtS
, 0 ) ; ssSetNumSampleTimes ( rtS , 2 ) ; ssSetNumBlocks ( rtS , 288 ) ;
ssSetNumBlockIO ( rtS , 149 ) ; ssSetNumBlockParams ( rtS , 821 ) ; } void
MdlInitializeSampleTimes ( void ) { ssSetSampleTime ( rtS , 0 , 0.0 ) ;
ssSetSampleTime ( rtS , 1 , 0.0 ) ; ssSetOffsetTime ( rtS , 0 , 0.0 ) ;
ssSetOffsetTime ( rtS , 1 , 1.0 ) ; } void raccel_set_checksum ( ) {
ssSetChecksumVal ( rtS , 0 , 808582686U ) ; ssSetChecksumVal ( rtS , 1 ,
3126849085U ) ; ssSetChecksumVal ( rtS , 2 , 4170160061U ) ; ssSetChecksumVal
( rtS , 3 , 2909507965U ) ; }
#if defined(_MSC_VER)
#pragma optimize( "", off )
#endif
SimStruct * raccel_register_model ( ssExecutionInfo * executionInfo ) {
static struct _ssMdlInfo mdlInfo ; ( void ) memset ( ( char * ) rtS , 0 ,
sizeof ( SimStruct ) ) ; ( void ) memset ( ( char * ) & mdlInfo , 0 , sizeof
( struct _ssMdlInfo ) ) ; ssSetMdlInfoPtr ( rtS , & mdlInfo ) ;
ssSetExecutionInfo ( rtS , executionInfo ) ; { static time_T mdlPeriod [
NSAMPLE_TIMES ] ; static time_T mdlOffset [ NSAMPLE_TIMES ] ; static time_T
mdlTaskTimes [ NSAMPLE_TIMES ] ; static int_T mdlTsMap [ NSAMPLE_TIMES ] ;
static int_T mdlSampleHits [ NSAMPLE_TIMES ] ; static boolean_T
mdlTNextWasAdjustedPtr [ NSAMPLE_TIMES ] ; static int_T mdlPerTaskSampleHits
[ NSAMPLE_TIMES * NSAMPLE_TIMES ] ; static time_T mdlTimeOfNextSampleHit [
NSAMPLE_TIMES ] ; { int_T i ; for ( i = 0 ; i < NSAMPLE_TIMES ; i ++ ) {
mdlPeriod [ i ] = 0.0 ; mdlOffset [ i ] = 0.0 ; mdlTaskTimes [ i ] = 0.0 ;
mdlTsMap [ i ] = i ; mdlSampleHits [ i ] = 1 ; } } ssSetSampleTimePtr ( rtS ,
& mdlPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rtS , & mdlOffset [ 0 ] ) ;
ssSetSampleTimeTaskIDPtr ( rtS , & mdlTsMap [ 0 ] ) ; ssSetTPtr ( rtS , &
mdlTaskTimes [ 0 ] ) ; ssSetSampleHitPtr ( rtS , & mdlSampleHits [ 0 ] ) ;
ssSetTNextWasAdjustedPtr ( rtS , & mdlTNextWasAdjustedPtr [ 0 ] ) ;
ssSetPerTaskSampleHitsPtr ( rtS , & mdlPerTaskSampleHits [ 0 ] ) ;
ssSetTimeOfNextSampleHitPtr ( rtS , & mdlTimeOfNextSampleHit [ 0 ] ) ; }
ssSetSolverMode ( rtS , SOLVER_MODE_SINGLETASKING ) ; { ssSetBlockIO ( rtS ,
( ( void * ) & rtB ) ) ; ( void ) memset ( ( ( void * ) & rtB ) , 0 , sizeof
( B ) ) ; } { real_T * x = ( real_T * ) & rtX ; ssSetContStates ( rtS , x ) ;
( void ) memset ( ( void * ) x , 0 , sizeof ( X ) ) ; } { void * dwork = (
void * ) & rtDW ; ssSetRootDWork ( rtS , dwork ) ; ( void ) memset ( dwork ,
0 , sizeof ( DW ) ) ; } { static DataTypeTransInfo dtInfo ; ( void ) memset (
( char_T * ) & dtInfo , 0 , sizeof ( dtInfo ) ) ; ssSetModelMappingInfo ( rtS
, & dtInfo ) ; dtInfo . numDataTypes = 14 ; dtInfo . dataTypeSizes = &
rtDataTypeSizes [ 0 ] ; dtInfo . dataTypeNames = & rtDataTypeNames [ 0 ] ;
dtInfo . BTransTable = & rtBTransTable ; dtInfo . PTransTable = &
rtPTransTable ; dtInfo . dataTypeInfoTable = rtDataTypeInfoTable ; }
Passive_balancing_InitializeDataMapInfo ( ) ; ssSetIsRapidAcceleratorActive (
rtS , true ) ; ssSetRootSS ( rtS , rtS ) ; ssSetVersion ( rtS ,
SIMSTRUCT_VERSION_LEVEL2 ) ; ssSetModelName ( rtS , "Passive_balancing" ) ;
ssSetPath ( rtS , "Passive_balancing" ) ; ssSetTStart ( rtS , 0.0 ) ;
ssSetTFinal ( rtS , 300.0 ) ; { static RTWLogInfo rt_DataLoggingInfo ;
rt_DataLoggingInfo . loggingInterval = ( NULL ) ; ssSetRTWLogInfo ( rtS , &
rt_DataLoggingInfo ) ; } { { static int_T rt_LoggedStateWidths [ ] = { 1 , 1
, 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 } ; static int_T
rt_LoggedStateNumDimensions [ ] = { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1
, 1 } ; static int_T rt_LoggedStateDimensions [ ] = { 1 , 1 , 1 , 1 , 1 , 1 ,
1 , 1 , 1 , 1 , 1 , 1 } ; static boolean_T rt_LoggedStateIsVarDims [ ] = { 0
, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } ; static BuiltInDTypeId
rt_LoggedStateDataTypeIds [ ] = { SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE } ; static int_T
rt_LoggedStateComplexSignals [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 } ; static RTWPreprocessingFcnPtr rt_LoggingStatePreprocessingFcnPtrs [
] = { ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , (
NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) } ; static
const char_T * rt_LoggedStateLabels [ ] = { "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" , "CSTATE" } ; static const char_T * rt_LoggedStateBlockNames [ ] =
{ "Passive_balancing/Battery/Model/Current filter" ,
"Passive_balancing/Battery/Model/int(i)" ,
"Passive_balancing/Battery/Model/Exp/Integrator2" ,
"Passive_balancing/Battery/Model/BAL" ,
"Passive_balancing/Battery1/Model/Current filter" ,
"Passive_balancing/Battery1/Model/int(i)" ,
"Passive_balancing/Battery1/Model/Exp/Integrator2" ,
"Passive_balancing/Battery1/Model/BAL" ,
"Passive_balancing/Battery2/Model/Current filter" ,
"Passive_balancing/Battery2/Model/int(i)" ,
"Passive_balancing/Battery2/Model/Exp/Integrator2" ,
"Passive_balancing/Battery2/Model/BAL" } ; static const char_T *
rt_LoggedStateNames [ ] = { "" , "" , "" , "" , "" , "" , "" , "" , "" , "" ,
"" , "" } ; static boolean_T rt_LoggedStateCrossMdlRef [ ] = { 0 , 0 , 0 , 0
, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } ; static RTWLogDataTypeConvert
rt_RTWLogDataTypeConvert [ ] = { { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 ,
1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } ,
{ 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } } ; static
int_T rt_LoggedStateIdxList [ ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 ,
10 , 11 } ; static RTWLogSignalInfo rt_LoggedStateSignalInfo = { 12 ,
rt_LoggedStateWidths , rt_LoggedStateNumDimensions , rt_LoggedStateDimensions
, rt_LoggedStateIsVarDims , ( NULL ) , ( NULL ) , rt_LoggedStateDataTypeIds ,
rt_LoggedStateComplexSignals , ( NULL ) , rt_LoggingStatePreprocessingFcnPtrs
, { rt_LoggedStateLabels } , ( NULL ) , ( NULL ) , ( NULL ) , {
rt_LoggedStateBlockNames } , { rt_LoggedStateNames } ,
rt_LoggedStateCrossMdlRef , rt_RTWLogDataTypeConvert , rt_LoggedStateIdxList
} ; static void * rt_LoggedStateSignalPtrs [ 12 ] ; rtliSetLogXSignalPtrs (
ssGetRTWLogInfo ( rtS ) , ( LogSignalPtrsType ) rt_LoggedStateSignalPtrs ) ;
rtliSetLogXSignalInfo ( ssGetRTWLogInfo ( rtS ) , & rt_LoggedStateSignalInfo
) ; rt_LoggedStateSignalPtrs [ 0 ] = ( void * ) & rtX . llwavd3uol ;
rt_LoggedStateSignalPtrs [ 1 ] = ( void * ) & rtX . ifbj2oqhyc ;
rt_LoggedStateSignalPtrs [ 2 ] = ( void * ) & rtX . ifq0x11cs2 ;
rt_LoggedStateSignalPtrs [ 3 ] = ( void * ) & rtX . e1x530c3es ;
rt_LoggedStateSignalPtrs [ 4 ] = ( void * ) & rtX . cs01gdjeym ;
rt_LoggedStateSignalPtrs [ 5 ] = ( void * ) & rtX . pfxj2ul3dz ;
rt_LoggedStateSignalPtrs [ 6 ] = ( void * ) & rtX . akpflzngjb ;
rt_LoggedStateSignalPtrs [ 7 ] = ( void * ) & rtX . jmchzhaobx ;
rt_LoggedStateSignalPtrs [ 8 ] = ( void * ) & rtX . otk33ad0ab ;
rt_LoggedStateSignalPtrs [ 9 ] = ( void * ) & rtX . p3nmfmnma0 ;
rt_LoggedStateSignalPtrs [ 10 ] = ( void * ) & rtX . jws0lo1qo5 ;
rt_LoggedStateSignalPtrs [ 11 ] = ( void * ) & rtX . g004y4jnca ; }
rtliSetLogT ( ssGetRTWLogInfo ( rtS ) , "tout" ) ; rtliSetLogX (
ssGetRTWLogInfo ( rtS ) , "" ) ; rtliSetLogXFinal ( ssGetRTWLogInfo ( rtS ) ,
"" ) ; rtliSetLogVarNameModifier ( ssGetRTWLogInfo ( rtS ) , "none" ) ;
rtliSetLogFormat ( ssGetRTWLogInfo ( rtS ) , 4 ) ; rtliSetLogMaxRows (
ssGetRTWLogInfo ( rtS ) , 0 ) ; rtliSetLogDecimation ( ssGetRTWLogInfo ( rtS
) , 1 ) ; rtliSetLogY ( ssGetRTWLogInfo ( rtS ) , "" ) ;
rtliSetLogYSignalInfo ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ;
rtliSetLogYSignalPtrs ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ; } { static
struct _ssStatesInfo2 statesInfo2 ; ssSetStatesInfo2 ( rtS , & statesInfo2 )
; } { static ssPeriodicStatesInfo periodicStatesInfo ;
ssSetPeriodicStatesInfo ( rtS , & periodicStatesInfo ) ; } { static
ssJacobianPerturbationBounds jacobianPerturbationBounds ;
ssSetJacobianPerturbationBounds ( rtS , & jacobianPerturbationBounds ) ; } {
static ssSolverInfo slvrInfo ; static boolean_T contStatesDisabled [ 12 ] ;
static real_T absTol [ 12 ] = { 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 ,
1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 } ; static
uint8_T absTolControl [ 12 ] = { 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U ,
0U , 0U , 0U } ; static real_T contStateJacPerturbBoundMinVec [ 12 ] ; static
real_T contStateJacPerturbBoundMaxVec [ 12 ] ; static uint8_T zcAttributes [
61 ] = { ( ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP )
, ( ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL
) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL )
, ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( 0xc0 | ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_DN ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , (
ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) } ;
static ssNonContDerivSigInfo nonContDerivSigInfo [ 45 ] = { { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . k1ekc1vsf0 ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . anyjfk53qp ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . abcbugh4lq ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . l3y1twbqro ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . gnspd531yz ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . ldgus1sr1s ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . etnpopllbl ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . ivq3zpd1bd ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . ctnsceddfy ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . hoc1uowy0l ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . c0s1abefak ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . jlf0hrvb5z ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . bybzbvcgip ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . p11j5vzjvf ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . liehtgeamk ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . pvm1yyq1x2 ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . pdw4w0iukq ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . h1cgh2p3m1 ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . k1a40pib50 ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . o2yv2v00xl ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . cfgua3mzpn ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . cun2lttrzh ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . byn2laotwy ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . nfpqqtt4xe ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . etmrit0r0u ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . apjpswajes ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . brbu1ojabk ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . hfuuf2ubg0 ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . emt33ggwjf ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . f0c2kodzql ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . h22uhfy2kg ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . bkaepijqzl ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . jdzd4nb0ri ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . gyuxlbpm5v ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . irwvsmo3n1 ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . l0gpduqluz ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . datxyxwqsn ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . fiehiuyw0k ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . p03chjpubi ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . onwyx43zfl ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . djaii0vejs ) , ( NULL ) } , { 1 * sizeof (
boolean_T ) , ( char * ) ( & rtB . oipsn2ext2 ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . d5an0i50bp ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . jw451fwnvv ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . brzjamghps ) , ( NULL ) } } ; { int i ; for (
i = 0 ; i < 12 ; ++ i ) { contStateJacPerturbBoundMinVec [ i ] = 0 ;
contStateJacPerturbBoundMaxVec [ i ] = rtGetInf ( ) ; } } ssSetSolverRelTol (
rtS , 0.001 ) ; ssSetStepSize ( rtS , 0.0 ) ; ssSetMinStepSize ( rtS , 0.0 )
; ssSetMaxNumMinSteps ( rtS , - 1 ) ; ssSetMinStepViolatedError ( rtS , 0 ) ;
ssSetMaxStepSize ( rtS , 0.001 ) ; ssSetSolverMaxOrder ( rtS , - 1 ) ;
ssSetSolverRefineFactor ( rtS , 1 ) ; ssSetOutputTimes ( rtS , ( NULL ) ) ;
ssSetNumOutputTimes ( rtS , 0 ) ; ssSetOutputTimesOnly ( rtS , 0 ) ;
ssSetOutputTimesIndex ( rtS , 0 ) ; ssSetZCCacheNeedsReset ( rtS , 1 ) ;
ssSetDerivCacheNeedsReset ( rtS , 0 ) ; ssSetNumNonContDerivSigInfos ( rtS ,
45 ) ; ssSetNonContDerivSigInfos ( rtS , nonContDerivSigInfo ) ;
ssSetSolverInfo ( rtS , & slvrInfo ) ; ssSetSolverName ( rtS , "ode23tb" ) ;
ssSetVariableStepSolver ( rtS , 1 ) ; ssSetSolverConsistencyChecking ( rtS ,
0 ) ; ssSetSolverAdaptiveZcDetection ( rtS , 0 ) ;
ssSetSolverRobustResetMethod ( rtS , 0 ) ; ssSetAbsTolVector ( rtS , absTol )
; ssSetAbsTolControlVector ( rtS , absTolControl ) ;
ssSetSolverAbsTol_Obsolete ( rtS , absTol ) ;
ssSetSolverAbsTolControl_Obsolete ( rtS , absTolControl ) ;
ssSetJacobianPerturbationBoundsMinVec ( rtS , contStateJacPerturbBoundMinVec
) ; ssSetJacobianPerturbationBoundsMaxVec ( rtS ,
contStateJacPerturbBoundMaxVec ) ; ssSetSolverStateProjection ( rtS , 0 ) ;
ssSetSolverMassMatrixType ( rtS , ( ssMatrixType ) 0 ) ;
ssSetSolverMassMatrixNzMax ( rtS , 0 ) ; ssSetModelOutputs ( rtS , MdlOutputs
) ; ssSetModelLogData ( rtS , rt_UpdateTXYLogVars ) ;
ssSetModelLogDataIfInInterval ( rtS , rt_UpdateTXXFYLogVars ) ;
ssSetModelUpdate ( rtS , MdlUpdate ) ; ssSetModelDerivatives ( rtS ,
MdlDerivatives ) ; ssSetSolverZcSignalAttrib ( rtS , zcAttributes ) ;
ssSetSolverNumZcSignals ( rtS , 61 ) ; ssSetModelZeroCrossings ( rtS ,
MdlZeroCrossings ) ; ssSetSolverConsecutiveZCsStepRelTol ( rtS ,
2.8421709430404007E-13 ) ; ssSetSolverMaxConsecutiveZCs ( rtS , 1000 ) ;
ssSetSolverConsecutiveZCsError ( rtS , 2 ) ; ssSetSolverMaskedZcDiagnostic (
rtS , 1 ) ; ssSetSolverIgnoredZcDiagnostic ( rtS , 1 ) ;
ssSetSolverMaxConsecutiveMinStep ( rtS , 1 ) ;
ssSetSolverShapePreserveControl ( rtS , 2 ) ; ssSetTNextTid ( rtS , INT_MIN )
; ssSetTNext ( rtS , rtMinusInf ) ; ssSetSolverNeedsReset ( rtS ) ;
ssSetNumNonsampledZCs ( rtS , 58 ) ; ssSetContStateDisabled ( rtS ,
contStatesDisabled ) ; ssSetSolverMaxConsecutiveMinStep ( rtS , 1 ) ; } {
ZCSigState * zc = ( ZCSigState * ) & rtPrevZCX ; ssSetPrevZCSigState ( rtS ,
zc ) ; } { rtPrevZCX . pmftj50xl0 = UNINITIALIZED_ZCSIG ; rtPrevZCX .
abvz0x2czi = UNINITIALIZED_ZCSIG ; rtPrevZCX . jnr2ivwps5 =
UNINITIALIZED_ZCSIG ; } ssSetChecksumVal ( rtS , 0 , 808582686U ) ;
ssSetChecksumVal ( rtS , 1 , 3126849085U ) ; ssSetChecksumVal ( rtS , 2 ,
4170160061U ) ; ssSetChecksumVal ( rtS , 3 , 2909507965U ) ; { static const
sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE ; static RTWExtModeInfo
rt_ExtModeInfo ; static const sysRanDType * systemRan [ 26 ] ;
gblRTWExtModeInfo = & rt_ExtModeInfo ; ssSetRTWExtModeInfo ( rtS , &
rt_ExtModeInfo ) ; rteiSetSubSystemActiveVectorAddresses ( & rt_ExtModeInfo ,
systemRan ) ; systemRan [ 0 ] = & rtAlwaysEnabled ; systemRan [ 1 ] = &
rtAlwaysEnabled ; systemRan [ 2 ] = & rtAlwaysEnabled ; systemRan [ 3 ] = &
rtAlwaysEnabled ; systemRan [ 4 ] = & rtAlwaysEnabled ; systemRan [ 5 ] = &
rtAlwaysEnabled ; systemRan [ 6 ] = & rtAlwaysEnabled ; systemRan [ 7 ] = &
rtAlwaysEnabled ; systemRan [ 8 ] = & rtAlwaysEnabled ; systemRan [ 9 ] = &
rtAlwaysEnabled ; systemRan [ 10 ] = & rtAlwaysEnabled ; systemRan [ 11 ] = &
rtAlwaysEnabled ; systemRan [ 12 ] = & rtAlwaysEnabled ; systemRan [ 13 ] = &
rtAlwaysEnabled ; systemRan [ 14 ] = & rtAlwaysEnabled ; systemRan [ 15 ] = &
rtAlwaysEnabled ; systemRan [ 16 ] = & rtAlwaysEnabled ; systemRan [ 17 ] = &
rtAlwaysEnabled ; systemRan [ 18 ] = & rtAlwaysEnabled ; systemRan [ 19 ] = &
rtAlwaysEnabled ; systemRan [ 20 ] = & rtAlwaysEnabled ; systemRan [ 21 ] = &
rtAlwaysEnabled ; systemRan [ 22 ] = & rtAlwaysEnabled ; systemRan [ 23 ] = &
rtAlwaysEnabled ; systemRan [ 24 ] = & rtAlwaysEnabled ; systemRan [ 25 ] = &
rtAlwaysEnabled ; rteiSetModelMappingInfoPtr ( ssGetRTWExtModeInfo ( rtS ) ,
& ssGetModelMappingInfo ( rtS ) ) ; rteiSetChecksumsPtr ( ssGetRTWExtModeInfo
( rtS ) , ssGetChecksums ( rtS ) ) ; rteiSetTPtr ( ssGetRTWExtModeInfo ( rtS
) , ssGetTPtr ( rtS ) ) ; } slsaDisallowedBlocksForSimTargetOP ( rtS ,
mr_Passive_balancing_GetSimStateDisallowedBlocks ) ;
slsaGetWorkFcnForSimTargetOP ( rtS , mr_Passive_balancing_GetDWork ) ;
slsaSetWorkFcnForSimTargetOP ( rtS , mr_Passive_balancing_SetDWork ) ; rtP .
inti_LowerSat = rtMinusInf ; rtP . Saturation_LowerSat = rtMinusInf ; rtP .
inti_LowerSat_hzpmw3xl5s = rtMinusInf ; rtP . Saturation_LowerSat_haspwmkdbs
= rtMinusInf ; rtP . inti_LowerSat_ntmgylsy20 = rtMinusInf ; rtP .
Saturation_LowerSat_pt1ot4ctql = rtMinusInf ;
rt_RapidReadMatFileAndUpdateParams ( rtS ) ; if ( ssGetErrorStatus ( rtS ) )
{ return rtS ; } ssSetNumSFunctions ( rtS , 1 ) ; { static SimStruct
childSFunctions [ 1 ] ; static SimStruct * childSFunctionPtrs [ 1 ] ; ( void
) memset ( ( void * ) & childSFunctions [ 0 ] , 0 , sizeof ( childSFunctions
) ) ; ssSetSFunctions ( rtS , & childSFunctionPtrs [ 0 ] ) ; ssSetSFunction (
rtS , 0 , & childSFunctions [ 0 ] ) ; { SimStruct * rts = ssGetSFunction (
rtS , 0 ) ; static time_T sfcnPeriod [ 1 ] ; static time_T sfcnOffset [ 1 ] ;
static int_T sfcnTsMap [ 1 ] ; ( void ) memset ( ( void * ) sfcnPeriod , 0 ,
sizeof ( time_T ) * 1 ) ; ( void ) memset ( ( void * ) sfcnOffset , 0 ,
sizeof ( time_T ) * 1 ) ; ssSetSampleTimePtr ( rts , & sfcnPeriod [ 0 ] ) ;
ssSetOffsetTimePtr ( rts , & sfcnOffset [ 0 ] ) ; ssSetSampleTimeTaskIDPtr (
rts , sfcnTsMap ) ; { static struct _ssBlkInfo2 _blkInfo2 ; struct
_ssBlkInfo2 * blkInfo2 = & _blkInfo2 ; ssSetBlkInfo2Ptr ( rts , blkInfo2 ) ;
} { static struct _ssPortInfo2 _portInfo2 ; struct _ssPortInfo2 * portInfo2 =
& _portInfo2 ; _ssSetBlkInfo2PortInfo2Ptr ( rts , portInfo2 ) ; }
ssSetMdlInfoPtr ( rts , ssGetMdlInfoPtr ( rtS ) ) ; { static struct
_ssSFcnModelMethods2 methods2 ; ssSetModelMethods2 ( rts , & methods2 ) ; } {
static struct _ssSFcnModelMethods3 methods3 ; ssSetModelMethods3 ( rts , &
methods3 ) ; } { static struct _ssSFcnModelMethods4 methods4 ;
ssSetModelMethods4 ( rts , & methods4 ) ; } { static struct _ssStatesInfo2
statesInfo2 ; static ssPeriodicStatesInfo periodicStatesInfo ; static
ssJacobianPerturbationBounds jacPerturbationBounds ; ssSetStatesInfo2 ( rts ,
& statesInfo2 ) ; ssSetPeriodicStatesInfo ( rts , & periodicStatesInfo ) ;
ssSetJacobianPerturbationBounds ( rts , & jacPerturbationBounds ) ; } {
static struct _ssPortInputs inputPortInfo [ 2 ] ; _ssSetNumInputPorts ( rts ,
2 ) ; ssSetPortInfoForInputs ( rts , & inputPortInfo [ 0 ] ) ; { static
struct _ssInPortUnit inputPortUnits [ 2 ] ; _ssSetPortInfo2ForInputUnits (
rts , & inputPortUnits [ 0 ] ) ; } ssSetInputPortUnit ( rts , 0 , 0 ) ;
ssSetInputPortUnit ( rts , 1 , 0 ) ; { static struct _ssInPortCoSimAttribute
inputPortCoSimAttribute [ 2 ] ; _ssSetPortInfo2ForInputCoSimAttribute ( rts ,
& inputPortCoSimAttribute [ 0 ] ) ; } ssSetInputPortIsContinuousQuantity (
rts , 0 , 0 ) ; ssSetInputPortIsContinuousQuantity ( rts , 1 , 0 ) ; { static
real_T const * sfcnUPtrs [ 6 ] ; sfcnUPtrs [ 0 ] = & rtB . bmrka5l5eq ;
sfcnUPtrs [ 1 ] = & rtB . gwm55h223z ; sfcnUPtrs [ 2 ] = & rtB . kjglqur00l ;
sfcnUPtrs [ 3 ] = & rtB . gisoswnzov ; sfcnUPtrs [ 4 ] = & rtB . be1yt0sowu ;
sfcnUPtrs [ 5 ] = & rtB . do3x3pi1jp ; ssSetInputPortSignalPtrs ( rts , 0 , (
InputPtrsType ) & sfcnUPtrs [ 0 ] ) ; _ssSetInputPortNumDimensions ( rts , 0
, 1 ) ; ssSetInputPortWidth ( rts , 0 , 6 ) ; } { static real_T const *
sfcnUPtrs [ 3 ] ; sfcnUPtrs [ 0 ] = & rtB . easujerxmm ; sfcnUPtrs [ 1 ] = &
rtB . i1ccd4rxd5 ; sfcnUPtrs [ 2 ] = & rtB . exhgo3ztsa ;
ssSetInputPortSignalPtrs ( rts , 1 , ( InputPtrsType ) & sfcnUPtrs [ 0 ] ) ;
_ssSetInputPortNumDimensions ( rts , 1 , 1 ) ; ssSetInputPortWidth ( rts , 1
, 3 ) ; } } { static struct _ssPortOutputs outputPortInfo [ 2 ] ;
ssSetPortInfoForOutputs ( rts , & outputPortInfo [ 0 ] ) ;
_ssSetNumOutputPorts ( rts , 2 ) ; { static struct _ssOutPortUnit
outputPortUnits [ 2 ] ; _ssSetPortInfo2ForOutputUnits ( rts , &
outputPortUnits [ 0 ] ) ; } ssSetOutputPortUnit ( rts , 0 , 0 ) ;
ssSetOutputPortUnit ( rts , 1 , 0 ) ; { static struct
_ssOutPortCoSimAttribute outputPortCoSimAttribute [ 2 ] ;
_ssSetPortInfo2ForOutputCoSimAttribute ( rts , & outputPortCoSimAttribute [ 0
] ) ; } ssSetOutputPortIsContinuousQuantity ( rts , 0 , 0 ) ;
ssSetOutputPortIsContinuousQuantity ( rts , 1 , 0 ) ; {
_ssSetOutputPortNumDimensions ( rts , 0 , 1 ) ; ssSetOutputPortWidth ( rts ,
0 , 3 ) ; ssSetOutputPortSignal ( rts , 0 , ( ( real_T * ) rtB . dagypwp03e )
) ; } { _ssSetOutputPortNumDimensions ( rts , 1 , 1 ) ; ssSetOutputPortWidth
( rts , 1 , 6 ) ; ssSetOutputPortSignal ( rts , 1 , ( ( real_T * ) rtB .
hkblhik3th ) ) ; } } ssSetModelName ( rts , "State-Space" ) ; ssSetPath ( rts
, "Passive_balancing/powergui/EquivalentModel1/State-Space" ) ; if (
ssGetRTModel ( rtS ) == ( NULL ) ) { ssSetParentSS ( rts , rtS ) ;
ssSetRootSS ( rts , ssGetRootSS ( rtS ) ) ; } else { ssSetRTModel ( rts ,
ssGetRTModel ( rtS ) ) ; ssSetParentSS ( rts , ( NULL ) ) ; ssSetRootSS ( rts
, rts ) ; } ssSetVersion ( rts , SIMSTRUCT_VERSION_LEVEL2 ) ; { static
mxArray * sfcnParams [ 10 ] ; ssSetSFcnParamsCount ( rts , 10 ) ;
ssSetSFcnParamsPtr ( rts , & sfcnParams [ 0 ] ) ; ssSetSFcnParam ( rts , 0 ,
( mxArray * ) rtP . StateSpace_P1_Size ) ; ssSetSFcnParam ( rts , 1 , (
mxArray * ) rtP . StateSpace_P2_Size ) ; ssSetSFcnParam ( rts , 2 , ( mxArray
* ) rtP . StateSpace_P3_Size ) ; ssSetSFcnParam ( rts , 3 , ( mxArray * ) rtP
. StateSpace_P4_Size ) ; ssSetSFcnParam ( rts , 4 , ( mxArray * ) rtP .
StateSpace_P5_Size ) ; ssSetSFcnParam ( rts , 5 , ( mxArray * ) rtP .
StateSpace_P6_Size ) ; ssSetSFcnParam ( rts , 6 , ( mxArray * ) rtP .
StateSpace_P7_Size ) ; ssSetSFcnParam ( rts , 7 , ( mxArray * ) rtP .
StateSpace_P8_Size ) ; ssSetSFcnParam ( rts , 8 , ( mxArray * ) rtP .
StateSpace_P9_Size ) ; ssSetSFcnParam ( rts , 9 , ( mxArray * ) rtP .
StateSpace_P10_Size ) ; } ssSetRWork ( rts , ( real_T * ) & rtDW . p4t13c2qkh
[ 0 ] ) ; ssSetIWork ( rts , ( int_T * ) & rtDW . f3xzmv2juc [ 0 ] ) ;
ssSetPWork ( rts , ( void * * ) & rtDW . d05nmt3jlb [ 0 ] ) ; { static struct
_ssDWorkRecord dWorkRecord [ 4 ] ; static struct _ssDWorkAuxRecord
dWorkAuxRecord [ 4 ] ; ssSetSFcnDWork ( rts , dWorkRecord ) ;
ssSetSFcnDWorkAux ( rts , dWorkAuxRecord ) ; _ssSetNumDWork ( rts , 4 ) ;
ssSetDWorkWidth ( rts , 0 , 4 ) ; ssSetDWorkDataType ( rts , 0 , SS_INTEGER )
; ssSetDWorkComplexSignal ( rts , 0 , 0 ) ; ssSetDWork ( rts , 0 , & rtDW .
i45jrqad2t [ 0 ] ) ; ssSetDWorkWidth ( rts , 1 , 2 ) ; ssSetDWorkDataType (
rts , 1 , SS_DOUBLE ) ; ssSetDWorkComplexSignal ( rts , 1 , 0 ) ; ssSetDWork
( rts , 1 , & rtDW . p4t13c2qkh [ 0 ] ) ; ssSetDWorkWidth ( rts , 2 , 23 ) ;
ssSetDWorkDataType ( rts , 2 , SS_INTEGER ) ; ssSetDWorkComplexSignal ( rts ,
2 , 0 ) ; ssSetDWork ( rts , 2 , & rtDW . f3xzmv2juc [ 0 ] ) ;
ssSetDWorkWidth ( rts , 3 , 22 ) ; ssSetDWorkDataType ( rts , 3 , SS_POINTER
) ; ssSetDWorkComplexSignal ( rts , 3 , 0 ) ; ssSetDWork ( rts , 3 , & rtDW .
d05nmt3jlb [ 0 ] ) ; } ssSetModeVector ( rts , ( int_T * ) & rtDW .
i45jrqad2t [ 0 ] ) ; sfun_spid_contc ( rts ) ; sfcnInitializeSizes ( rts ) ;
sfcnInitializeSampleTimes ( rts ) ; ssSetSampleTime ( rts , 0 , 0.0 ) ;
ssSetOffsetTime ( rts , 0 , 0.0 ) ; sfcnTsMap [ 0 ] = 0 ;
ssSetNumNonsampledZCs ( rts , 4 ) ; _ssSetInputPortConnected ( rts , 0 , 1 )
; _ssSetInputPortConnected ( rts , 1 , 1 ) ; _ssSetOutputPortConnected ( rts
, 0 , 1 ) ; _ssSetOutputPortConnected ( rts , 1 , 1 ) ;
_ssSetOutputPortBeingMerged ( rts , 0 , 0 ) ; _ssSetOutputPortBeingMerged (
rts , 1 , 0 ) ; ssSetInputPortBufferDstPort ( rts , 0 , - 1 ) ;
ssSetInputPortBufferDstPort ( rts , 1 , - 1 ) ; } } return rtS ; }
#if defined(_MSC_VER)
#pragma optimize( "", on )
#endif
const int_T gblParameterTuningTid = 2 ; void MdlOutputsParameterSampleTime (
int_T tid ) { MdlOutputsTID2 ( tid ) ; }
