#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "Passive_balancing_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)    
#else
#include "builtin_typeid_types.h"
#include "Passive_balancing.h"
#include "Passive_balancing_capi.h"
#include "Passive_balancing_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST                  
#define TARGET_STRING(s)               (NULL)                    
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static const rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 25 , TARGET_STRING
( "Passive_balancing/MATLAB Function" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 1 , 25 , TARGET_STRING ( "Passive_balancing/MATLAB Function" ) ,
TARGET_STRING ( "" ) , 1 , 0 , 0 , 0 , 0 } , { 2 , 25 , TARGET_STRING (
"Passive_balancing/MATLAB Function" ) , TARGET_STRING ( "" ) , 2 , 0 , 0 , 0
, 0 } , { 3 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 4 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 5 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 6 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 7 , 0 , TARGET_STRING ( "Passive_balancing/Battery/Model/Fcn6" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 8 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 9 , 0 , TARGET_STRING ( "Passive_balancing/Battery/Model/Gain" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 10 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 11 , 0 , TARGET_STRING ( "Passive_balancing/Battery/Model/R1" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 12 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 13 , 0 , TARGET_STRING ( "Passive_balancing/Battery/Model/R3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 14 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 1 } , { 15 , 0 , TARGET_STRING ( "Passive_balancing/Battery/Model/int(i)" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 16 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 17 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 18 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 19 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 20 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 21 , 0 , TARGET_STRING ( "Passive_balancing/Battery/Model/Add3" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 22 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 23 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 24 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 25 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 26 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 27 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 28 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 29 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Fcn6" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 1 } , { 30 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 1 } , { 31 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Gain" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 32 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 33 , 0 , TARGET_STRING ( "Passive_balancing/Battery1/Model/R1"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 34 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 35 , 0 , TARGET_STRING ( "Passive_balancing/Battery1/Model/R3" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 36 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 37 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/int(i)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 38 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 39 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 40 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 41 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 42 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 43 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 44 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 45 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 46 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 47 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 48 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Data Type Conversion1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 49 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Data Type Conversion2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 50 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Fcn1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 51 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Fcn6" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 1 } , { 52 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Fcn9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 1 } , { 53 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Gain" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 54 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Gain2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 55 , 0 , TARGET_STRING ( "Passive_balancing/Battery2/Model/R1"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 56 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/R2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 57 , 0 , TARGET_STRING ( "Passive_balancing/Battery2/Model/R3" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 58 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/R4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 1 } , { 59 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/int(i)" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 60 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/it init" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 1 } , { 61 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/it init1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 62 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Relational Operator" ) , TARGET_STRING ( ""
) , 0 , 1 , 0 , 0 , 1 } , { 63 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Saturation" ) , TARGET_STRING ( "SOC (%)" )
, 0 , 0 , 0 , 0 , 0 } , { 64 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Add2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 65 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 66 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Switch7" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 67 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/BAL" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 68 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Current filter" ) , TARGET_STRING (
"Current (A)" ) , 0 , 0 , 0 , 0 , 0 } , { 69 , 0 , TARGET_STRING (
"Passive_balancing/IGBT/Model/qqq" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 ,
2 } , { 70 , 0 , TARGET_STRING ( "Passive_balancing/IGBT1/Model/qqq" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 2 } , { 71 , 0 , TARGET_STRING (
"Passive_balancing/IGBT2/Model/qqq" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 2 } , { 72 , 0 , TARGET_STRING (
"Passive_balancing/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"" ) , 0 , 0 , 1 , 0 , 0 } , { 73 , 0 , TARGET_STRING (
"Passive_balancing/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"" ) , 1 , 0 , 2 , 0 , 0 } , { 74 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 75 , 2 , TARGET_STRING (
"Passive_balancing/Battery/Model/E_dyn Charge/Product" ) , TARGET_STRING ( ""
) , 0 , 0 , 3 , 0 , 0 } , { 76 , 4 , TARGET_STRING (
"Passive_balancing/Battery/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 3 , 0 , 0 } , { 77 , 3 , TARGET_STRING (
"Passive_balancing/Battery/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 3 , 0 , 0 } , { 78 , 1 , TARGET_STRING (
"Passive_balancing/Battery/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 3 , 0 , 0 } , { 79 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 80 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 81 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 82 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 83 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 84 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 85 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 86 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 87 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 88 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 89 , 6 , TARGET_STRING (
"Passive_balancing/Battery/Model/Saturation Dynamic/Switch" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 90 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 91 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 92 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 93 , 7 , TARGET_STRING (
"Passive_balancing/Battery/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 94 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 95 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 96 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 97 , 8 , TARGET_STRING (
"Passive_balancing/Battery/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 98 , 0 , TARGET_STRING (
"Passive_balancing/Battery/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 99 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 100 , 10 , TARGET_STRING (
"Passive_balancing/Battery1/Model/E_dyn Charge/Product" ) , TARGET_STRING (
"" ) , 0 , 0 , 3 , 0 , 0 } , { 101 , 12 , TARGET_STRING (
"Passive_balancing/Battery1/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 3 , 0 , 0 } , { 102 , 11 , TARGET_STRING (
"Passive_balancing/Battery1/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 3 , 0 , 0 } , { 103 , 9 , TARGET_STRING (
"Passive_balancing/Battery1/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 3 , 0 , 0 } , { 104 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 105 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 106 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 107 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 108 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 109 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 110 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 111 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 112 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 113 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 114 , 14 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Saturation Dynamic/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 115 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 116 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 117 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 118 , 15 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 119 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 120 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 121 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 122 , 16 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 123 , 0 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 124 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/E_dyn Charge/Multiport Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 125 , 18 , TARGET_STRING (
"Passive_balancing/Battery2/Model/E_dyn Charge/Product" ) , TARGET_STRING (
"" ) , 0 , 0 , 3 , 0 , 0 } , { 126 , 20 , TARGET_STRING (
"Passive_balancing/Battery2/Model/E_dyn Charge/Product1" ) , TARGET_STRING (
"" ) , 0 , 0 , 3 , 0 , 0 } , { 127 , 19 , TARGET_STRING (
"Passive_balancing/Battery2/Model/E_dyn Charge/Product2" ) , TARGET_STRING (
"" ) , 0 , 0 , 3 , 0 , 0 } , { 128 , 17 , TARGET_STRING (
"Passive_balancing/Battery2/Model/E_dyn Charge/Product3" ) , TARGET_STRING (
"" ) , 0 , 0 , 3 , 0 , 0 } , { 129 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Exp/Abs" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 130 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Exp/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 131 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Exp/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 132 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Exp/Integrator2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 133 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Exp/Multiport Switch1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 134 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Exp/Divide" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 135 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Exp/Saturation" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 136 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Exp/Add3" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 137 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Saturation Dynamic/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 138 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Saturation Dynamic/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 139 , 22 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Saturation Dynamic/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 140 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Saturation Dynamic/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 141 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Saturation Dynamic1/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 142 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Saturation Dynamic1/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 143 , 23 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Saturation Dynamic1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 144 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Saturation Dynamic1/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 145 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Saturation Dynamic2/LowerRelop1" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 146 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Saturation Dynamic2/UpperRelop" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 147 , 24 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Saturation Dynamic2/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 148 , 0 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Saturation Dynamic2/Switch2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 0 , 0 , ( NULL ) , ( NULL ) ,
0 , 0 , 0 , 0 , 0 } } ; static const rtwCAPI_BlockParameters
rtBlockParameters [ ] = { { 149 , TARGET_STRING ( "Passive_balancing/Battery"
) , TARGET_STRING ( "BatType" ) , 0 , 0 , 0 } , { 150 , TARGET_STRING (
"Passive_balancing/Battery1" ) , TARGET_STRING ( "BatType" ) , 0 , 0 , 0 } ,
{ 151 , TARGET_STRING ( "Passive_balancing/Battery2" ) , TARGET_STRING (
"BatType" ) , 0 , 0 , 0 } , { 152 , TARGET_STRING (
"Passive_balancing/Battery/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 153 , TARGET_STRING (
"Passive_balancing/Battery/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 154 , TARGET_STRING (
"Passive_balancing/Battery/Model/Constant1" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 155 , TARGET_STRING (
"Passive_balancing/Battery/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 156 , TARGET_STRING (
"Passive_balancing/Battery/Model/Constant9" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 157 , TARGET_STRING ( "Passive_balancing/Battery/Model/Gain" )
, TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 158 , TARGET_STRING (
"Passive_balancing/Battery/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 159 , TARGET_STRING ( "Passive_balancing/Battery/Model/R1" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 160 , TARGET_STRING (
"Passive_balancing/Battery/Model/R2" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 161 , TARGET_STRING ( "Passive_balancing/Battery/Model/R3" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 162 , TARGET_STRING (
"Passive_balancing/Battery/Model/R4" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0
} , { 163 , TARGET_STRING ( "Passive_balancing/Battery/Model/int(i)" ) ,
TARGET_STRING ( "UpperSaturationLimit" ) , 0 , 0 , 0 } , { 164 ,
TARGET_STRING ( "Passive_balancing/Battery/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 165 , TARGET_STRING (
"Passive_balancing/Battery/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 166 , TARGET_STRING (
"Passive_balancing/Battery/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 167 , TARGET_STRING (
"Passive_balancing/Battery/Model/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 0 , 0 , 0 } , { 168 , TARGET_STRING (
"Passive_balancing/Battery/Model/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 0 , 0 , 0 } , { 169 , TARGET_STRING (
"Passive_balancing/Battery/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0 }
, { 170 , TARGET_STRING ( "Passive_balancing/Battery/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 171 , TARGET_STRING (
"Passive_balancing/Battery/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 172 , TARGET_STRING (
"Passive_balancing/Battery/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 173 , TARGET_STRING (
"Passive_balancing/Battery1/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 174 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 175 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Constant1" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 176 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 177 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Constant9" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 178 , TARGET_STRING ( "Passive_balancing/Battery1/Model/Gain"
) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 179 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 180 , TARGET_STRING ( "Passive_balancing/Battery1/Model/R1" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 181 , TARGET_STRING (
"Passive_balancing/Battery1/Model/R2" ) , TARGET_STRING ( "Gain" ) , 0 , 0 ,
0 } , { 182 , TARGET_STRING ( "Passive_balancing/Battery1/Model/R3" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 183 , TARGET_STRING (
"Passive_balancing/Battery1/Model/R4" ) , TARGET_STRING ( "Gain" ) , 0 , 0 ,
0 } , { 184 , TARGET_STRING ( "Passive_balancing/Battery1/Model/int(i)" ) ,
TARGET_STRING ( "UpperSaturationLimit" ) , 0 , 0 , 0 } , { 185 ,
TARGET_STRING ( "Passive_balancing/Battery1/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 186 , TARGET_STRING (
"Passive_balancing/Battery1/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 187 , TARGET_STRING (
"Passive_balancing/Battery1/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 188 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 189 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 190 , TARGET_STRING (
"Passive_balancing/Battery1/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0
} , { 191 , TARGET_STRING ( "Passive_balancing/Battery1/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 192 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 193 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 194 , TARGET_STRING (
"Passive_balancing/Battery2/Current Measurement/do not delete this gain" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 195 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Constant" ) , TARGET_STRING ( "Value" ) , 0
, 0 , 0 } , { 196 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Constant1" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 197 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Constant12" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 198 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Constant9" ) , TARGET_STRING ( "Value" ) ,
0 , 0 , 0 } , { 199 , TARGET_STRING ( "Passive_balancing/Battery2/Model/Gain"
) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 200 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0
, 0 } , { 201 , TARGET_STRING ( "Passive_balancing/Battery2/Model/R1" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 202 , TARGET_STRING (
"Passive_balancing/Battery2/Model/R2" ) , TARGET_STRING ( "Gain" ) , 0 , 0 ,
0 } , { 203 , TARGET_STRING ( "Passive_balancing/Battery2/Model/R3" ) ,
TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 204 , TARGET_STRING (
"Passive_balancing/Battery2/Model/R4" ) , TARGET_STRING ( "Gain" ) , 0 , 0 ,
0 } , { 205 , TARGET_STRING ( "Passive_balancing/Battery2/Model/int(i)" ) ,
TARGET_STRING ( "UpperSaturationLimit" ) , 0 , 0 , 0 } , { 206 ,
TARGET_STRING ( "Passive_balancing/Battery2/Model/int(i)" ) , TARGET_STRING (
"LowerSaturationLimit" ) , 0 , 0 , 0 } , { 207 , TARGET_STRING (
"Passive_balancing/Battery2/Model/it init" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 208 , TARGET_STRING (
"Passive_balancing/Battery2/Model/it init1" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 209 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 210 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 211 , TARGET_STRING (
"Passive_balancing/Battery2/Model/BAL" ) , TARGET_STRING ( "A" ) , 0 , 0 , 0
} , { 212 , TARGET_STRING ( "Passive_balancing/Battery2/Model/BAL" ) ,
TARGET_STRING ( "C" ) , 0 , 0 , 0 } , { 213 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Current filter" ) , TARGET_STRING ( "A" ) ,
0 , 0 , 0 } , { 214 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Current filter" ) , TARGET_STRING ( "C" ) ,
0 , 0 , 0 } , { 215 , TARGET_STRING ( "Passive_balancing/IGBT/Model/qqq" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 216 , TARGET_STRING (
"Passive_balancing/IGBT1/Model/qqq" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0
} , { 217 , TARGET_STRING ( "Passive_balancing/IGBT2/Model/qqq" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 218 , TARGET_STRING (
"Passive_balancing/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P1" ) , 0 , 4 , 0 } , { 219 , TARGET_STRING (
"Passive_balancing/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P2" ) , 0 , 5 , 0 } , { 220 , TARGET_STRING (
"Passive_balancing/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P4" ) , 0 , 6 , 0 } , { 221 , TARGET_STRING (
"Passive_balancing/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P5" ) , 0 , 7 , 0 } , { 222 , TARGET_STRING (
"Passive_balancing/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P6" ) , 0 , 8 , 0 } , { 223 , TARGET_STRING (
"Passive_balancing/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P7" ) , 0 , 1 , 0 } , { 224 , TARGET_STRING (
"Passive_balancing/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P8" ) , 0 , 8 , 0 } , { 225 , TARGET_STRING (
"Passive_balancing/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P9" ) , 0 , 0 , 0 } , { 226 , TARGET_STRING (
"Passive_balancing/powergui/EquivalentModel1/State-Space" ) , TARGET_STRING (
"P10" ) , 0 , 0 , 0 } , { 227 , TARGET_STRING (
"Passive_balancing/Battery/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 228 , TARGET_STRING (
"Passive_balancing/Battery/Model/Compare To Zero2/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 229 , TARGET_STRING (
"Passive_balancing/Battery/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 230 , TARGET_STRING (
"Passive_balancing/Battery/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 231 , TARGET_STRING (
"Passive_balancing/Battery/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 232 , TARGET_STRING (
"Passive_balancing/Battery/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 233 , TARGET_STRING (
"Passive_balancing/Battery/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 234 , TARGET_STRING (
"Passive_balancing/Battery/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 235 , TARGET_STRING (
"Passive_balancing/Battery/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 236 , TARGET_STRING (
"Passive_balancing/Battery/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 237 , TARGET_STRING (
"Passive_balancing/Battery/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 238 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 239 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 240 , TARGET_STRING (
"Passive_balancing/Battery1/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 241 , TARGET_STRING (
"Passive_balancing/Battery1/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 242 , TARGET_STRING (
"Passive_balancing/Battery1/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 243 , TARGET_STRING (
"Passive_balancing/Battery1/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 244 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 245 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 246 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 247 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 248 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 249 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Compare To Zero/Constant" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 250 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 251 , TARGET_STRING (
"Passive_balancing/Battery2/Model/E_dyn Charge/Constant1" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 252 , TARGET_STRING (
"Passive_balancing/Battery2/Model/E_dyn Charge/Constant2" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 253 , TARGET_STRING (
"Passive_balancing/Battery2/Model/E_dyn Charge/Constant3" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 254 , TARGET_STRING (
"Passive_balancing/Battery2/Model/E_dyn Charge/Constant4" ) , TARGET_STRING (
"Value" ) , 0 , 0 , 0 } , { 255 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Exp/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 256 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Exp/Gain4" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 257 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Exp/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 258 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Exp/Saturation" ) , TARGET_STRING (
"UpperLimit" ) , 0 , 0 , 0 } , { 259 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Exp/Saturation" ) , TARGET_STRING (
"LowerLimit" ) , 0 , 0 , 0 } , { 260 , TARGET_STRING (
"Passive_balancing/Battery/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 261 , TARGET_STRING (
"Passive_balancing/Battery1/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 262 , TARGET_STRING (
"Passive_balancing/Battery2/Model/Exp/Compare To Zero2/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 0 , ( NULL ) , ( NULL ) , 0 , 0 ,
0 } } ; static int_T rt_LoggedStateIdxList [ ] = { - 1 } ; static const
rtwCAPI_Signals rtRootInputs [ ] = { { 0 , 0 , ( NULL ) , ( NULL ) , 0 , 0 ,
0 , 0 , 0 } } ; static const rtwCAPI_Signals rtRootOutputs [ ] = { { 0 , 0 ,
( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 } } ; static const
rtwCAPI_ModelParameters rtModelParameters [ ] = { { 0 , ( NULL ) , 0 , 0 , 0
} } ;
#ifndef HOST_CAPI_BUILD
static void * rtDataAddrMap [ ] = { & rtB . easujerxmm , & rtB . i1ccd4rxd5 ,
& rtB . exhgo3ztsa , & rtB . a4tzm2m5sq , & rtB . irwvsmo3n1 , & rtB .
d5an0i50bp , & rtB . pvu3dnbqsl , & rtB . datxyxwqsn , & rtB . hnt3ftc4mk , &
rtB . iyfasljzji , & rtB . gbetiytzwl , & rtB . gzlt4xylvw , & rtB .
jw451fwnvv , & rtB . p03chjpubi , & rtB . ldgus1sr1s , & rtB . gdglp05luq , &
rtB . kharh1onr2 , & rtB . brzjamghps , & rtB . onwyx43zfl , & rtB .
glvvn5z0tb , & rtB . h5exb04soq , & rtB . huvwhwqywz , & rtB . orby2ps5pm , &
rtB . iomwh2g1s2 , & rtB . eu3o5g1x2r , & rtB . bh3gpd01qa , & rtB .
cun2lttrzh , & rtB . f0c2kodzql , & rtB . i0mboczxg1 , & rtB . nfpqqtt4xe , &
rtB . jzumqygy01 , & rtB . abmum4zdvq , & rtB . gw1zorijkj , & rtB .
j1tsv1iiyg , & rtB . h22uhfy2kg , & rtB . apjpswajes , & rtB . gnspd531yz , &
rtB . ay355figj3 , & rtB . ni5dgzgvxm , & rtB . bkaepijqzl , & rtB .
brbu1ojabk , & rtB . alddy4exqt , & rtB . kmx5zhhmnh , & rtB . jugdae5134 , &
rtB . cdzndnqfwj , & rtB . bjd1txqszf , & rtB . jqep12tdv2 , & rtB .
lt0awrrixb , & rtB . ctnsceddfy , & rtB . pdw4w0iukq , & rtB . e1vfx4yr0v , &
rtB . c0s1abefak , & rtB . me5y00movs , & rtB . jg4yrqfsjm , & rtB .
hys3hftnnd , & rtB . deqrvibqyf , & rtB . h1cgh2p3m1 , & rtB . bybzbvcgip , &
rtB . l3y1twbqro , & rtB . i0gqr3h53o , & rtB . ef23qut0ie , & rtB .
k1a40pib50 , & rtB . p11j5vzjvf , & rtB . bxlrmhtp4q , & rtB . kixhxo1qh1 , &
rtB . ipqjb5oznn , & rtB . ojpg4sgyg2 , & rtB . lersv2nrng , & rtB .
bfoinkupre , & rtB . gisoswnzov , & rtB . be1yt0sowu , & rtB . do3x3pi1jp , &
rtB . dagypwp03e [ 0 ] , & rtB . hkblhik3th [ 0 ] , & rtB . m2x5nkxt2s , &
rtB . fpks1og0r3 [ 0 ] , & rtB . cpafwt3ydk [ 0 ] , & rtB . fktu3qn43z [ 0 ]
, & rtB . amiygo4hlk [ 0 ] , & rtB . iuxt2aetva , & rtB . apotbg3wx1 , & rtB
. abcbugh4lq , & rtB . nigeuue53d , & rtB . ghz5b1e3e3 , & rtB . g1v4ipxq25 ,
& rtB . prvd12bttp , & rtB . grdkvtj4al , & rtB . gyuxlbpm5v , & rtB .
jdzd4nb0ri , & rtB . haad1hudpr , & rtB . bmrka5l5eq , & rtB . oipsn2ext2 , &
rtB . djaii0vejs , & rtB . cgct03fk00 , & rtB . kid3xl3flw , & rtB .
fiehiuyw0k , & rtB . l0gpduqluz , & rtB . pzbmqcb4oc , & rtB . hag5fa5wq5 , &
rtB . i25z0wvgra , & rtB . bpkwyg51d0 [ 0 ] , & rtB . gz0xktnhv2 [ 0 ] , &
rtB . cpsa2gffjp [ 0 ] , & rtB . k4vv5a5qnd [ 0 ] , & rtB . pnshzpy2e2 , &
rtB . pwybstq3ra , & rtB . anyjfk53qp , & rtB . ehifpgdwjy , & rtB .
pvonpaqj1n , & rtB . asmh3r5xcj , & rtB . obg0kvwunj , & rtB . cpfn4adcdj , &
rtB . cfgua3mzpn , & rtB . o2yv2v00xl , & rtB . pgjbxu0ggf , & rtB .
gwm55h223z , & rtB . emt33ggwjf , & rtB . hfuuf2ubg0 , & rtB . luiisy1tsz , &
rtB . jjvc40ph1m , & rtB . etmrit0r0u , & rtB . byn2laotwy , & rtB .
mv3ukrhvwg , & rtB . osqxc1rnvg , & rtB . kvfix31cdr , & rtB . hakcjtbzae [ 0
] , & rtB . lexfemd5s5 [ 0 ] , & rtB . bfwytcdw0r [ 0 ] , & rtB . kvy1l3feb5
[ 0 ] , & rtB . njircekp2k , & rtB . j2xpkyat4x , & rtB . k1ekc1vsf0 , & rtB
. pkj0c3flun , & rtB . eavnlisxfe , & rtB . h14foxcrc1 , & rtB . alow0u4nsz ,
& rtB . cpadzae1y5 , & rtB . ivq3zpd1bd , & rtB . etnpopllbl , & rtB .
fos1jiogax , & rtB . kjglqur00l , & rtB . pvm1yyq1x2 , & rtB . liehtgeamk , &
rtB . oin55b55uz , & rtB . azy5vdur0y , & rtB . jlf0hrvb5z , & rtB .
hoc1uowy0l , & rtB . hbdfujedg1 , & rtB . nj11lx1qq3 , & rtP .
Battery_BatType , & rtP . Battery1_BatType , & rtP . Battery2_BatType , & rtP
. donotdeletethisgain_Gain , & rtP . Constant_Value_jorngiczgp , & rtP .
Constant1_Value , & rtP . Constant12_Value , & rtP . Constant9_Value , & rtP
. Gain_Gain , & rtP . Gain2_Gain , & rtP . R1_Gain , & rtP . R2_Gain , & rtP
. R3_Gain , & rtP . R4_Gain , & rtP . inti_UpperSat , & rtP . inti_LowerSat ,
& rtP . itinit_InitialCondition , & rtP . itinit1_InitialCondition , & rtP .
Saturation_UpperSat_pcz043fnep , & rtP . Saturation_LowerSat_b05y2t0vvl , &
rtP . BAL_A , & rtP . BAL_C , & rtP . Currentfilter_A , & rtP .
Currentfilter_C , & rtP . donotdeletethisgain_Gain_ave45anr4u , & rtP .
Constant_Value_pfu1thap3i , & rtP . Constant1_Value_h1thd4w1zg , & rtP .
Constant12_Value_oujd2whfki , & rtP . Constant9_Value_bcezbzp4a1 , & rtP .
Gain_Gain_a4qiy5rws3 , & rtP . Gain2_Gain_of2pa5ka31 , & rtP .
R1_Gain_bdgjwewy0w , & rtP . R2_Gain_axv50jbqfg , & rtP . R3_Gain_hslbhc5rsq
, & rtP . R4_Gain_e51nv5aiyc , & rtP . inti_UpperSat_ff0nysnmjy , & rtP .
inti_LowerSat_hzpmw3xl5s , & rtP . itinit_InitialCondition_mh2yj0opxq , & rtP
. itinit1_InitialCondition_po45v3mmic , & rtP .
Saturation_UpperSat_p4wbgcsokm , & rtP . Saturation_LowerSat_gdbbvpyvzg , &
rtP . BAL_A_oad34lr4nf , & rtP . BAL_C_cq3wtorxkj , & rtP .
Currentfilter_A_o3r40a2fs0 , & rtP . Currentfilter_C_e5mev0pk52 , & rtP .
donotdeletethisgain_Gain_hhsesvmj2g , & rtP . Constant_Value_no3jct1ds0 , &
rtP . Constant1_Value_lyb1tm4os2 , & rtP . Constant12_Value_fsrk0ximud , &
rtP . Constant9_Value_jb43nlmf1e , & rtP . Gain_Gain_fhbsryzldc , & rtP .
Gain2_Gain_lnlqortcjb , & rtP . R1_Gain_pckb3sksct , & rtP .
R2_Gain_co3b3ev0vv , & rtP . R3_Gain_d3ow5rqpqq , & rtP . R4_Gain_djamifkejg
, & rtP . inti_UpperSat_paqyu313at , & rtP . inti_LowerSat_ntmgylsy20 , & rtP
. itinit_InitialCondition_ha0g3gbxl1 , & rtP .
itinit1_InitialCondition_ma1kf4wxow , & rtP . Saturation_UpperSat_mldly5fnun
, & rtP . Saturation_LowerSat_ctz2o0nkl2 , & rtP . BAL_A_lpxrnrfk4y , & rtP .
BAL_C_ekdjgq2enr , & rtP . Currentfilter_A_b4s30vlpp5 , & rtP .
Currentfilter_C_cr1quwu5bc , & rtP . qqq_Value , & rtP . qqq_Value_fqup2ywv0j
, & rtP . qqq_Value_ahsmvvczti , & rtP . StateSpace_P1 [ 0 ] , & rtP .
StateSpace_P2 [ 0 ] , & rtP . StateSpace_P4 [ 0 ] , & rtP . StateSpace_P5 [ 0
] , & rtP . StateSpace_P6 [ 0 ] , & rtP . StateSpace_P7 [ 0 ] , & rtP .
StateSpace_P8 [ 0 ] , & rtP . StateSpace_P9 , & rtP . StateSpace_P10 , & rtP
. Constant_Value , & rtP . Constant_Value_efypwvyyax , & rtP .
Constant1_Value_ks0gbwvaxk , & rtP . Constant2_Value , & rtP .
Constant3_Value , & rtP . Constant4_Value , & rtP . Gain1_Gain , & rtP .
Gain4_Gain , & rtP . Integrator2_IC , & rtP . Saturation_UpperSat , & rtP .
Saturation_LowerSat , & rtP . Constant_Value_epq2rsx4ba , & rtP .
Constant_Value_h45zreb2fb , & rtP . Constant1_Value_ny1xdqiske , & rtP .
Constant2_Value_ppmjeluned , & rtP . Constant3_Value_kuyjih2run , & rtP .
Constant4_Value_om2zghpbx3 , & rtP . Gain1_Gain_dq4vkdpk0h , & rtP .
Gain4_Gain_j4eqtusam3 , & rtP . Integrator2_IC_iw5ohpmyuz , & rtP .
Saturation_UpperSat_dr1jmbb0we , & rtP . Saturation_LowerSat_haspwmkdbs , &
rtP . Constant_Value_c5l5x2wrr5 , & rtP . Constant_Value_j455eynuld , & rtP .
Constant1_Value_d4ob3b25zw , & rtP . Constant2_Value_cymgwomvip , & rtP .
Constant3_Value_mv2f5w5r3e , & rtP . Constant4_Value_g3r4dndzdn , & rtP .
Gain1_Gain_erkjggn3zc , & rtP . Gain4_Gain_fxc0qhliat , & rtP .
Integrator2_IC_bg2f3nd4dc , & rtP . Saturation_UpperSat_dcwljnke5m , & rtP .
Saturation_LowerSat_pt1ot4ctql , & rtP . Constant_Value_ogegtmkzv0 , & rtP .
Constant_Value_khiqevv1tc , & rtP . Constant_Value_anxi4ijlqk , } ; static
int32_T * rtVarDimsAddrMap [ ] = { ( NULL ) } ;
#endif
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { { "double" ,
"real_T" , 0 , 0 , sizeof ( real_T ) , SS_DOUBLE , 0 , 0 , 0 } , {
"unsigned char" , "boolean_T" , 0 , 0 , sizeof ( boolean_T ) , SS_BOOLEAN , 0
, 0 , 0 } } ;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static const rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 2 , 0 } , { rtwCAPI_VECTOR , 2 , 2 , 0 } , {
rtwCAPI_VECTOR , 4 , 2 , 0 } , { rtwCAPI_VECTOR , 6 , 2 , 0 } , {
rtwCAPI_MATRIX_COL_MAJOR , 8 , 2 , 0 } , { rtwCAPI_VECTOR , 10 , 2 , 0 } , {
rtwCAPI_MATRIX_COL_MAJOR , 12 , 2 , 0 } , { rtwCAPI_MATRIX_COL_MAJOR , 14 , 2
, 0 } , { rtwCAPI_VECTOR , 16 , 2 , 0 } } ; static const uint_T
rtDimensionArray [ ] = { 1 , 1 , 3 , 1 , 6 , 1 , 4 , 1 , 15 , 6 , 1 , 4 , 15
, 39 , 2 , 3 , 1 , 3 } ; static const real_T rtcapiStoredFloats [ ] = { 0.0 ,
1.0 } ; static const rtwCAPI_FixPtMap rtFixPtMap [ ] = { { ( NULL ) , ( NULL
) , rtwCAPI_FIX_RESERVED , 0 , 0 , 0 } , } ; static const
rtwCAPI_SampleTimeMap rtSampleTimeMap [ ] = { { ( const void * ) &
rtcapiStoredFloats [ 0 ] , ( const void * ) & rtcapiStoredFloats [ 0 ] , 0 ,
0 } , { ( const void * ) & rtcapiStoredFloats [ 0 ] , ( const void * ) &
rtcapiStoredFloats [ 1 ] , 1 , 0 } , { ( NULL ) , ( NULL ) , 2 , 0 } } ;
static rtwCAPI_ModelMappingStaticInfo mmiStatic = { { rtBlockSignals , 149 ,
rtRootInputs , 0 , rtRootOutputs , 0 } , { rtBlockParameters , 114 ,
rtModelParameters , 0 } , { ( NULL ) , 0 } , { rtDataTypeMap , rtDimensionMap
, rtFixPtMap , rtElementMap , rtSampleTimeMap , rtDimensionArray } , "float"
, { 808582686U , 3126849085U , 4170160061U , 2909507965U } , ( NULL ) , 0 , 0
, rt_LoggedStateIdxList } ; const rtwCAPI_ModelMappingStaticInfo *
Passive_balancing_GetCAPIStaticMap ( void ) { return & mmiStatic ; }
#ifndef HOST_CAPI_BUILD
void Passive_balancing_InitializeDataMapInfo ( void ) { rtwCAPI_SetVersion (
( * rt_dataMapInfoPtr ) . mmi , 1 ) ; rtwCAPI_SetStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , & mmiStatic ) ; rtwCAPI_SetLoggingStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ; rtwCAPI_SetDataAddressMap ( ( *
rt_dataMapInfoPtr ) . mmi , rtDataAddrMap ) ; rtwCAPI_SetVarDimsAddressMap (
( * rt_dataMapInfoPtr ) . mmi , rtVarDimsAddrMap ) ;
rtwCAPI_SetInstanceLoggingInfo ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArray ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( ( * rt_dataMapInfoPtr ) . mmi , 0 ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void Passive_balancing_host_InitializeDataMapInfo (
Passive_balancing_host_DataMapInfo_T * dataMap , const char * path ) {
rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ; rtwCAPI_SetStaticMap ( dataMap ->
mmi , & mmiStatic ) ; rtwCAPI_SetDataAddressMap ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , NULL ) ; rtwCAPI_SetPath (
dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetChildMMIArray ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 0 ) ; }
#ifdef __cplusplus
}
#endif
#endif
